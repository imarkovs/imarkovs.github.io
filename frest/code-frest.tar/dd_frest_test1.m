clear all

%% benchmark-system
Q = [0 0 0 0.28261 0.50666]; 
P = [1 -1.41833 1.58939 -1.31608 0.88642];
B = ss(tf(Q, P, -1)); n = order(B); 

%% exact frequency response
[h0, Omega] = freqresp(B);

%% exact and noisy data trajectories
Td = 1000; ud0 = rand(Td, 1); yd0 = lsim(B, ud0); wd0 = [ud0 yd0];
s = 0.1;  wt = randn(Td, 2); wd = wd0 + s * norm(wd0) * wt / norm(wt); 
ud = wd(:, 1); yd = wd(:, 2);

%% do the estimation with the didfferent methods
hh_dd = dd_frest(ud, yd, exp(i * Omega), n); 
Bh = ident(wd, 1, n); hh_ident = freqresp(Bh, Omega); 
Bh = n4sid(iddata(yd, ud), n); hh_n4sid = freqresp(Bh, Omega); 
% a = spa(iddata(yd, ud), [], Omega); hh_spa = a.ResponseData; 
hh_spa = spa__(yd, ud, Omega);

%% plot the results
figure(1)
plot(Omega, abs(h0(:)), '-k'), hold on, 
plot(Omega, abs(hh_dd(:)), '--b')
plot(Omega, abs(hh_ident(:)), '-.b')
% plot(Omega, abs(hh_n4sid(:)), '-xr')
plot(Omega, abs(hh_spa(:)), ':r')
box off; h = gca; ax = axis;
h.XTick = [ax(1) ax(2)];
h.YTick = [ax(3) ax(4)];
xlabel('frequency'), ylabel('amplitude')
legend('exact', 'proposed', 'ident', 'spa', 'location', 'best', 'box', 'off')
% print_fig('frest-f3a')

figure(2)
plot(Omega, angle(h0(:)), '-k'), hold on, 
plot(Omega, angle(hh_dd(:)), '--b')
plot(Omega, angle(hh_ident(:)), '-.b')
% plot(Omega, angle(hh_n4sid(:)), '-xr')
plot(Omega, angle(hh_spa(:)), ':r')
box off; h = gca; ax = axis; 
h.XTick = [ax(1) ax(2)];
h.YTick = [ax(3) ax(4)];
xlabel('frequency'), ylabel('phase')
legend('exact', 'proposed', 'ident', 'spa', 'location', 'best', 'box', 'off')
% print_fig('frest-f3p')
