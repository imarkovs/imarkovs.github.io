clear all

%% benchmark-system
Q = [0 0 0 0.28261 0.50666]; 
P = [1 -1.41833 1.58939 -1.31608 0.88642];
B = ss(tf(Q, P, -1)); n = order(B); 

%% Simulation parameters
omega = pi / 4; h0 = freqresp(B, omega); 
ea = @(hh) 100 * abs(abs(h0) - abs(hh)) / abs(h0);
ep = @(hh) 100 * abs(angle(h0) - angle(hh)) / angle(h0);

%% True data
Td = 500; ud0 = rand(Td, 1); yd0 = lsim(B, ud0); wd0 = [ud0 yd0];

%% MC simulation over different noise levels
K = 11; S = linspace(0, 0.1, K); N = 100; 
for k = 1:K
  s = S(k)
  for i = 1:N
    wt = randn(Td, 2); wd = wd0 + s * norm(wd0) * wt / norm(wt); 

    hh_dd = dd_frest(wd(:, 1), wd(:, 2), exp(j * omega), n); 
    Bh = ident(wd, 1, n); hh_ident = freqresp(Bh, omega);
    % a = spa(iddata(wd(:, 2), wd(:, 1)), [], omega); hh_spa = a.ResponseData;
    hh_spa = spa__(wd(:, 2), wd(:, 1), omega);

    Ea_dd(i, k)    = ea(hh_dd);    Ep_dd(i, k)    = ep(hh_dd);    
    Ea_ident(i, k) = ea(hh_ident); Ep_ident(i, k) = ep(hh_ident); 
    Ea_spa(i, k)   = ea(hh_spa);   Ep_spa(i, k)   = ep(hh_spa);   
  end
end
ea_dd    = mean(Ea_dd);    ep_dd    = mean(Ep_dd);    
ea_ident = mean(Ea_ident); ep_ident = mean(Ep_ident); 
ea_spa   = mean(Ea_spa);   ep_spa   = mean(Ep_spa);    
% [S; ea_dd; ea_ident; ea_spa] 
% [S; ep_dd; ep_ident; ep_spa]

figure(1), hold on, S = S * 100;
plot(S, ea_dd, 'b--')
plot(S, ea_ident, 'b-.')
plot(S, ea_spa, 'r:')
box off; h = gca; axis([S(1) S(end) 0 max(ea_spa)])
h.XTick = [S(1) S(end)];
h.YTick = [0 max(ea_spa)];
xlabel('noise level, \%'), ylabel('error $e_a$, \%')
legend('proposed', 'ident', 'spa', 'location', 'best', 'box', 'off')
% print_fig('frest-f1a')

figure(2), hold on
plot(S, ep_dd, 'b--')
plot(S, ep_ident, 'b-.')
plot(S, ep_spa, 'r:')
box off; h = gca; axis([S(1) S(end) 0 max(ep_spa)])
h.XTick = [S(1) S(end)];
h.YTick = [0 max(ep_spa)];
xlabel('noise level, \%'), ylabel('error $e_p$, \%')
legend('proposed', 'ident', 'spa', 'location', 'best', 'box', 'off')
% print_fig('frest-f1p')

%% MC simulation over different  data lengths
Tmax = 1000; ud0 = rand(Tmax, 1); yd0 = lsim(B, ud0); wd0 = [ud0 yd0];
K = 10; TT = round(linspace(100, Tmax, K)); N = 100; s = 0.05;
for k = 1:K
    T = TT(k)
    for i = 1:N
      wt = randn(T, 2); wd = wd0(1:T, :) + s * norm(wd0(1:T, :)) * wt / norm(wt); 

      hh_dd = dd_frest(wd(:, 1), wd(:, 2), exp(j * omega), n); 
      Bh = ident(wd, 1, n); hh_ident = freqresp(Bh, omega);
      % a = spa(iddata(wd(:, 2), wd(:, 1)), [], omega); hh_spa = a.ResponseData;
      hh_spa = spa__(wd(:, 2), wd(:, 1), omega);

      Ea_dd(i, k)    = ea(hh_dd);    Ep_dd(i, k)    = ep(hh_dd);    
      Ea_ident(i, k) = ea(hh_ident); Ep_ident(i, k) = ep(hh_ident); 
      Ea_spa(i, k)   = ea(hh_spa);   Ep_spa(i, k)   = ep(hh_spa);   
    end
end
ea_dd    = mean(Ea_dd);    ep_dd    = mean(Ep_dd);    
ea_ident = mean(Ea_ident); ep_ident = mean(Ep_ident); 
ea_spa   = mean(Ea_spa);   ep_spa   = mean(Ep_spa);    
% [TT; ea_dd; ea_ident; ea_spa]
% [TT; ep_dd; ep_ident; ep_spa]

figure(3), hold on
plot(TT, ea_dd(1:K), 'b--')
plot(TT, ea_ident(1:K), 'b-.')
plot(TT, ea_spa(1:K), 'r:')
box off; h = gca; axis([TT(1) TT(end) 0 max(ea_spa)])
h.XTick = [TT(1) TT(end)];
h.YTick = [0 max(ea_spa)];
xlabel('number of samples $T$'), ylabel('error $e_a$, \%')
legend('proposed', 'ident', 'spa', 'location', 'best', 'box', 'off')
% print_fig('frest-f2a')

figure(4), hold on
plot(TT, ep_dd(1:K), 'b--')
plot(TT, ep_ident(1:K), 'b-.')
plot(TT, ep_spa(1:K), 'r:')
box off; h = gca; axis([TT(1) TT(end) 0 max(ep_spa)])
h.XTick = [TT(1) TT(end)];
h.YTick = [0 max(ep_spa)];
xlabel('number of samples $T$'), ylabel('error $e_p$, \%')
legend('proposed', 'ident', 'spa', 'location', 'best', 'box', 'off')
% print_fig('frest-f2p')
