%% find the frequency response using the algorithm in [1] (spa in Matlab)
function G = spa__(yd0, ud0, omega) 

    omega = [0 omega(:)'];
    phi_yu = cpsd(yd0, ud0, [], [], omega);
    phi_uu = pwelch(ud0,    [], [], omega);

    G = phi_yu ./ phi_uu;
    G = G(2:end);
end
