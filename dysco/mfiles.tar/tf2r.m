
function R = tf2r(H)
[Q P] = tfdata(tf(H), 'v'); 
R = vec(fliplr([Q; -P]))';
