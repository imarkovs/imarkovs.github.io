
function ah = lra(a, r)
[u, s, v] = svd(a); ah = u(:, 1:r) * s(1:r, 1:r) * v(:, 1:r)';
