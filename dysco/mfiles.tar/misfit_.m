
function wh = misfit_(w, B)
P = null(sylv(tf2r(B), size(w, 1)));
wh = P * pinv(P) * vec(w');
wh = reshape(wh, 2, size(w, 1))';
