
function ch = glra(c, n, r)
q = size(c, 2) - n; rr = r - n; 
[Q, R] = qr(c); % R = triu(qr(c, 0)); 
R22 = R((n + 1):(n + q), (n + 1):end);
[u, s, v] = svd(R22);
Rh22 = u(:, 1:rr) * s(1:rr, 1:rr) * v(:, 1:rr)';
R12 = R(1:n, (n + 1):end);
bh = Q(:, 1:(n + q)) * [R12; Rh22];
ch = [c(:, 1:n) bh];
