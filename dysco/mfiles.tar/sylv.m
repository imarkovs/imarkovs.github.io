
function S = sylv(R, T)
nR = length(R); q = 2;
n = (nR / q) - 1;
S = zeros(T - n, q * T);
for i = 1:T - n
  S(i, (1:nR) + (i - 1) * q) = R;
end
