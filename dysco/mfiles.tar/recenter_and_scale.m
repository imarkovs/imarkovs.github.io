
function ah = recenter_and_scale(ah)
max_ah = max(ah(:)); min_ah = min(ah(:)); 
ah = (ah - min_ah) * 255 / (max_ah - min_ah);
