
c = 'br'; fig_name = 'l1-f6';
d = [-1  1 1 -1; 
     -1 -1 1  1]; 
f = @(a, b) [a .^ 2; a .* b; b .^ 2];
R = null(f(d(1, :), d(2, :))')'; 
plot(d(1, :), d(2, :), 'o', 'markersize', 12) 
ax = 2 * axis;
for i = 1:size(R, 1) 
  hold on, plot_model(R(i, :), f, ax, c(i));
end
print_fig(fig_name)
