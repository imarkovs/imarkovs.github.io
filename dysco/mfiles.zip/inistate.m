
function x0 = inistate(w, sys)
l = size(sys, 'order');
x0 = obsv(sys) \ (w(1:l, 2) ...
                  - lsim(sys, w(1:l, 1)));
