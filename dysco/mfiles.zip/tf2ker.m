
function R = tf2ker(H)
[Q P] = tfdata(tf(H), 'v'); 
R = vec(fliplr([Q; -P]))';
