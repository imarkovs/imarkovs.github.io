xini = [0 1 0 2]';
[p, t] = sim_ini(xini); plot(p(1,:), p(2,:)), hold on
g = 9.81;
plot(xini(1) + xini(2) * t, xini(3) + xini(4) * t - 0.5 * g * t .^2, '--r') 
print_figure(1)
[p, t] = sim_ini_friction(xini, 1, 1); plot(p(1,:), p(2,:))
print_figure(6)
