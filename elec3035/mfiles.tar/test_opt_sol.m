xini = zeros(4, 1); 
th = pi/4; xini([2, 4]) = [cos(th); sin(th)];
[p, t] = sim_ini(xini); plot(p(1,:), p(2,:), '-b'), hold on
th = pi/3; xini([2, 4]) = [cos(th); sin(th)];
[p, t] = sim_ini(xini); plot(p(1,:), p(2,:), '--r') 
th = pi/5; xini([2, 4]) = [cos(th); sin(th)];
[p, t] = sim_ini(xini); plot(p(1,:), p(2,:), '--r') 
print_figure(3)
