function vyt = var_yt(xini, m, v)
p = sim_ini(xini); T = size(p, 2);
a1 = [0 1; 0 0]; a = blkdiag(a1, a1, 0); a(4, 5) = 1;
c  = zeros(2, 5); c(1, 1) = 1; c(2, 3) = 1;
b  = [0; 1; 0; 0; 0];
ts = 0.01;
ad = expm(a * ts);
if exist('b'), bd = pinv(a) * (expm(a * ts) - eye(size(a, 1))) * b; end
C = bd;
for i = 1:T-1
  C = [C ad * C(:, end)];
end
vpt = v/m^2 * c * C * C' * c';
vyt = vpt(1, 1);
