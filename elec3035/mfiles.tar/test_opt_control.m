xini = [1; 1; 1; 1]; xdes = [2; 1; 1; 1]; T = 1; m = 1;
u = opt_control(xini, xdes, T, m);
[p, t, x] = sim_ini_input(u, xini, m);
plot(p(1, :), p(2, :)), print_figure(8)
