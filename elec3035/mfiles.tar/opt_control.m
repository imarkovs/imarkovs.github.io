function u = opt_control(xini, xdes, T, m)
a1 = [0 1; 0 0]; a = blkdiag(a1, a1, 0); a(4, 5) = 1;
c  = zeros(2, 5); c(1, 1) = 1; c(2, 3) = 1;
b  = [0 0; 1 0; 0 0; 0 1; 0 0];
ts = 0.01;
ad = expm(a * ts);
if exist('b'), bd = pinv(a) * (expm(a * ts) - eye(size(a, 1))) * b; end
g = 9.81;
C = bd; Td = round(T / ts);
for i = 1:(Td - 1), 
    C = [C, ad * C(:, (end - 1):end)]; 
end
xc =  [xdes; -g] - ad ^ Td * [xini; -g];
u = C(1:4, :)' * inv(C(1:4, :) * C(1:4, :)') * xc(1:4); 
u = fliplr(reshape(u, 2, Td));
