function print_figure(n)
xlabel('x'), ylabel('y'), title('t')
set(gca, 'fontsize', 20)
eval(['print -depsc exercises-f' int2str(n) '.eps'])
