function xini = est_xini(p, t)
a1 = [0 1; 0 0]; a = blkdiag(a1, a1, 0); a(4, 5) = 1;
c  = zeros(2, 5); c(1, 1) = 1; c(2, 3) = 1;
g = 9.81;
N = length(t); O = [];
for i = 1:N
    O = [O; c * expm(a * t(i))];
end
xini = O(:, 1:4) \ (p(:) + g * O(:, 5));
