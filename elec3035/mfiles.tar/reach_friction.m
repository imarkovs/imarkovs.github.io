function vini = reach_friction(pdes, T, m, gamma)
a1 = [0 1; 0 -gamma/m]; a = blkdiag(a1, a1, 0); a(4, 5) = 1;
c  = zeros(2, 5); c(1, 1) = 1; c(2, 3) = 1;
g = 9.81;
phi  = c * expm(a * T);
vini = phi(:, [2, 4]) \ (pdes + g * phi(:, 5));
