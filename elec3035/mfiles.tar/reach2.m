function v = reach2(pini, tini, T)
Tini = tini(end);                       % end of the observation period
[p, t] = sim_ini(est_xini(pini, tini)); % extrapolates pini further in time
v = reach(p(:, find(t == T)), T - Tini);
