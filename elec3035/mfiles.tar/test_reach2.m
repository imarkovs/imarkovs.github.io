[p2, t2] = sim_ini([1 -2 0 1]'); 
Tini = t2(4); T = t2(end - 4);
vini1 = reach2(p2(:, 1:4), t2(1:4), T);
[p1, t1] = sim_ini([0; vini1(1); 0; vini1(2)]); t1 = t1 + Tini;
plot(p1(1, find(t1 <= T + eps)), p1(2, find(t1 <= T + eps)), 'r'), hold on 
plot(p2(1, find(t2 <= T + eps)), p2(2, find(t2 <= T + eps)), 'b') 
print_figure(4)
