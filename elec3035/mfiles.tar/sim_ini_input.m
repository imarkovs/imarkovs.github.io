function [p, t, x] = sim_ini_input(u, xini, m)
a1 = [0 1; 0 0]; a = blkdiag(a1, a1, 0); a(4, 5) = 1;
c  = zeros(2, 5); c(1, 1) = 1; c(2, 3) = 1;
b  = [0 0; 1 0; 0 0; 0 1; 0 0];
ts = 0.01;
ad = expm(a * ts);
if exist('b'), bd = pinv(a) * (expm(a * ts) - eye(size(a, 1))) * b; end
g = 9.81;
x  = [xini; -g];
Td = length(u);
for k = 1:Td
    x = [x ad * x(:, end) + bd * u(:, k)];
end
p = c * x; t = 0:ts:(Td * ts);
