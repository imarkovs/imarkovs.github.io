function [p, t, x] = sim_ini(xini, m, gamma)
a1 = [0 1; 0 -gamma/m]; a = blkdiag(a1, a1, 0); a(4, 5) = 1;
c  = zeros(2, 5); c(1, 1) = 1; c(2, 3) = 1;
ts = 0.01;
ad = expm(a * ts);
if exist('b'), bd = pinv(a) * (expm(a * ts) - eye(size(a, 1))) * b; end
g = 9.81;
x = [xini; -g];
while x(3,end) >= -eps
    x = [x ad * x(:,end)];
end
p = c * x;
T = size(x, 2); t = 0:ts:(T - 1) * ts;
