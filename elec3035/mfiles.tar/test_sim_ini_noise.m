xini = [0 1 0 2]'; m = 1; v = 0.5;
[p, t] = sim_ini_noise(xini, m, v); plot(p(1,:), p(2,:)), print_figure(5)
