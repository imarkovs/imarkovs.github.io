xini = zeros(4, 1); xini([2, 4]) = reach([1; 0], 1);
[p, t] = sim_ini(xini); plot(p(1,:), p(2,:)), print_figure(2)
xini = zeros(4, 1); xini([2, 4]) = reach_friction([1; 0], 1, 1, 1);
[p, t] = sim_ini_friction(xini, 1, 1); plot(p(1,:), p(2,:)), print_figure(7)
