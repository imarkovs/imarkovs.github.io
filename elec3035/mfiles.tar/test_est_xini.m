[p, t] = sim_ini([1 2 3 4]'); est_xini(p(:, 1:4), t(1:4)) 
