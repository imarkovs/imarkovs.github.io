function U = DeePC_OSQP(N,Tini,T, UP, YP, UF,YF,lambda_g,x_ini,t,lambda_y, Q, R,r,ub,lb)
% This function will solve the DeePC optimization problem (quadratic regularization) by using OSQP.

m = 2;
p = 2;

global osqpSolver;  

if t == 0
    % We initialize the sovler at t = 0.
    H = blkdiag(R * [UF]'*[UF] + (YF'*Q * YF) + lambda_g * eye(T-Tini-N+1),lambda_y * eye(p*Tini));
    f = [- kron(r',ones(1,N)) * Q * YF zeros(1,p*Tini)];
    Aeq = [[UP;YP] [zeros(m*Tini,p*Tini);-1 * eye(p*Tini)]];
    Aineq = [ [UF;YF]   zeros(m*N + p*N,p*Tini) ];
    
    l = [x_ini;kron(lb,ones(N,1))];
    u = [x_ini;kron(ub,ones(N,1))];
    
    osqpSolver = osqp;
    osqpSolver.setup(H,f,[Aeq;Aineq],l,u);
    
    out = osqpSolver.solve();
    g = out.x;
    U = [UF] * g(1:T-Tini-N+1,1);
else
    l = [x_ini;kron(lb,ones(N,1))];
    u = [x_ini;kron(ub,ones(N,1))];
    f = [- kron(r',ones(1,N)) * Q * YF zeros(1,p*Tini)];
    osqpSolver.update('l', l, 'u', u, 'q', f);
    out = osqpSolver.solve();
    g = out.x;
    U = [UF] * g(1:T-Tini-N+1,1);
end
    
end

