----- Simulink Models for DeePC (Version 1.1) -----
--------------------------------------------------
--------------------------------------------------
----- Copyright 2022 ETH Zurich, Linbin Huang -----
--------------------------------------------------------------------------------------------------

----- Licensed under the Apache License, Version 2.0 (the "License");
----- you may not use this file except in compliance with the License.
----- You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

----- Unless required by applicable law or agreed to in writing, software
----- distributed under the License is distributed on an "AS IS" BASIS,
----- WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
----- See the License for the specific language governing permissions and
----- limitations under the License.

-- MATLAB R2020b (or higher versions) is required to run the simulink models. "OSQP" (https://osqp.org/) should be installed to run the models.

-- To get the results, simply run "Data_Collection.slx" and then "DeePC_Runing.slx". You will see the results in the colored scope in "DeePC_Runing.slx". The other functions/scripts in the folder will be automatically executed during the simulations.
-- The "unknown system" in the Simulink models is a (marginally stable) second-order system, where you will observe that DeePC can effectively eliminate the oscillations and improve the damping ratio.

-- To reproduce the power system simulation results in the paper "Data-driven control based on behavioral framework: from theory to applications in power systems", you will need to follow the steps below:
-- 1. Find the Simulink example model in MATLAB: "Wind Farm - Synchronous Generator and Full Scale Converter (Type 4) Average Model";
-- 2. Change the length of the transmission line from 30km to 85km to create a weak grid;
-- 3. In the block "Data_Collection/wind_Gen/Wind Turbine Type 4/Control/Measurement and Transformation/PLL", disable the "Automatic Gain Control" and use the PI parameters (ki_PLL,kp_PLL) provided in "InitFile.m" for the PLL;
-- 4. Follow the instructions provided in the Simulink model "Data-driven control based on behavioral framework: from theory to applications in power systems" on how to run the model to a steady state and save the initial state;
-- 5. Follow the system settings in the paper "Data-driven control based on behavioral framework: from theory to applications in power systems" on the choices of inputs/outputs;
-- 6. Replace the "unknown system" in the Simulink models by your modified model.

-- The main parameters of DeePC can be changed in the script "InitFile.m".

!! If you are using this software in your research or teaching, please include explicit mention of this software and of our papers:

@article{markovsky2022,
  title   =  {Data-driven control based on behavioral framework: from theory to applications in power systems},
  author  =  {Markovsky, Ivan and Huang, Linbin and D{\"o}rfler, Florian},
  journal =  {IEEE Control Systems Magazine},
  year    =  {2022}
}

@article{huang2022,
  title   =  {Decentralized Data-Enabled Predictive Control for Power System Oscillation Damping},
  author  =  {Huang, Linbin and Coulson, Jeremy and Lygeros, John and D{\"o}rfler, Florian},
  journal =  {IEEE Transactions on Control Systems Technology},
  volume={30},
  number={3},
  pages={1065--1077},
  year={2022},
  publisher={IEEE}
}
