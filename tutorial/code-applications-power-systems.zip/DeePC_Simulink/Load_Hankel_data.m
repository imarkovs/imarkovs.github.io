a = 3/Tc; % Start to collect the data at time = 3s
b = a + T - 1;

%% Use the data recorded in the scope to build the Hankel matrices
U = [data_uy.signals(1).values(a:b)';data_uy.signals(2).values(a:b)'];
Y = [data_uy.signals(3).values(a:b)';data_uy.signals(4).values(a:b)'];

for i = 1:T-Tini-N+1
    for j = 1:Tini+N
        U1(j,i) = U(1,i+j-1);
        U2(j,i) = U(2,i+j-1);
        Y1(j,i) = Y(1,i+j-1);
        Y2(j,i) = Y(2,i+j-1);
    end
end

UP1 = U1(1:Tini,:);
UF1 = U1(Tini+1:Tini+N,:);
UP2 = U2(1:Tini,:);
UF2 = U2(Tini+1:Tini+N,:);
YP1 = Y1(1:Tini,:);
YF1 = Y1(Tini+1:Tini+N,:);
YP2 = Y2(1:Tini,:);
YF2 = Y2(Tini+1:Tini+N,:);

UP = [UP1;UP2];
UF = [UF1;UF2];
YP = [YP1;YP2];
YF = [YF1;YF2];
%% Calculate the subspace model
K = YF * pinv([UP;YP;UF]);