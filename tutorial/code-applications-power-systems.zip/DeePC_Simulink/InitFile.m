%% create an "unknown system"
sysA = [0.49 4; -0.066 1.5];
sysB = [0.01 0; 0 0.01];
sysC = [1 0; 0 1];
sysD = [0 0; 0 0];
x0 = [0 0]';

%% DeePC parameters

% Select the method:  
controlmode = 1; 
% controlmode = 1 (DeePC: quadratic regularization); 
% controlmode = 2 (DeePC: 1-norm regularization); 
% controlmode = 3 (DeePC: projection-based regularization); 
% controlmode = 4 (SPC); 

Tini = 6; % The length of the initial trajectories
N = 12;   % Prediction horizon (T_f in the paper)
T = 600;  % The length of data trajectories to construct the Hankel matrices (T_d in the paper)

R = 1;     % The weighting of control effort
Q = 100;   % The weighting of output tracking error
lambda_g = 1;   % Regularization parameter
if controlmode == 2 
    lambda_g = 0.06; 
end
lambda_y = 1000; % Regularization parameter (\lambda_{y_{ini}} in the paper)
ub =  [0.05 0.05 1 1]'; % Define the upper bounds for [u1 u2 y1 y2].
lb = [-0.05 -0.05 -1 -1]'; % Define the lower bounds for [u1 u2 y1 y2].

k = 1; % The control horizon equals "k", namely, we apply the first "k" elements of the optimal control sequence 
        % to the system before solving the optimization problem again.

Bat_TsRun = 10e-6; % Simulation step size (if a continuous system, e.g., a wind generator, is used)

Tc = 0.005; % Sampling time of DeePC

m = 2; % number of input
p = 2; % number of output

%% The PI parameters of the PLL in a wind generator
BW = 60;
ki_PLL = BW^2/(2+sqrt(5));
kp_PLL = sqrt(2*ki_PLL);