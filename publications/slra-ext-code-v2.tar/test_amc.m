randn('seed', 0); rand('seed', 0); methods = {}; i = 0;
d0 = rand(m, r) * rand(r, n); 
np = m * n; tts = reshape(1:np, m, n); 
dt = randn(m, n); d = d0 + nl * std(d0(:)) * dt;
E = 1 - ceil(rand(m, n) - eps);
Ig = find(vec(E)); Im = vec(setdiff(1:np, Ig));
d(Im) = 0; % NaN; 
tic, method = 'slra-m'; p = d(:); p(Im) = NaN; 
     if n < 150, 
       [ph, info_slra_m] = slra_ext(tts, p, r, vec(E)); dh = reshape(ph, m, n); 
     else, dh = NaN * ones(m, n); end,   i = i + 1; methods{i} = method; 
                  if isnan(dh), t(i) = NaN; else t(i) = toc; end
                  eg(i) = norm( d(Ig) - dh(Ig)) / norm( d(Ig));
                  em(i) = norm(d0(Im) - dh(Im)) / norm(d0(Im));
tic, method = 'slra-r'; opt.method = 'reg';
     if n < 150, 
       [ph, info_slra_m_reg] = slra_ext(tts, p, r, vec(E), [], [], [], opt); dh = reshape(ph, m, n); 
     else, dh = NaN * ones(m, n); end,    i = i + 1; methods{i} = method; 
                  if isnan(dh), t(i) = NaN; else t(i) = toc; end
                  eg(i) = norm( d(Ig) - dh(Ig)) / norm( d(Ig));
                  em(i) = norm(d0(Im) - dh(Im)) / norm(d0(Im));
tic, method = 'slra-c';     
     s.m = ones(m, 1); s.n = ones(n, 1); s.w = vec(E); opt.maxiter = 200;
     s.w(Im) = 1e-6;
     [ph, info_slra_c] = slra(d(:), s, r, opt); dh = reshape(ph, m, n);   i = i + 1; methods{i} = method; 
                  if isnan(dh), t(i) = NaN; else t(i) = toc; end
                  eg(i) = norm( d(Ig) - dh(Ig)) / norm( d(Ig));
                  em(i) = norm(d0(Im) - dh(Im)) / norm(d0(Im));
tic, method = 'wlra';
     addpath ~/mfiles/missing-data; 
     [Ph, Lh, info_wlra] = wlra(d, r, E); dh = Ph * Lh;     i = i + 1; methods{i} = method; 
                  if isnan(dh), t(i) = NaN; else t(i) = toc; end
                  eg(i) = norm( d(Ig) - dh(Ig)) / norm( d(Ig));
                  em(i) = norm(d0(Im) - dh(Im)) / norm(d0(Im));
tic, method = 'optspace';   
     addpath ~/slra-ext-code/OptSpace_matlab_Reg/; 
     [X S Y info_opt] = OptSpace(sparse(d), r, 100, [], 0, E); dh = X * S * Y'; i = i + 1; methods{i} = method; 
                  if isnan(dh), t(i) = NaN; else t(i) = toc; end
                  eg(i) = norm( d(Ig) - dh(Ig)) / norm( d(Ig));
                  em(i) = norm(d0(Im) - dh(Im)) / norm(d0(Im));
tic, method = 'lmafit';     
     addpath ~/slra-ext-code/LMaFit-adp/;
     addpath ~/slra-ext-code/LMaFit-adp/Utilities;
     opts = []; opts.maxit = 1000; opts.est_rank = 0; 
     opts.rank_min = r; opts.rank_max = r;
     [Ik, Jk] = ind2sub([m n], Ig);
     data = partXY(eye(m), d, Ik, Jk, length(Ig));
     [X, Y, info_adp] = lmafit_mc_adp(m, n, r, Ig', data, opts); dh = X * Y;   i = i + 1; methods{i} = method; 
                  if isnan(dh), t(i) = NaN; else t(i) = toc; end
                  eg(i) = norm( d(Ig) - dh(Ig)) / norm( d(Ig));
                  em(i) = norm(d0(Im) - dh(Im)) / norm(d0(Im));
tic, method = 'rtrmc';      
     addpath ~/slra-ext-code/;
     addpath ~/slra-ext-code/GenRTR/solvers;
     Jrtr = floor((Ig - 1) ./ m) + 1; Irtr = rem((Ig - 1), m) + 1;
     problem = buildproblem(Irtr, Jrtr, d(Ig), ones(size(Ig)), m, n, r, 1e-6);
     U0 = initialguess(problem);
     [U W stats] = rtrmc(problem, opts, U0); dh = reshape(U * W, m, n);    i = i + 1; methods{i} = method; 
                  if isnan(dh), t(i) = NaN; else t(i) = toc; end
                  eg(i) = norm( d(Ig) - dh(Ig)) / norm( d(Ig));
                  em(i) = norm(d0(Im) - dh(Im)) / norm(d0(Im));

                  
                  
res = ['  ' methods;
 'eg' num2cell(eg); 
 'em' num2cell(em); 
 't ' num2cell(t) ];
    %diary(ex), disp(res), diary off
