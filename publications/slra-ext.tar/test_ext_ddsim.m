clear all, close all, randn('seed', 0), rand('seed', 0)
sys0 = zpk(1, 0.9 * [exp(i * pi / 5) exp(-i * pi / 5)], 1, 1);  ell = 2; m = 1; q = 2; 
T1 = 30; T2 = 52; nl = 0.4;
u1 = rand(T1, m); y1 = lsim(sys0, u1); 
E  = rand(T1, q); w1 = [u1 y1] + nl * E / norm(E, 'fro') * norm([u1 y1], 'fro');
u2 = [zeros(ell, 1); 1; zeros(T2 - ell - 1, 1)];
y2 = [zeros(ell, 1); NaN * ones(T2 - ell, 1)]; w2 = [u2 y2];
tts = [blkhank(reshape(1:(T1 * q), q, T1), ell + 1) ...
       blkhank(reshape(T1 * q + (1:(T2 * q)), q , T2), ell + 1)];
w = [ones(q * T1, 1); inf * vec(~isnan(w2'))];       
[wh, info] = slra_ext(tts, vec([w1' w2']), q * ell + 1, diag(w));
wh2 = reshape(wh(T1 * q + 1:end), q, T2);
hh = wh2(m + 1:end, (ell + 1):end)'; 
h0 = impulse(sys0, T2 - ell - 1);

% comparison with subspace
addpath ~/mfiles/detss/
hh2 = uy2h(w1(:, 1:m), w1(:, m + 1:end), ell, 7, T2 - ell);

plot(hh(2:end), '--b'), hold on, plot(h0(2:end), '-r'), plot(hh_(2:end), '-.k')
ax = axis; axis([1, T2 - ell - 1, ax(3:4)]), print_fig('slra-ext-f2')

norm(h0 - hh), norm(h0 - hh2)
tts = blkhank(reshape(1:(T1 * q), q, T1), ell + 1);
[wh1_, info_] = slra_ext(tts, vec(w1'), q * ell + 1);
sysh_ = tf(fliplr(info_.Rh(1:2:end)), - fliplr(info_.Rh(2:2:end)), -1);
hh_ = impulse(sysh_, T2 - ell); hh_ = hh_(1:T2 - ell);
norm(hh - hh_)
