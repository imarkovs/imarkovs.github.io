clear all

% AMC, example 1
ex = 'amc-ex1'; m = 10; n = 100; r = 8; nl = 0; eps = 0.995; test_amc
pause

% AMC, example 2
ex = 'amc-ex2'; m = 10; n = 100; r = 8; nl = 0.1; eps = .995; test_amc
pause

% AMC, example 3
ex = 'amc-ex3'; m = 10; n = 100; r = 8; nl = 0; eps = 0.8; test_amc
pause

% SYSID example 1
ex = 'sysid-ex1'; T = 100; N = 8; NL = linspace(0, 0.1, N); Tm = 30:3:70; test_sysid
pause

% SYSID example 2
ex = 'sysid-ex2'; T = 100; N = 8; NL = linspace(0, 0.1, N); Tm = 40:60; test_sysid
pause

% DDSIM example
T1 = 30; T2 = 52; N = 6; NL = linspace(0, 0.1, N); test_ddsim
pause
