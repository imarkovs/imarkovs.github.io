randn('seed', 0); rand('seed', 0); clear e_*
R0(1, :, :) = [1 0.81]; R0(2, :, :) = [-1 -1.456]; R0(3, :, :) = [1 1]; 
[ell1, p, q] = size(R0); ell = ell1 - 1; m = q - p; 
Q0 = - R0(:, :, 1:m); P0 = R0(:, :, m + 1:q);
sys0 = tf(fliplr(Q0(:)'), fliplr(P0(:)'), 1); , u0 = rand(T, m); y0 = lsim(sys0, u0); w0 = [u0 y0]; w0 = [u0 y0];
s.m = (ell + 1) * ones(q, 1); s.n = T - ell; r = ell * q + m; 
for i = 1:N
  nl = NL(i); wt = randn(T, q); w = w0 + nl * wt / norm(wt, 'fro') * norm([u0 y0], 'fro');, w(Tm, :) = NaN; 
  s.w = double(~isnan(w(:)));
  [wh, info] = slra_ext(s2s(s), w(:), r, s.w); wh = reshape(wh, T, q); 
  Rh = info.Rh / info.Rh(end);, R0_vec = vec(shiftdim(R0, 3))'; e = norm(R0_vec - Rh) / norm(R0_vec);, e_slra_m(i) = e; 
  opt.method = 'reg';
  [wh, info] = slra_ext(s2s(s), w(:), r, s.w, [], [], [], opt); 
  wh = reshape(wh, T, q); Rh = info.Rh / info.Rh(end);, R0_vec = vec(shiftdim(R0, 3))'; e = norm(R0_vec - Rh) / norm(R0_vec);, e_slra_r(i) = e; 
  Im = find(s.w == 0); s.w(Im) = 1e-6;, opt.Rini = Rh;
  [wh, info] = slra(w(:), s, r, opt); wh = reshape(wh, T, q); 
  Rh = info.Rh / info.Rh(end);, R0_vec = vec(shiftdim(R0, 3))'; e = norm(R0_vec - Rh) / norm(R0_vec);, e_slra_c(i) = e; 
  addpath ~/mfiles/missing-data-dynamic/rik/
  try 
    [sysh, wh_m] = sysid_missing_data_rik(w(:, 1), w(:, 2), ell, std(wt)); 
    [Qh Ph] = tfdata(sysh, 'v'); 
    Rh = [- fliplr(Qh) fliplr(Ph)]; 
  catch, 
    wh_m = NaN; Rh = NaN; 
  end
  wh = zeros(size(w)); wh(Tm, :) = wh_m;, R0_vec = vec(shiftdim(R0, 3))'; e = norm(R0_vec - Rh) / norm(R0_vec);, e_sysid(i) = e; 
end

labels = {'nl'; 'slra-m'; 'slra-r'; 'slra-c'; 'sysid'}; 
res = [labels, num2cell([NL; e_slra_m; e_slra_r; e_slra_c; e_sysid])] 
eval(['!rm ' ex]), diary(ex), disp(res), pause(.1), diary off
