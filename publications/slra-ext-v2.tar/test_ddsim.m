randn('seed', 0); rand('seed', 0); clear e_*
R0(1, :, :) = [1 0.81]; R0(2, :, :) = [-1 -1.456]; R0(3, :, :) = [1 1]; 
[ell1, p, q] = size(R0); ell = ell1 - 1; m = q - p; 
Q0 = - R0(:, :, 1:m); P0 = R0(:, :, m + 1:q);
sys0 = tf(fliplr(Q0(:)'), fliplr(P0(:)'), 1);  h0 = impulse(sys0, T2 - ell - 1);
for i = 1:N
  nl = NL(i);
  T = T1; u0 = rand(T, m); y0 = lsim(sys0, u0); w0 = [u0 y0]; w0 = [u0 y0];, wt = randn(T, q); w = w0 + nl * wt / norm(wt, 'fro') * norm([u0 y0], 'fro');, w1 = w;
  u2 = [zeros(ell, 1); 1; zeros(T2 - ell - 1, 1)];
  y2 = [zeros(ell, 1); NaN * ones(T2 - ell, 1)]; w2 = [u2 y2];
  tts = [blkhank(reshape(1:(T1 * q), q, T1), ell + 1) ...
         blkhank(reshape(T1 * q + (1:(T2 * q)), q , T2), ell + 1)];
  w = [ones(q * T1, 1); inf * vec(~isnan(w2'))]; r = ell * q + m; 
  [wh, info] = slra_ext(tts, vec([w1' w2']), r, diag(w));
  wh2 = reshape(wh(T1 * q + 1:end), q, T2); hh = wh2(m + 1:end, (ell + 1):end)';  e = norm(h0 - hh) / norm(hh);, e_slra_m(i) = e; hh1 = hh;
  tts = [blkhank(reshape(1:(T1 * q), q, T1), ell + 1) ...
         blkhank(reshape(T1 * q + (1:(T2 * q)), q , T2), ell + 1)];
  w = [ones(q * T1, 1); inf * vec(~isnan(w2'))]; r = ell * q + m; , 
  opt.method = 'reg'; R0_vec = vec(shiftdim(R0, 3))'; opt.Rini = R0_vec;
  [wh, info] = slra_ext(tts, vec([w1' w2']), r, diag(w), [], [], [], opt);
  wh2 = reshape(wh(T1 * q + 1:end), q, T2); hh = wh2(m + 1:end, (ell + 1):end)';  e = norm(h0 - hh) / norm(hh);, e_slra_r(i) = e;
  s.m = [ell + 1 ell + 1]; s.n = [T1 T2] - ell; r = ell * q + m; 
  s.w = [ones(q * T1, 1); inf * vec(~isnan(w2))];
  [wh, info] = slra([vec(w1); vec(w2)], s, r);
  wh2 = reshape(wh(T1 * q + 1:end), T2, q)'; hh = wh2(m + 1:end, (ell + 1):end)';    e = norm(h0 - hh) / norm(hh);, e_slra_c(i) = e;  
  addpath ~/mfiles/detss/
  hh = uy2h(w1(:, 1:m), w1(:, m + 1:end), ell, 10, T2 - ell);, e = norm(h0 - hh) / norm(hh);, e_ddsim(i) = e; hh2 = hh;
end

labels = {'nl'; 'slra-m'; 'slra-r'; 'slra-c'; 'ddsim'};
res = [labels, num2cell([NL; e_slra_m; e_slra_r; e_slra_c; e_ddsim])];
diary('ddsim_ex'), disp(res), diary off

figure
plot(hh1(2:end), '--b'), hold on, plot(h0(2:end), '-r'), plot(hh2(2:end), '-.k')
ax = axis; axis([1, T2 - ell - 1, ax(3:4)]), print_fig('slra-ext-f2')
