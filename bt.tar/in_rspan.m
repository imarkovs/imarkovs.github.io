function [ans, E, U] = in_rspan(A, B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
U = A * pinv(B, tol); E = A - U * B; ans = norm(E) < tol;
