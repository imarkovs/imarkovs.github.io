clear all
addpath /home/im/Dropbox/mohammad/row-reduction/2024

%% structure's parameters
m = 2; 
ells = [0 0 3 3 5 5];

%% define constants
ell = max(ells); n = sum(ells); 
p = length(ells); q = m + p;
c = [m, ell, n];

%% generate a random example with the specified structure
for i = 1:p, R0cell{i} = rand_schur(ells(i), q); end
R0 = Rcell2Rmat(R0cell, q); 
R0full = multmat(R0cell, q, ell + 1);

%% add g redundant equations and mask the structure
g = 5;
R0 = [R0; rand(g, size(R0full, 1)) * R0full]; 
R0 = rand(size(R0, 1)) * R0; % mask the structure

%% apply the methods and check their results
res = [0 0];

[Rh, ellsh] = R2Rp(R0, q); 
try, if(all(ells == ellsh)), res(1) = 1; end, end

[Rh, ellsh] = R2Rproper(R0, q, p);
try, if(all(ells == ellsh)), res(2) = 1; end, end

res

return 

%% using system identification
T = 30;
BT1 = R2BT(R0cell, q, T, c); 

BT2 = R2BT(R0, q, T, c); 

Bdist(BT1, BT2, q, T, c)

BT2

%% old
q = 2; ell = 1;
R0 = [1 0 0 -1; 0 1 0 -1];
[Rp, ellsh] = R2Rp(R0, q)

R1 = multmat(Rp{1}, q, ell)
R2 = Rp{2}

in_rspan(R2,       R1, 1e-8)
in_rspan(R0(1, :), R1, 1e-8)
in_rspan(R0(2, :), R1, 1e-8)

in_rspan(R2,       perp(R1), 1e-8)
in_rspan(R0(1, :), perp(R1), 1e-8)
in_rspan(R0(2, :), perp(R1), 1e-8)

rspan_intersect(R0, perp(R1), 1e-8)
