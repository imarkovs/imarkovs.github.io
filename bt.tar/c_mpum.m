function [c, m, ell, n] = c_mpum(wd, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
if length(ctol) == 3 % nothing to do
  c = ctol; [m, ell, n] = unpack_c(c); return
end
if ~iscell(wd)
  [Td, q] = size(wd); ell_max = floor((Td + 1) / (q + 1)) - 1; 
else
  N = length(wd); for i = 1:N, [Td(i), q] = size(wd{i}); end
  %% find ell_max (different from the formula in the paper)
  Td = [sort(Td, 'descend') 0];
  for i = 1:N
    ell_max = floor((sum(Td(1:i)) + i) / (q + i)) - 1; 
    if (Td(i + 1) < ell_max + 1), break, end
  end
end
r1 = rank(hank(wd, ell_max), tol); 
r2 = rank(hank(wd, ell_max + 1), tol); 
mn = [ell_max 1; ell_max+1 1] \ [r1; r2]; 
m = round(mn(1)); n = round(mn(2)); 
for ell = 0:n, if rank(hank(wd, ell), tol) == m * ell + n, break, end, end
c = [m, ell, n];
