function BC = B2BC(B, T, ctol), 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
[p, m] = size(B); ell = lag(B); ell_ctr = n;
BT = B2BT(B, ell + ell_ctr + T);
BC = BT2BC(BT, p + m, ctol);
