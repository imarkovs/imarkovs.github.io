function HT = ss2HT(B, T), HT = convm(B, T);
