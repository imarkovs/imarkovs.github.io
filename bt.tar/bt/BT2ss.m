function [Bh, io] = BT2ss(BT, q, io, ctol); 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if ~exist('io', 'var') || isempty(io), io = 1:q; end % <default-io>
if ~exist('c', 'var'), [c, m, ell, n] = BT2c(BT, q, ctol); end
BT = BT2BT(BT, q, 2 * ell + 1); [OK, alt_io] = is_io(BT, q, io, c);
if ~OK, warning('changed I/O partioning'), io = alt_io; end
if q > 1 && any(io ~= 1:q), BT = BT2BT(BT, q, io); end 

%% compute state by past/future intersection
Wpf = BT(1:q * (2 * ell + 1), :); R = null(Wpf', tol)';
Wp  = BT(1:q * ell, :); X = R(:, 1:q * ell) * Wp;

%% compute the shifted state
sigmaWp = BT(q + 1:q * (ell + 1), :); 
sigmaX  = R(:, 1:q * ell) * sigmaWp;

%% make X and sigmaX minimal; TODO: why needed?
[u, s, ~] = svd(X); P = u(1:n, :);
Xmin = P * X; sigmaXmin = P * sigmaX;

%% input/output partition
p = q - m; [UT, YT] = BT2UYT(BT, m, p);
U = UT(m * ell + 1:m * (ell + 1), :);
Y = YT(p * ell + 1:p * (ell + 1), :);

%% compute the state-space parameters
abcd = [sigmaXmin; Y] * pinv([Xmin; U], tol); 
Bh = ss(abcd(1:n,     1:n), abcd(1:n,     n+1:end), ...
        abcd(n+1:end, 1:n), abcd(n+1:end, n+1:end), 1);
