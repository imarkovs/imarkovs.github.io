function BT = BT2BT(BT, q, Tio, ctol)
T = size(BT, 1) / q; 
if isscalar(Tio), Tnew = Tio; % horizon restriction/extension
  if T == Tnew, return, end   % nothing to do
  if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
  %% <default-ctol>
  if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
  elseif length(ctol) == 1, tol = ctol;            % tolerence specification
  else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
  if T > Tnew,                % restriction
    BTnew = BT(1:q * Tnew, :);
    if length(ctol) == 1, BT = lra(BTnew, tol); 
    else, BT = lra(BTnew, c2r(c, Tnew)); end
  else                        % extension
    if length(ctol) == 1, [~, R] = lra(BT, tol); 
    else, [~, R] = lra(BT, c2r(c, T)); end
    BT = R2BT(R, q, Tnew, ctol);
  end
else, io = Tio;               % variables permutation
  BT = BT(q * kron(0:T-1, ones(1, q)) + kron(ones(1, T), io), :);
end
