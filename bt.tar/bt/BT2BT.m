function BT = BT2BT(BT, q, Tio, ctol, opt)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
T = size(BT, 1) / q; 
if isscalar(Tio), Tnew = Tio; % horizon restriction/extension
  if T >= Tnew % restriction
    if exist('opt', 'var') && contains(opt, 'hank')
      M = []; for i = 0:T-Tnew, M = [M, BT(i * q + 1:(i + Tnew) * q, :)]; end
    else, M = BT(1:q * Tnew, :); end
    BT = lra(M, ctol2rtol(ctol, Tnew));
  else         % extension
    if exist('ell', 'var')
      [~, R] = lra(BT(1:q * (ell+1), :), ctol2rtol(ctol, ell+1));
    else, [~, R] = lra(BT, ctol2rtol(ctol, T)); end
    BT = R2BT(R, q, Tnew, ctol);
  end
else, io = Tio;               % variables permutation
  BT = BT(q * kron(0:T-1, ones(1, q)) + kron(ones(1, T), io), :);
end
