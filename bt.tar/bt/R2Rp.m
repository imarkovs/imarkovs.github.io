function [Rp, ells] = R2Rp(R, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
ell1 = size(R, 2) / q; [Rp, ells] = BT2Rp(R2BT(R, q, ell1, ctol), q, ctol);
