function [Rp, ells] = R2Rp(R, q, ellsctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ellsctol>
if exist('ellsctol', 'var') && ~isempty(ellsctol)
  if (ellsctol(1) > 0 && ellsctol(1) < 1), tol = ellsctol; ctol = tol;
  elseif all(size(ellsctol) == [1 3])
     c = ellsctol; [m, ell, n] = unpack_c(c); ctol = c;
  else, ells = ellsctol; [c, m, ell, n] = ells2c(ells, q); ctol = c; end
else, ellsctol = tol; ctol = tol; end
ell1 = size(R, 2) / q; 
[Rp, ells] = BT2Rp(R2BT(R, q, ell1, ctol), q, ellsctol);
