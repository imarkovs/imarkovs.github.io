function BP = ss2BP(B, T)
% TODO
