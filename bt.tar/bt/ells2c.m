function [c, m, ell, n] = ells2c(ells, q)
m = q - length(ells); ell = max(ells); n = sum(ells); c = [m, ell, n];
