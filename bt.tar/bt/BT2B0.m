function [B0, T, c] = BT2B0(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
[c, m, ell, n] = BT2c(BT, q, ctol);
Bini = BT(1:q * ell, :); T = size(BT, 1) / q - ell; 
B0 = lra(BT(q * ell + 1:end, :) * null(Bini, tol), ctol2rtol(c, T, 'B0'));
