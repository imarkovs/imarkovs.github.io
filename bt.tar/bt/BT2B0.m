function [B0, T, c] = BT2B0(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
%% <ctol2c>
if length(ctol) == 3                     % ctol specifies complexity
  c = ctol; [m, ell, n] = unpack_c(c);   
elseif ~exist('c', 'var') || isempty(c)  % the complexity has to be estimated
  if exist('R', 'var') && ~exist('BT', 'var'), BT = null(R, tol); end
  if exist('BT', 'var'), [c, m, ell, n] = BT2c(BT, q, tol); 
  elseif exist('wd', 'var'), [c, m, ell, n] = w2c(wd, tol); end
else, [m, ell, n] = unpack_c(c); end     % in case m, ell, n are not defined 
Bini = BT(1:q * ell, :); T = size(BT, 1) / q - ell; % call BT2BT
B0 = lra(BT(q * ell + 1:end, :) * null(Bini, tol), c2r(c, T, 0));
