function Rp = randB_stable(q, ells)
    p = length(ells); m = q - p; ell1 = max(ells) + 1; 

    % Stable diagonal denominator block
    P = zeros(p, p, ell1); Q = zeros(p, m, ell1);
    for i = 1:p, di = ells(i);
        pi_coeff = stable_scalar_poly(di);   % ascending powers
        P(i, i, 1:di+1) = reshape(pi_coeff, 1, 1, []);
    end

    % Random numerator block, row degree <= di
    for i = 1:p, di = ells(i);
        for k = 0:di
            if m > 0, Q(i, :, k+1) = 0.5 * randn(1, m); end
        end
        % optional: sometimes allow degree exactly di in Q, sometimes not
        % but never disturb row-reducedness because the pivot at y_i remains
        % present in the whole row
        if m > 0 && rand < 0.5, Q(i, :, di+1) = 0; end
    end

    % Form R = [-Q  P]
    R = zeros(p, q, ell1); if m > 0, R(:, 1:m, :) = -Q; end, R(:, m+1:end, :) = P;
    Rmat = reshape(R, p, []); for i = 1:p, Rp{i, 1} = Rmat(i, 1:q * (ells(i) + 1)); end
    end

function a = stable_scalar_poly(d)
    if d == 0, a = 1; return, end
    rho = 0.85; roots_list = [];

    k = 1;
    while k <= d
        if k <= d-1 && rand < 0.5
            r  = rho * (0.2 + 0.8 * rand);
            th = pi * rand;
            z1 = r * exp(1i * th);
            z2 = conj(z1);
            roots_list = [roots_list z1 z2];
            k = k + 2;
        else
            z = rho * (-0.95 + 1.9 * rand);
            roots_list = [roots_list z];
            k = k + 1;
        end
    end

    desc = poly(roots_list);  % descending powers
    a = fliplr(real(desc));   % ascending powers
    a = a / a(end);           % monic
end
