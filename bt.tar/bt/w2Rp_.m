function [Rp, ells] = w2Rp_(w, ell_max, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~iscell(w), [T, q] = size(w); else, [T, q] = size(w{1}); end 
if ~exist('ell_max', 'var') || isempty(ell_max)
  ell_max = floor((T + 1) / (q + 1)); 
end
m = q; p = 0; ells = []; Rp = {};
for L = 1:ell_max+1
  if ~isempty(Rp), R_perp = perp(R2M(Rp, q, L), tol);
  else,            R_perp = eye(q * L); end
  Z = null((R_perp * hank(w, L))', tol)';   
  if ~isempty(Z) 
    Rnew = Z * R_perp; Rp = [Rp; Rnew]; 
    ells = [ells (size(Rnew, 2) / q - 1) * ones(1, size(Rnew, 1))];
    p = p + size(Rnew, 1); m = m - size(Rnew, 1); 
  end
end
