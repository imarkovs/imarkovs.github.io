function d = distunctr(BT, q, nc, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if ~exist('nc', 'var') || isempty(nc), nc = 1; end
[c, m, ell, n] = BT2c(BT, q, ctol); 
Bini = BT(1:q * ell, :); % call BT2BT
[~, NullBini] = lra(Bini', m * ell + n);
BC = BT((q * 2 * ell + 1):end, :) * NullBini';
[P, R, hatBC] = lra(BC, m * size(BC, 1) / q + n - nc); 
d = norm(BC - hatBC, 'fro') / norm(BC, 'fro');
