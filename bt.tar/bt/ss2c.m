function [c, m, ell, n] = ss2c(B, tol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[p, m] = size(B); n = rank(obsv(B)); 
ell = lag(B, tol); c = [m, ell, n];
