function BvT = BTselect(BT, q, v)
BT = BT2BT(BT, q, [v, setdiff(1:q, v)]);
BvT = BT2UYT(BT, length(v), q - length(v));
