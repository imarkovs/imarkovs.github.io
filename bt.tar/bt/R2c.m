function [c, m, ell, n] = R2c(R_or_Rp, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if length(ctol) == 3, c = ctol; [m, ell, n] = unpack_c(c); % nothing to do
else
  if iscell(R_or_Rp), Rp = R_or_Rp;
    c = ells2c(Rp2ells(Rp, q), q); [m, ell, n] = unpack_c(c);
  else,               R = R_or_Rp; 
    [c, m, ell, n] = BT2c(null(R, ctol), q, ctol); 
  end
end
