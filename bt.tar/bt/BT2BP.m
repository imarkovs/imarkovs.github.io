function BP = BT2BP(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
[c, m, ell, n] = BT2c(BT, q, ctol); p = q - m; 

T = size(BT, 1) / q; t = (1:T)'; 
[UT, YT] = BT2UYT(BT, m, p); P = [UT; YT];

%% ??? TODO
z = exp(i * linspace(0, 2 * pi, T));
for k = 1:length(z)
  A  = [[zeros(m * T, p); -kron(z(k) .^ t, eye(p))] P];
  hg = pinv(A, tol) * [kron(z(k) .^ t, eye(m)); zeros(p * T, m)]; 
  Hh(:, :, k) = hg(1:p, :); 
end
