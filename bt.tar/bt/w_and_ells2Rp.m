function Rp = w_and_ells2Rp(wd, ells)
if ~iscell(wd), q = size(wd, 2); else, q = size(wd{1}, 2); end
p = length(ells); Rp = {}; [ells_, ia, ic] = unique(ells);
for i = ells_, L = i + 1;
  if ~isempty(Rp), R_perp = perp(R2M(Rp, q, L));
  else,            R_perp = eye(q * L); end
  [~, Z] = lra(R_perp * hank(wd, L), size(R_perp, 1) - sum(i == ells));
  Rnew = Z * R_perp; Rp = [Rp; Rnew]; 
end
