function R = w2R(wd, ctol, ell_max)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if exist('ell', 'var'), ell_max = ell; % overwrite a given one
elseif ~exist('ell_max', 'var') || isempty(ell_max)
  %% <find-ell_max>
  if ~iscell(wd) % one trajectory
    [Td, q] = size(wd); ell_max = floor((Td + 1) / (q + 1)) - 1; 
  else           % multiple trajectories
    N = length(wd); for i = 1:N, [Td(i), q] = size(wd{i}); end
    Td = [sort(Td, 'descend') 0];
    for i = 1:N  
      ell_max = floor((sum(Td(1:i)) + i) / (q + i)) - 1; 
      if (Td(i + 1) < ell_max + 1), break, end
    end
  end
end
[~, R] = lra(hank(wd, ell_max+1), ctol2rtol(ctol, ell_max+1));
