function R = w2R(wd, ctol) 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if length(ctol) == 3 % ctol specifies complexity
  c = ctol; [m, ell, n] = unpack_c(c); r = m * (ell+1) + n;  
else                 % the complexity has to be estimated
  %% <find-ell_max>
  if ~iscell(wd)
    [Td, q] = size(wd); ell_max = floor((Td + 1) / (q + 1)) - 1; 
  else
    N = length(wd); for i = 1:N, [Td(i), q] = size(wd{i}); end
    Td = [sort(Td, 'descend') 0];
    for i = 1:N
      ell_max = floor((sum(Td(1:i)) + i) / (q + i)) - 1; 
      if (Td(i + 1) < ell_max + 1), break, end
    end
  end
  ell = ell_max; r = ctol; 
end 
[~, R] = lra(hank(wd, ell+1), r);
