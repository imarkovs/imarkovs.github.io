function [B, io] = w2ss(wd, io, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if ~iscell(wd), q = size(wd, 2); else, q = size(wd{1}, 2); end
if ~exist('io', 'var') || isempty(io), io = 1:q; end % <default-io>
[B, io] = R2ss(w2R(wd, ctol), q, io, ctol);
