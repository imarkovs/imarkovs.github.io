function R = ss2R(B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[c, m, ell] = ss2c(B, tol); [~, R] = lra(B2BT(B, ell + 1), c2r(c, ell + 1));
