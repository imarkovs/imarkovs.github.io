function R = ss2R(B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
q = sum(size(B)); [c, m, ell] = ss2c(B, tol); 
R = BT2R(B2BT(B, ell + 1), q, c);
