clear all, clc, echo on
%% Interconnection of systems: series connection

n1 = 2; B1 = drss(n1); q1 = 2;
n2 = 2; B2 = drss(n2); q2 = 2;

R3 = [0 1 -1 0]; q3 = 4;

T = n1 + n2 + 1; BT1 = ss2BT(B1, T); BT2 = ss2BT(B2, T); BT3 = R2BT(R3, q3, T);

BT12    = BTappend(BT1, q1, BT2, q2);
BT12int = BTintersect(BT12, BT3);

B12 = B2 * B1;

BT12_ = BTselect(BT12int, q3, [1 4]); q12 = 2;

equal(B12, BT12_, q12) % -> 1

echo off
