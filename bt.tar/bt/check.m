function check(a, s)
if ~exist('s', 'var'), s = []; end
if a, m = ['PASSED: ' s]; else, m = ['FAILED: ' s]; end, disp(m)
