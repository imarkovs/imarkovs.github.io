function R = Rp2R(Rp, q)
if ~iscell(Rp), R = Rp;
else            R = R2M(Rp, q, max(Rp2ells(Rp, q)) + 1); end
