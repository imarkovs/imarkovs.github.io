function R = Rp2R(Rp, q)
if ~iscell(Rp), R = Rp; return, end
g = length(Rp); R = []; ells = Rp2ells(Rp, q); R = R2M(Rp, q, max(ells)+1);
