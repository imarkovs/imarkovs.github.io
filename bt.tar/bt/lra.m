function [P, R, dh] = lra(d, rtol, opt)
[u, s, v] = svd(d); 
if rtol < 1 
  r = sum(sum(diag(s) > rtol)); % the rank is estimated 
else r = rtol; end              % the rank is given 
if ~exist('opt', 'var')         % bases for image and left kernel (primal)
  P = u(:, 1:r);  R = u(:, (r + 1):end)';    
else                            % bases for rowspan and right kernel (dual)
  P = v(:, 1:r)'; R = v(:, (r + 1):end); 
end 
if nargout > 2, dh = u(:, 1:r) * s(1:r, 1:r) * v(:, 1:r)'; end
