clear all, clc, echo on
%% Model reduction

%% full order model
opt = 'stable'; 
m = 1; ells = [10]'; 
p = length(ells); q = m + p; c = ells2c(ells, q); ell = c(2); n = c(3);
Rp = randB(q, ells, opt); 
BT = R2BT(Rp, q, ell+1, c); 
[B, io] = R2ss(Rp, q, [], c);

%% reduction specification
nr = 9; cr = [m ceil(nr/p) nr]; ellsr = c2ells(cr, q); 

%% validation criteria
e1 = @(BTh) Bdist(BT, BTh, q); 
e2 = @(Bh) 100 * norm(B - Bh) / norm(Bh); 
T = 100; w = R2w(Rp, q, T); wp = w(1:ell, :); wf = w(ell+1:end, :);
e3 = @(yh) 100 * norm(wf(:, m+1:end) - yh) / norm(wf(:, m+1:end)); 

%% BT2BT+BT2Rp
BTr  = BT2BT(BT, q, cr(2)+1, cr, 'hank'); % BT2c(BTr, q),  BT2ells(BTr, q)
[Br, ioc] = BT2ss(BTr, q, [], cr);
Rpr  = BT2Rp(BTr, q, ellsr);
BTrp = R2BT(Rpr, q, T); 
[Brp, io]  = R2ss(Rpr, q, [], cr);

%% check
cr, crh    = BT2c(BTrp, q), 
ellsr, ellsrh = BT2ells(BTrp, q)

%% balanced model reduction
Brb = balred(B, nr); BTrb = B2BT(Brb, T);

%% compare results
yh  = u2y(BTr,  q, wf(:, 1:m), wp);
yhp = u2y(BTrp, q, wf(:, 1:m), wp);
yhb = u2y(BTrb, q, wf(:, 1:m), wp);
[e1(BTr)  e2(Br)  e3(yh)
 e1(BTrp) e2(Brp) e3(yhp) 
 e1(BTrb) e2(Brb) e3(yhb)]
