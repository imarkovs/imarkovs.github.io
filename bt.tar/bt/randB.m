function Rp = randB(q, c_or_ells, opt)
if length(c_or_ells) ~= 3 || (exist('opt') && ~isempty(strfind(c_or_ells, 'ells')))
    ells = c_or_ells; [c, m, ell, n] = ells2c(ells, q); p = q - m;
else, c = c_or_ells; [m, ell, n] = unpack_c(c); p = q - m; ells = c2ells(c, q); end
for i = 1:p
  if (exist('opt') && ~isempty(strfind(opt, 'stable')))
    Rp{i, 1} = rand_schur(ells(i), q);
  else, Rp{i, 1} = rand(1, q * (ells(i) + 1)); end
end

function r = rand_schur(ell, q)
r = zeros(1, q * (ell+1));
for i = 1:q, s = drss(ell); r(i:q:end) = rand * flip(poly(eig(s))); end
