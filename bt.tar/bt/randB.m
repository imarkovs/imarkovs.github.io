function Rp = randB(q, ellsc, opt)
if all(size(ellsc) == [1 3]), 
  c = ellsc; [m, ell, n] = unpack_c(c); ells = c2ells(c, q); 
else, ells = ellsc; [c, m, ell, n] = ells2c(ells, q); end
if exist('opt') && contains(opt, 'stable'), Rp = randB_stable(q, ells);
else, for i = 1:(q-m), Rp{i, 1} = rand(1, q * (ells(i) + 1)); end, end
