function R = BT2R(BT, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if ~exist('ell', 'var'), ell = size(BT, 1) / q - 1; end
[~, R] = lra(BT(1:q * (ell+1), :), ctol2rtol(ctol, ell+1));
