function M = R2M(R, q, T)
if ~iscell(R), M = multmat(R, q, T);
else, N = length(R); M = []; for i = 1:N, M = [M; multmat(R{i}, q, T)]; end, end
