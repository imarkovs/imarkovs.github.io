function h = B2h(B, T)
[p, m] = size(B); q = m + p; I = eye(m);
ell = lag(B); BT = B2BT(B, ell + T); 
for i = 1:m 
  uf = zeros(T, m); uf(1, :) = I(i, :);
  h(:, :, i) = u2y(BT, q, uf, zeros(ell, q));
end
