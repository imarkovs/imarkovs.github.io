clear all, close all
m = 1; p = 1; q = m + p; n = 10; 
B = drss(n, p, m); ell = lag(B);

Tmax = 1000; tic, BT = B2BT(B, Tmax + ell); t_BT = toc 

np = 10; TT = round(linspace(100, Tmax, np));
u = rand(Tmax, m); xini = zeros(n, 1); 
wini = w2wini([u lsim(B, u, [], xini)], BT, ell);
for i = 1:np, T = TT(i),
  tic, y  = lsim(B, u(1:T, :), [], xini); t_lsim(i) = toc;
  tic, y_ = u2y(BT, q, u(1:T, :), wini); t_u2y(i) = toc;
  e(i) = norm(y - y_) / norm(y);
end

T = 100; NN = round(linspace(10, 100, np)); u = rand(T, m); 
for i = 1:np, n = NN(i);
  B = drss(n, p, m); ell = lag(B); xini = zeros(n, 1); 
  tic, BT = B2BT(B, T + ell); t_BT = toc; 
  wini = w2wini([u lsim(B, u, [], xini)], BT, ell);
  tic, y  = lsim(B, u(1:T, :), [], xini); tn_lsim(i) = toc;
  tic, y_ = u2y(BT, q, u(1:T, :), wini); tn_u2y(i) = toc;
  en(i) = norm(y - y_) / norm(y);
end

figure(1) 
plot(TT, t_lsim, 'r-'), hold on, plot(TT, t_u2y, 'b--')
xlabel('$T$'), ylabel('computation times, sec')
legend('lsim', 'u2y', 'location', 'northwest')
print_fig('bt-f-lsim-cost')

figure(2) 
plot(NN, tn_lsim, 'r-'), hold on, plot(NN, tn_u2y, 'b--')
xlabel('$n$'), ylabel('computation times, sec')
legend('lsim', 'u2y', 'location', 'northwest')
print_fig('bt-f-lsim-cost-n')

figure(3), 
plot(TT, e(1:np))
xlabel('$T$'), ylabel('relative error $e$')
print_fig('e')

figure(4), 
plot(NN, en(1:np))
xlabel('$n$'), ylabel('relative error $e$')
print_fig('en')
