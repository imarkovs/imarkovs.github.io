function [IO_possible, IO_impossible] = BT2IO(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
IO = flipud(perms(1:q)); possible = []; impossible = []; 
for i = 1:size(IO, 1)
  if is_io(BT, q, IO(i, :), ctol), 
    possible = [possible; i]; 
  else 
    impossible = [impossible; i]; 
  end
end
IO_possible   = IO(possible, :); 
IO_impossible = IO(impossible, :);
