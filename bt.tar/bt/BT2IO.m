function [io, IO_possible, IO_impossible] = BT2IO(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if ~exist('c', 'var'), [c, m, ell, n] = BT2c(BT, q, ctol); end
T = 2 * ell + 1; BT = BT2BT(BT, q, T);
IO = flipud(perms(1:q)); possible = []; impossible = []; 
for i = 1:size(IO, 1)
  if is_io(BT, q, IO(i, :), c), 
    possible = [possible; i]; 
    if nargout == 1, io = IO(possible, :); disp('pass'), return, end
  else 
    impossible = [impossible; i]; 
  end
end
IO_possible   = IO(possible, :); io = IO(possible(1), :);
IO_impossible = IO(impossible, :);
