clear all, clc, echo on

%% Simulation parameters
q = 3; m = 1; ell = 2; n = 3; % complexity 
Td = 20;                      % # of samples

%% Generate random system and trajectory
Rp = randB(q, [m, ell, n]); 
wd = R2w(Rp, q, Td);

%% Finding the number of inputs from wd
[~, mh, ellh, nh] = w2c(wd);
[m == mh, ell == ellh, n == nh] % -> [true true true]

pause

%% Finding an input/output partitioning of the variables
[~, IO] = BT2IO(w2BT(wd, ell + 1, [m ell n]), q); IO 
ud = wd(:, IO(1, 1:m)); yd = wd(:, IO(:, m+1:end));

pause

%% The data-generating system may be unstable (but it's OK)
[B, io] = R2ss(Rp, q); any(abs(eig(B)) > 1) % -> true
T = 300; u = rand(T, m); y = lsim(B, u, [], rand(n, 1)); w = [u y]; max(w(:)) % -> large
w = R2BT(Rp, q, T) * rand(m * T + n, 1); max(w) % -> small

pause

%% Distance of a signal to a system
dist(wd, B) % -> 0
wn = randn(size(wd)); wd_noisy = wd + 0.1 * norm(wd) * wn / norm(wd);
[d, wdh] = dist(wd_noisy, B);
100 * [norm(wd - wd_noisy) norm(wd - wdh)] / norm(wd)

pause

%% Distance between systems
Bp = ss2ss(B, rand(n));
try 
    B == Bp % -> Operator '==' is not supported for operands of type 'ss'.
catch me, me, end
norm(Bp - B) % -> Inf
Bdist(Bp, B) % -> 0

echo off
