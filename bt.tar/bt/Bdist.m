function [d, B1T, B2T] = Bdist(B_or_BT1, B_or_BT2, q, T)
if ~exist('T', 'var') || isempty(T), T = 100; end % <default-horizon>
if  isa(B_or_BT1, 'ss'), q = sum(size(B_or_BT1)); B1T = B2BT(B_or_BT1, T); end
if  isa(B_or_BT2, 'ss'), q = sum(size(B_or_BT2)); B2T = B2BT(B_or_BT2, T); end
if ~isa(B_or_BT1, 'ss'), B1T = BT2BT(B_or_BT1, q, T); end 
if ~isa(B_or_BT2, 'ss'), B2T = BT2BT(B_or_BT2, q, T); end
d = subspace(B1T, B2T);
