clear all, clc, echo on
%% Identification

ex = 'complex'; opt = '';
%% <test-examples>
switch ex
  case{'static'},     m = 1; ells = 0;            
  case{'scalar'},     m = 0; ells = 1;
  case{'siso'},       m = 1; ells = 2;            
  case{'mimo'},       m = 3; ells = [1 2 3];        
  case{'aut-mo'},     m = 0; ells = [1 2];        
  case{'descriptor'}, m = 1; ells = [0 3];    
  case{'complex'},    m = 2; ells = [0 1 2 2 3]; 
end
p = length(ells); q = m + p; 
Rp = randB(q, ells, strcat('ells', opt)); 
c = ells2c(ells, q); ell = c(2); n = c(3);
T = 100; BT = R2BT(Rp, q, T, c);
e = @(BTh) Bdist(BT, BTh, q); 

%% signle run
Td = 100; wd0 = R2w(Rp, q, Td, c); 
rank(hank(wd0, ell+1)) == m * (ell+1) + n
tic, Rh = w2Rp(wd0);             t_bt1 = toc; e_bt1 = e(R2BT(Rh, q, T, c));
tic, Bh = w2ss(wd0, [], c);      t_bt2 = toc; e_bt2 = e(Bh);
tic, Bh = w2ss(wd0);             t_bt3 = toc; e_bt3 = e(Bh);
tic, Bh = w2ss_n4sid(wd0, m, n); t_n4  = toc; e_n4  = e(Bh);
[e_bt1 t_bt1; 
 e_bt2 t_bt2; 
 e_bt3 t_bt3; 
 e_n4  t_n4]

wn = randn(size(wd0)); wd = wd0 + 0.01 * norm(wd0) * wn / norm(wn);
tic, Rh = w2R(wd, c);    toc, BTh = R2BT(Rh, q, T, c); e(BTh)
tic, Rh = w2Rp(wd, ell); toc, BTh = R2BT(Rh, q, T, c); e(BTh)

%% Monte-Carlo
Td = 100; wd0 = R2w(Rp, q, Td, c); 
mc = 10;  np = 10; S = linspace(0, 0.1, np); 
for j = 1:np, j = j
  for i = 1:mc
    wn = randn(size(wd0)); wd = wd0 + S(j) * norm(wd0) * wn / norm(wn);
    Rh = w2R(wd, c);     BTh = R2BT(Rh, q, T, c); e1(i, j) = e(BTh);
    Rh = w2Rp(wd, ells); BTh = R2BT(Rh, q, T, c); e2(i, j) = e(BTh);
  end
end

echo off

plot(S, mean(e1), 'r'), hold on, 
plot(S, mean(e2), 'b--')
xlabel('noise level, $s$'), ylabel('distance measrue, $e$')
legend('using compleaxity', 'using full lag structure', 'location', 'northwest')
print_fig('w2r')
