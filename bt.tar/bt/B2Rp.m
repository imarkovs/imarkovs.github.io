function [Rp, ells] = B2Rp(B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[c, m, ell, n] = ss2c(B, tol);
[Rp, ells] = BT2Rp(B2BT(B, ell+1, tol), sum(size(B), c);
