function [Rp, ells] = B2Rp(B)
[Rp, ells] = BT2Rp(B2BT(B, lag(B)+1), sum(size(B)));
