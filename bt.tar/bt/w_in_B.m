function ans = w_in_B(w, B_or_BT, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if iscell(w)
  for i = 1:length(w), ans(i) = w_in_B(w{i}, B_or_BT, tol); end
else
  ans = dist(w, B_or_BT) < tol;
end
