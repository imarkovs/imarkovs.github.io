function C = convm(H_or_B, T)
if isa(H_or_B, 'ss'), B = H_or_B; h = impulse(B, T - 1); 
  [p, m] = size(B); if m == 0, C = zeros(p * T, 0); return, end;   
else, h = H_or_B;
  if length(size(h)) == 3, [TT, p, m] = size(h); else, p = 1; m = 1, end
end
C = zeros(p * T, m * T); 
if m > 1, H = zeros(T * p, m);
  for i = 1:T, H((i - 1) * p + 1:i * p, :) = reshape(h(i, :, :), p, m); end
else, H = vec(h'); end
for i = 1:T
  C((i - 1) * p + 1:end, (i - 1) * m + 1:i * m) = H(1:(T - i + 1) * p, :);
end
