function BT = B2BT(B, T, tol); 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[c, m, ell, n] = ss2c(B, tol); [p, m] = size(B); q = m + p;
Tmin = ell + 1; O = B.c; H = B.d; C = zeros(p * Tmin, m * Tmin); 
for i = 2:Tmin
  O = [O; O(end-p+1:end, :) * B.a]; H = [H; O(end-2*p+1:end-p, :) * B.b];
end
for i = 1:Tmin 
  C((i - 1) * p + 1:end, (i - 1) * m + 1:i * m) = H(1:(Tmin - i + 1) * p, :);
end
BTmin = uy2w([zeros(m * Tmin, size(O, 2)) eye(m * Tmin); O C], m, p);
[~, R] = lra(BTmin, ctol2rtol(c, Tmin)); BT = R2BT(R, q, T, c);
