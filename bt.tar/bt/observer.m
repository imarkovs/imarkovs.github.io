clear all, clc, echo on
%% Missing input recovery

m_missing = 1; m_given = 1; m = m_missing + m_given; p = 2; n = 3; 
B = drss(n, p, m); q = m + p;

T = 10; w0 = B2w(B, T); 
w0_missing = w0(:, 1:m_missing); w0_given = w0(:, m_missing+1:end);

BT = ss2BT(B, T);

[BT_missing, BT_given] = BT2UYT(BT, m_missing, m_given + p);

rank(BT_given) == T * m + n % -> 1

wh_missing = BT_missing * pinv(BT_given) * vec(w0_given');
wh_missing = reshape(wh_missing, m_missing, T)';

e = norm(w0_missing - wh_missing) / norm(w0_missing) % -> 1e-15

echo off
