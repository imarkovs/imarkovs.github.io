function B = msd(theta)
m = theta(1); c = theta(2); k = theta(3);
ts = 2 * pi / sqrt(k / m) / 40; % sampling time based on natural frequency
B = c2d(ss([0 1; -k / m, -c / m], [0; 1 / m], [1 0], 0), ts, 'zoh');
