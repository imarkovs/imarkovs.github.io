function Hz = BT2Hz(BT, q, z, ctol) 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
[c, m] = BT2c(BT, q, ctol); p = q - m; 
T = size(BT, 1) / q; t = (1:T)'; 
[UT, YT] = BT2UYT(BT, m, p); P = [UT; YT];
for k = 1:length(z)
  A  = [[zeros(m * T, p); -kron(z(k) .^ t, eye(p))] P];
  hg = pinv(A, tol) * [kron(z(k) .^ t, eye(m)); zeros(p * T, m)]; 
  Hz(:, :, k) = hg(1:p, :); 
end
