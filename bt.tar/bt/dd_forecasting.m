clear all, clc, echo on
%% Direct data-driven forecasting

load robot_arm.dat, m = 1; p = 1; q = m + p; n = 8;

Tv = 10; Td = size(robot_arm, 1) - Tv;
wd = robot_arm(1:Td, :); wv = robot_arm(Td+1:end, :);
Tini = n; w_ini = wd(end - Tini + 1:end, :);

tic, BT = w2BT(wd, Tini + Tv, [m, n, n]);  t_w2BT = toc % direct method
tic, BT = R2BT(w2R(wd, [m, n, n]), q, Tini + Tv); t_w2R2BT = toc

tic, yh_dd = u2y(BT, q, wv(:, 1:m), w_ini); t_u2y = toc

tic, Bh = n4sid(iddata(wd(:, m+1:end), wd(:, 1:m)), n); t_n4sid = toc
tic, f = forecast(Bh, iddata(w_ini(:, m+1:end), w_ini(:, 1:m)), Tv, wv(:, 1:m)); 
     yh_mb = f.OutputData; t_forecast = toc

e = @(yh) 100 * norm(wv(:, m+1:end) - yh) / norm(wv(:, m+1:end)); 
[t_w2R2BT + t_u2y,      e(yh_dd); % ->    0.0284    1.9114
 t_n4sid  + t_forecast, e(yh_mb)] % ->    1.6709    1.8803

echo off
