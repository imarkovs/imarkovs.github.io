function rtol = ctol2rtol(ctol, T, opt, q)
if length(ctol) == 1, rtol = ctol; return, end % tolerance specification
%% complexity specification 
[m, ell, n] = unpack_c(ctol);
if exist('opt', 'var') && contains(opt, 'B0'), rtol = m * T; % for BT2B0
else, rtol = m * T + n; end % rank for the primal problem
if exist('opt', 'var') && contains(opt, 'dual'), 
  rtol = q * T - rtol;      % rank for the dual problem
end
