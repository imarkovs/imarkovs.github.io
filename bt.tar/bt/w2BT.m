function [BT, c] = w2BT(wd, T, ctol) 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if length(ctol) == 3 % ctol specifies complexity
  c = ctol; [m, ell, n] = unpack_c(c); r = m * T + n;  
else, r = ctol; end  % the complexity has to be estimated
BT = lra(hank(wd, T), r);
