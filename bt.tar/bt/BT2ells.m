function ells = BT2ells(BT, q, tol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
T = size(BT, 1) / q; d_ = 0; dd_ = q; ells = []; 
for t = 1:T 
  d = rank(BT(1:q*t, :), tol); dd = d - d_;
  if dd_ - dd, ells = [ells, (t-1) * ones(1, dd_ - dd)]; dd_ = dd; end
  d_ = d;
end
