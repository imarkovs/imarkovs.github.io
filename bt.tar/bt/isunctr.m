function n_unctr = isunctr(BT_or_R, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if size(BT_or_R, 2) < size(BT_or_R, 1)
  BT = BT_or_R; % the given representation is BT
  [BC, c] = BT2BC(BT, q, ctol); T = size(BC, 1) / q;
  n_unctr = ctol2rtol(c, T) - size(BC, 2);
else
  R = BT_or_R;  % the given representation is R
  [R, ells] = R2Rp(R, q, ctol); [c, m, ell, n] = ells2c(ells. q);
  M = R2M(R, q, 2 * ell + n); Mc = M(:, q * ell + 1:(q + n) * ell);
  n_unctr = size(Mc, 2) - rank(Mc, tol);
end
