function [B, wdh] = w2ss_n4sid(wd, m, n)
if ~exist('n', 'var'), n = []; end; q = size(wd, 2); ud = wd(:, 1:m); yd = wd(:, m+1:end);
opt = n4sidOptions('EnforceStability', false, 'EstimateCovariance', false);
[B, x0] = n4sid(iddata(yd, ud), n, 'Feedthrough', true(1, m), 'DisturbanceModel', 'none', opt);
if nargout == 2, yh = lsim(B, ud, x0); wdh = [ud yh]; end, B = ss(B);
