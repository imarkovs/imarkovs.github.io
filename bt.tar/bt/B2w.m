function w = B2w(B, T)
BT = B2BT(B, T); w = reshape(BT * rand(size(BT, 2), 1), [], T)';
