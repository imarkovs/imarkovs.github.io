function w = B2w(B, T)
[p, m] = size(B); q = m + p; BT = B2BT(B, T); 
w = reshape(BT * rand(size(BT, 2), 1), q, T)';
