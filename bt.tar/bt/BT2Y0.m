function Y0 = BT2Y0(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
[c, m, ell, n] = BT2c(BT, q, ctol);
[UT, YT] = BT2UYT(BT, m, q - m); Y0 = YT * null(UT, tol);
