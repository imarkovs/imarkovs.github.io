%% Test suite for the Behavioral Toolbox
clear all, clc, 
ex  = 'descriptor'; opt = 'stable'; tol = 1e-8;
%% <test-examples>
switch ex
  case{'static'},     m = 1; ells = 0;            
  case{'scalar'},     m = 0; ells = 3;
  case{'siso'},       m = 1; ells = 5;            
  case{'mimo'},       m = 3; ells = [1 2 3]';
  case{'aut-mo'},     m = 0; ells = [1 2]';        
  case{'descriptor'}, m = 1; ells = [0 3]';    
  case{'complex'},    m = 2; ells = [0 1 2 2 3]'; 
end
p = length(ells); q = m + p; 
Rp = randB(q, ells, opt); 
c = ells2c(ells, q); ell = c(2); n = c(3);

%% R2BT and BT2BT
T = 100; BT = R2BT(Rp, q, T); BTmin = R2BT(Rp, q, ell+1);
check(size(BT, 2) == m * T + n, 'R2BT, size BT')
check(equal(BTmin, BT2BT(BT, q, ell+1), q), 'BT2BT, restriction')
check(equal(BT2BT(BTmin, q, T), BT, q), 'BT2BT, extension')

%% BT2R, BT2Rp, R2Rp, BT2ss, R2ss
R = BT2R(BTmin, q);        check(equal(BTmin, R2BT(R, q, T), q), 'BT2R')
Rp_ = BT2Rp(BTmin, q);     check(equal(BTmin, R2BT(Rp_, q, T), q), 'BT2Rp')
Rp_ = R2Rp(R, q);          check(equal(BTmin, R2BT(Rp_, q, T), q), 'R2Rp')
[B, io] = BT2ss(BTmin, q); check(equal(BTmin, B), 'BT2ss')
[B, io] = R2ss(R, q);      check(equal(BTmin, B), 'R2ss, R')
[B, io] = R2ss(Rp, q);     check(equal(BTmin, B), 'R2ss, Rp')

%% Analysis
[ch, mh, ellh, nh] = BT2c(BTmin, q); check(all([mh ellh nh] == [m ell n]), 'BT2c')
ellh = lag(B);                       check(ellh == ell, 'lag')
ellsh = BT2ells(BT, q);              check(all(ellsh == ells), 'BT2ells')
Bp = ss2ss(B, rand(n));              check(equal(B, Bp), 'equal')

%% Input/output partitionings
io = flip(1:q); BTp = BT2BT(BT, q, io); w = R2w(Rp, q, T);
check(w_in_B(w(:, io), BTp), 'BT2BT(BT, q, io)')
[UT, YT] = BT2UYT(BT, m, p);
check(norm(BT - UYT2BT(UT, YT, m, p)) == 0, 'UYT2BT')

%% Subbehaviors
Y0 = BT2Y0(BT, q);
U0 = BT2U0(BT, q);
B0 = BT2B0(BT, q);
BC = BT2BC(BT, q);
[HT, Tp] = BT2HT(BT, q);

y0 = initial(B, rand(n, 1), T-1); check(w_in_B(y0, Y0), 'BT2Y0')

u0 = reshape(U0 * rand(size(U0, 2), 1), m, T)';
w0 = [u0 zeros(T, p)]; check(w_in_B(w0, BT), 'BT2U0')

T0 = size(B0, 1) / q;
w0 = reshape(B0 * rand(size(B0, 2), 1), q, T0)'; 
xini = w2xini(w0, B); check(norm(xini) < tol, 'w2xini')

check(norm(HT - convm(B, Tp)) < tol, 'BT2HT')

%% Signal processing and open-loop control
[d, wh] = dist(w, B);
[xini, e] = w2xini(w, B); u = w(:, 1:m); y = w(:, m+1:end);
check(norm(y - lsim(B, u, [], xini)) < tol, 'w2xini')

BT = B2BT(B, ell+T);
[wini, e] = w2wini(w, BT, ell); check(w_in_B([wini; w], B), 'w2wini')

yf = u2y(BT, q, w(:, 1:m), wini); check(norm(w(:, m+1:end) - yf) < tol, 'u2y')

Tf = 3; u1 = zeros(Tf, m); u1(1) = 1;
h1 = u2y(BT, q, u1, zeros(ell, q)); h = lsim(B, u1); 
check(norm(h1 - h) < tol, 'u2y, impulse response estimation')

%% Identification
ch = w2c(w); check(all(ch == c), 'w2c')
Bh = w2BT(w, ell+1); check(equal(BTmin, Bh, q), 'w2BT')
Rh = w2R(w, c); check(equal(BTmin, R2BT(Rh, q, ell+1), q), 'w2R')
Rph = w2Rp(w); check(equal(BTmin, R2BT(Rph, q, ell+1), q), 'w2Rp')
