%% Tutorial for the Behavioral Toolbox
clear all
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>

ex  = 'descriptor'; opt = '';
%% <test-examples>
switch ex
  case{'static'},     m = 1; ells = 0;            
  case{'scalar'},     m = 0; ells = 1;
  case{'siso'},       m = 1; ells = 2;            
  case{'mimo'},       m = 3; ells = [1 2 3];        
  case{'aut-mo'},     m = 0; ells = [1 2];        
  case{'descriptor'}, m = 1; ells = [0 3];    
  case{'complex'},    m = 2; ells = [0 1 2 2 3]; 
end
p = length(ells); q = m + p; 
Rp = randB(q, ells, strcat('ells', opt)); 
c = ells2c(ells, q); ell = c(2); n = c(3);

%% Finite-horizon behavior

T = 10; BT = R2BT(Rp, q, T);

check(size(BT, 2) == m * T + n, 'R2BT, size BT')

w = R2w(Rp, q, T); check(w_in_B(w, BT), 'R2BT + R2w + w_in_B')

W = BT2W(BT, q); check(all(w_in_B(W, BT)), 'R2BT + BT2W + w_in_B')

BTmin = R2BT(Rp, q, ell + 1);
check(equal(BTmin, BT2BT(BT, q, ell + 1), q), 'BT2BT, restriction')
check(equal(BT2BT(BTmin, q, T), BTmin, q), 'BT2BT, extension')

%% Parametric representations

R_ = BT2R(BT, q); check(equal(BT, R2BT(R_, q, T), q), 'BT2R')

Rp_ = BT2Rp(BT, q); check(equal(BT, R2BT(Rp_, q, T), q), 'BT2Rp + R2BT')
Rp_ = R2Rp(R_, q);  check(equal(BT, R2BT(Rp_, q, T), q), 'R2Rp + R2BT')

B = R2ss(Rp, q); check(equal(B, BT), 'R2ss')

B = BT2ss(BT, q); check(equal(B, BT), 'BT2ss')

%% Input/output partitionings

io = flip(1:q); BTp = BT2BT(BT, q, io);

check(w_in_B(w(:, io), BTp), 'BT2BT(BT, q, io)')

[UT, YT] = BT2UYT(BT, m, p);

check(norm(BT - UYT2BT(UT, YT, m, p)) == 0, 'UYT2BT')

%% Subbehaviors

Y0 = BT2Y0(BT, q);
U0 = BT2U0(BT, q);
B0 = BT2B0(BT, q);
BC = BT2BC(BT, q);

y0 = initial(B, rand(n, 1), T-1); check(w_in_B(y0, Y0), 'BT2Y0')

u0 = reshape(U0 * rand(size(U0, 2), 1), m, T)';
w0 = [u0 zeros(T, p)]; check(w_in_B(w0, BT), 'BT2U0')

T0 = size(B0, 1) / q;
w0 = reshape(B0 * rand(size(B0, 2), 1), q, T0)'; 
xini = w2xini(w0, B); check(norm(xini) < tol, 'w2xini')

[HT, T] = BT2HT(BT, q);

check(norm(HT - convm(B, T)) < tol, 'BT2HT')

%% Analysis

[ch, mh, ellh, nh] = BT2c(BT, q); check(all([mh ellh nh] == [m ell n]), 'BT2c')

ellh = lag(B); check(ellh == ell, 'lag')

ellsh = BT2ells(BT, q); check(all(ellsh == ells), 'BT2ells')

Bp = B; Bp.a = Bp.a + 0.01 * randn(n); d = Bdist(B, Bp);

Bp = ss2ss(B, rand(n)); check(equal(B, Bp), 'equal')

%% Signal processing and open-loop control

[d, wh] = dist(w, B);

[xini, e] = w2xini(w, B); u = w(:, 1:m); y = w(:, m+1:end);
check(norm(y - lsim(B, u, [], xini)) < tol, 'w2xini')

BT = B2BT(B, ell + size(w,1));
[wini, e] = w2wini(w, BT, ell); check(w_in_B([wini; w], B), 'w2wini')

yf = u2y(BT, q, w(:, 1:m), wini); check(norm(w(:, m+1:end) - yf) < tol, 'u2y')

Tf = 3; u1 = zeros(Tf, m); u1(1) = 1;
h1 = u2y(BT, q, u1, zeros(ell, q)); h = lsim(B, u1); 
check(norm(h1 - h) < tol, 'u2y, impulse response estimation')

%% Identification

Td = 100; wd = B2w(B, Td);

ch = w2c(wd); check(all(ch == c), 'w2c')

BhT = w2BT(wd, T);

Rh = w2R(wd);   BTh = R2BT(Rh, q, Td);  check(w_in_B(wd, BTh), 'w2R + w_in_B')
Rph = w2Rp(wd); BTh = R2BT(Rph, q, Td); check(w_in_B(wd, BTh), 'w2Rp + w_in_B')
