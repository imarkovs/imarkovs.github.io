function [c, m, ell, n] = BT2c(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if length(ctol) == 3, c = ctol; [m, ell, n] = unpack_c(c); % nothing to do
else, tol = ctol; 
  T = size(BT, 1) / q; 
  r1 = rank(BT, tol); r2 = rank(BT(1:q * (T - 1), :), tol); 
  mn = [T 1; T-1 1] \ [r1; r2]; m = round(mn(1)); n = round(mn(2));
  if n > 0,
    for ell = 1:n,
      if rank(BT(1: q * ell, :), tol) == m * ell + n, break, end, 
    end
  else, ell = 0; end
  c = [m, ell, n];
end
