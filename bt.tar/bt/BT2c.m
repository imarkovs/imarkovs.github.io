function [c, m, ell, n] = BT2c(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if length(ctol) == 3, c = ctol; [m, ell, n] = unpack_c(c); % nothing to do
else 
  T = size(BT, 1) / q; 
  r1 = rank(BT, tol); r2 = rank(BT2BT(BT, q, T - 1, tol), tol); 
  mn = [T 1; T-1 1] \ [r1; r2]; m = round(mn(1)); n = round(mn(2));
  if n > 0,
    for ell = 1:n,
      if rank(BT2BT(BT, q, ell, tol), tol) == m * ell + n, break, end, 
    end
  else, ell = 0; end
  c = [m, ell, n];
end
