function [d, wh] = dist(w_or_B, B_or_BT, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if isa(w_or_B, 'ss') % distance between systems
  d = Bdist(w_or_B, B_or_BT, ctol); 
else, w = w_or_B;    % distance from signal to system          
  if iscell(w)
    for i = 1:length(w), 
      [d(i) wh{i}] = dist(w{i}, B_or_BT, ctol);
    end
  else
    [T, q] = size(w); 
    if isa(B_or_BT, 'ss'), BT = B2BT(B_or_BT, T); 
    else, BT = BT2BT(B_or_BT, q, T, ctol); end
    wh = ProjBT(w, BT); d = norm(w - wh, 'fro');
  end
end
