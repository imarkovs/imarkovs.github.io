function BT = ss2BT(B, T, tol); 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
BT = B2BT(B, T, tol);
