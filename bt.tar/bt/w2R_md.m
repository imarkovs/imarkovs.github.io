function [R, status] = w2R_md(wd, ctol, ell_max) 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
[Td, q] = size(wd); R = {};
if ~exist('ell_max', 'var'), ell_max = floor((Td + 1) / (q + 1)) - 1; end
if ~exist('c', 'var'), status = 'unknown'; ell_min = 1; check = 0;
else,                  status = 'failed';  ell_min = ell + 1; check = 1; end
for L = ell_min:ell_max
  RL = lker_md(hank(wd, L), q, ctol2rtol(ctol, L)); 
  if ~isempty(RL), R = [R; RL]; end, R_ = Rp2R(R, q);
  if check && rank(R_) >= ctol2rtol(c, L, 'dual', q)
    status = 'success'; break 
  end
end
R = R_; if isempty(R), status = 'fail';
elseif check, R = lra(R, ctol2rtol(c, L, 'dual', q), 'dual'); end
