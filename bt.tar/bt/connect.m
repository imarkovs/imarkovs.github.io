function R = connect(R, q, v)
N = length(R); Rapp = R{1}; qapp = q(1);
for i = 2:N
  Rapp = Rappend(Rapp, qapp, R{i}, q(i)); qapp = qapp + q(i); 
end
sq = cumsum([0 q]); k = size(v, 1); Rint = zeros(k, qapp);
for i = 1:k 
  Rint(i, [sq(v(i, 1)) + v(i, 2), sq(v(i, 3)) + abs(v(i, 4))]) = [1 sign(v(i, 4))];
end
R = [Rapp; multmat(Rint, qapp, size(Rapp, 2) / qapp)];
