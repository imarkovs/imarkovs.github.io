function [Hinf, HT, uinf] = BT2Hinf(BT, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
HT = BT2HT(BT, q, ctol); 
[u, s, v] = svd(HT); Hinf = s(1); uinf = v(:, 1);
