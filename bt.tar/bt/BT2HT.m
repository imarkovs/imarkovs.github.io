function [HT, T] = BT2HT(BT, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
[c, m] = BT2c(BT, q, ctol); p = q - m;
[U0, Y0] = BT2UYT(BT2B0(BT, q, ctol), m, p);
HT = Y0 * pinv(U0, tol); T = size(Y0, 1) / p;
