% BT - Behavioral Toolbox
%
% - Examples
%    observer	          missing input estimation
%    smoothing	          errors-in-variables smoothing
%    dd_forecasting	  data-driven forecasting
%    interconnection	  interconnection as variables sharing
%    controllability	  distance to uncontrollability
%    sysid_with_structure system identification with predefined structure
%    sysid_missing_data	  system identification from data with missing values
%
% - Nonparametric representation of the finite-horizon behavior
%    R2BT          kernel representation to finite-horizon representation      
%    ss2BT / B2BT  state-space representation to finite-horizon representation 
%    BT2BT         change horizon or permute variables
%    BT2W          convert the basis =BT= into a set of trajectories (cell array)
%
% - Kernel and state-space representations
%    BT2R           finite-horizon representation to kernel representation                          
%    ss2R / B2R     state-space representation to kernel representation                             
%    BT2ss          finite-horizon representation to state-space representation                     
%    R2ss           kernel representation to state-space representation                             
%    BT2Rp          finite-horizon representation to shortest-lag kernel representation             
%    R2Rp and Rp2R  conversion between kernel representation and shortest-lag kernel representation 
%    B2Rp           state-space representation to shortest-lag kernel representation
%
% - Input/output partitioning
%    BT2UYT  extract the finite-horizon behaviors of the input and the output                                      
%    UYT2BT  reconstruct the finite-horizon behavior from the input/output behaviors
%    is_io   check if a partitioning of the variables is a possible input/output partitioning                      
%    BT2IO   find all input/output partitionings of the variables
%
% - Subbehaviors
%    BT2Y0 and ss2Y0  zero input subbehavior                                     
%    BT2U0            zero output subbehavior                                    
%    BT2B0            zero initial conditions subbehavior                        
%    BT2HT and ss2HT  zero initial conditions finite-horizon input-to-output map 
%    BT2BC            controllable subbehavior
%
% - Analysis
%    ells2c and c2ells  conversion between complexity and lag structure                            
%    lag / ss2ell       find the lag of a system given by a state-space representation             
%    ss2c               find the complexity of a system given by a state-space representation      
%    BT2c               find the complexity from the finite-horizon behavior                       
%    BT2ells            find the lag structure from the finite-horizon behavior                    
%    Rp2ells            find the lag structure from a shortest-lag kernel representation           
%    is_lti             check if a finite-horizon behavior represents a bounded complexity LTI system 
%    dist_lti           distance to the set of bounded complexity LTI systems                      
%    Bdist              distance between two systems                                               
%    equal              check if two systems are equal                                             
%    isunctr            check controllability                                                      
%    distunctr          distance to uncontrollability                                              
%    BT2Hinf            finite-horizon H-infty norm                                                
%    BT2Hz              transfer function evaluation
%
% - Signal processing and open-loop control
%    B2w              select random trajectory of system specified by state-space representation      
%    R2w              select a bounded trajectory of system specified by kernel representation 
%    dist             distance from trajectory to system                                              
%    w_in_B           check if signal is trajectory of a system                                       
%    w2xini           find initial state for future trajectory                                        
%    w2wini           find initial trajectory for future trajectory                                   
%    u2y              simulation                                                                      
%    B2h              impulse response computation                                                    
%    wgiven2wmissing  estimation of missing variables                                                 
%    lqctr            open-loop linear-quadratic tracking control
%
% - System identification
%    w2c   complexity of the most powerful unfalsified model    
%    w2BT  finite-horizon behavior from a trajectory         
%    w2R   kernel representation from a trajectory              
%    w2Rp  shortest-lag kernel representation from a trajectory
%    w2ss  state-space representation from a trajectory
%
% - Auxiliary functions
%    hank             mosaic Hankel matrix
%    R2M              multiplication matrix
%    randB            random LTI systems with presctibed lag structure or complexity 
%    uy2w and w2uy    row permutation reordering variables from $(u,y)$ to $w$ and back
%    obsvm            extended observability matrix
%    convm            convolution matrix
%    in_rspan         check if vector(s) are in the rowspan of a matri
%    is_subspace      check if image A is a subset of imageB
%
% - Interconnection of systems
%    BTappend  append one finite-horizon behavior to another      
%    Rappend   append one kernel representation to another        
%    connect   interconnection of systems                         
%    BTselect  projection of the behavior on a subset of variable
%
