function [OK, io] = is_io(BT, q, io, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if ~exist('c', 'var'), [c, m, ell, n] = BT2c(BT, q, ctol); end
p = q - m; T = 2 * ell + 1; BT = BT2BT(BT, q, T, c);
BTp = BT(1:q * ell, :); BTf = BT(q * ell + 1:end, :);
UTf = BT2UYT(BT2BT(BTf, q, io), m, p);
OK = rank([BTp; UTf], tol) == m * T + n;
if ~OK && nargout == 2, io = BT2IO(BT, q, c); end
