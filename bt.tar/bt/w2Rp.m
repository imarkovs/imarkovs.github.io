function [Rp, ells] = w2Rp(w, ell_max, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~iscell(w), [T, q] = size(w); else, [T, q] = size(w{1}); end 
if ~exist('ell_max', 'var') || isempty(ell_max)
  ell_max = floor((T + 1) / (q + 1)); 
end
m = q; p = 0; ells = []; Rp = {};
for L = 1:ell_max+1
  H = hank(w, L);
  if rank(H, tol) < m * L + sum(ells) 
    N = null(H', tol)'; Np = R2M(Rp, q, L); 
    if isempty(Np), Rnew = N; else, Rnew = perp(Np / N) * N; end
    if ~isempty(Rnew),
      Rp = [Rp; Rnew]; ells = [ells (size(Rnew, 2) / q - 1) * ones(1, size(Rnew, 1))];
      p = p + size(Rnew, 1); m = m - size(Rnew, 1); 
    end
  end
end
