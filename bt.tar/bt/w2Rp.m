function [Rp, ells] = w2Rp(wd, ellsctol, ell_max)
if ~iscell(wd), q = size(wd, 2); else, q = size(wd{1}, 2); end
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ellsctol>
if exist('ellsctol', 'var') && ~isempty(ellsctol)
  if (ellsctol(1) > 0 && ellsctol(1) < 1), tol = ellsctol; ctol = tol;
  elseif all(size(ellsctol) == [1 3])
     c = ellsctol; [m, ell, n] = unpack_c(c); ctol = c;
  else, ells = ellsctol; [c, m, ell, n] = ells2c(ells, q); ctol = c; end
else, ellsctol = tol; ctol = tol; end
if exist('ells', 'var') 
  LL = unique(ells); LL = vec(LL + 1)';
else
  if ~exist('ell_max', 'var')
    %% <find-ell_max>
    if ~iscell(wd) % one trajectory
      [Td, q] = size(wd); ell_max = floor((Td + 1) / (q + 1)) - 1; 
    else           % multiple trajectories
      N = length(wd); for i = 1:N, [Td(i), q] = size(wd{i}); end
      Td = [sort(Td, 'descend') 0];
      for i = 1:N  
        ell_max = floor((sum(Td(1:i)) + i) / (q + i)) - 1; 
        if (Td(i + 1) < ell_max + 1), break, end
      end
    end
  end
  ells_ = []; LL = 1:ell_max+1; rtol = tol; 
end
Rp = {}; 
for L = LL
  if ~isempty(Rp), R_perp = perp(R2M(Rp, q, L), tol);
  else,            R_perp = eye(q * L); end
  if exist('ells', 'var'),  rtol = size(R_perp, 1) - sum(L-1 == ells); 
  elseif exist('c', 'var'), rtol = ctol2rtol(c, L); end
  [~, Z] = lra(R_perp * hank(wd, L), rtol);
  if ~isempty(Z) 
    Rnew = Z * R_perp; Rp = [Rp; Rnew]; 
    if ~exist('ells', 'var')
      ells_ = [ells_; (L-1) * ones(size(Rnew, 1), 1)];
    end
  end  
end
if ~exist('ells', 'var'), ells = ells_; end
