clear all, ex = 'complex';
%% <test-examples>
switch ex
  case{'static'},     m = 1; ells = 0;            
  case{'scalar'},     m = 0; ells = 1;
  case{'siso'},       m = 1; ells = 2;            
  case{'mimo'},       m = 3; ells = [1 2 3];        
  case{'aut-mo'},     m = 0; ells = [1 2];        
  case{'descriptor'}, m = 1; ells = [0 3];    
  case{'complex'},    m = 2; ells = [0 1 2 2 3]; 
end
p = length(ells); q = m + p; 
Rp = randB(q, ells, strcat('ells', opt)); 
c = ells2c(ells, q); ell = c(2); n = c(3);
R = Rp2R(Rp, q); R = rand(size(R, 1)) * R;

[Rp_, ells_] = R2Rp(R, q); all(ells == ells_)      % -> true
Bdist(R2BT(Rp, q, ell + 1), R2BT(Rp_, q, ell + 1)) % -> 0

[Rp_, ells_] = R2Rproper(R, q, p); all(ells == ells_) 
Bdist(R2BT(Rp, q, ell + 1), R2BT(Rp_, q, ell + 1)) 

return

addpath ~/mfiles/misc/polyx
[Rp_, ells_] = R2Rp_polyx(R, q); all(ells == ells_) 
Bdist(R2BT(Rp, q, ell + 1), R2BT(Rp_, q, ell + 1))
