clear all; ex = 'descriptor';
%% <test-examples>
switch ex
  case{'static'},     m = 1; ells = 0;            
  case{'scalar'},     m = 0; ells = 1;
  case{'siso'},       m = 1; ells = 2;            
  case{'mimo'},       m = 3; ells = [1 2 3];        
  case{'aut-mo'},     m = 0; ells = [1 2];        
  case{'descriptor'}, m = 1; ells = [0 3];    
  case{'complex'},    m = 2; ells = [0 1 2 2 3]; 
end
p = length(ells); q = m + p; 
Rp = randB(q, ells, strcat('ells', opt)); 
c = ells2c(ells, q); ell = c(2); n = c(3);
T = 100; BT = R2BT(Rp, q, T, c);
e = @(BTh) Bdist(BT, BTh); 

%% signle run
Td = 20; wd0 = R2w(Rp, q, Td, c); 

Rh = w2Rp(wd0);  BTh = R2BT(Rh, q, T, c); e(BTh)
Rh = w2Rp_(wd0); BTh = R2BT(Rh, q, T, c); e(BTh)

wn = randn(size(wd0)); wd = wd0 + 0.01 * norm(wd0) * wn / norm(wn);
Rh = w2R(wd, c);    BTh = R2BT(Rh, q, T, c); e(BTh)
Rh = w2R(wd, ells, 'ells'); BTh = R2BT(Rh, q, T, c); e(BTh)

%% Monte-Carlo
Td = 20; wd0 = R2w(Rp, q, Td, c); 
mc = 100; np = 10; S = linspace(0, 0.1, np); 
for j = 1:np, j = j
  for i = 1:mc
    wn = randn(size(wd0)); wd = wd0 + S(j) * norm(wd0) * wn / norm(wn);
    Rh = w2R(wd, c);            BTh = R2BT(Rh, q, T, c); e1(i, j) = e(BTh);
    Rh = w2R(wd, ells, 'ells'); BTh = R2BT(Rh, q, T, c); e2(i, j) = e(BTh);
  end
end

plot(S, mean(e1), 'r'), hold on, 
plot(S, mean(e2), 'b--')
xlabel('noise level, $s$'), ylabel('distance measrue, $e$')
legend('using compleaxity', 'using full lag structure', 'location', 'northwest')
print_fig('w2r')

Rh1 = w2R(wd, c);            BTh1 = R2BT(Rh1, q, T); ch1 = BT2c(BTh1, q)
Rh2 = w2R(wd, ells, 'ells'); BTh2 = R2BT(Rh2, q, T); ch2 = BT2c(BTh2, q)
[e(BTh1), e(BTh2)]
