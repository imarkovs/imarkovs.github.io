function wh = ProjBT(w, BT)
wh = BT * BT' * vec(w');  
if size(w, 2) > 1, wh = reshape(wh, size(w, 2), size(w, 1))'; end
