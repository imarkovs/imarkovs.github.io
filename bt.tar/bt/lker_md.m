function R = lker_md(H, q, rtol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
nr = size(H, 1); R = [];
while ~isempty(H)
  pattern = isnan(H(:, 1));
  missing = find(pattern); 
  given   = setdiff(1:nr, missing); 
  selected = find(all( isnan(H) == pattern(:, ones(1, size(H, 2))), 1));  
  Hs = H(given, selected); H(:, selected) = [];
  if rtol >= 1, cond = all(size(Hs) >= [rtol+1 rtol]);
  else          cond = size(Hs, 1) >= q && size(Hs, 1) <= size(Hs, 2); end
  if cond 
    [~, Rs] = lra(Hs, rtol); 
    if ~isempty(Rs), 
      Ri = zeros(size(Rs, 1), nr); Ri(:, given) = Rs; R = [R; Ri]; 
    end
  end
end
