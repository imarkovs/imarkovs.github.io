The Behavioral Toolbox is a collection of Matlab functions for analysis
and design of dynamical systems using the behavioral approach to systems
theory and control. It implements newly emerged nonparameteric
data-driven methods for linear time-invariant systems.

In order to install it, download and unpack the archive file
      <https://imarkovs.github.io/bt/bt.tar>

To get started, run the the files showcases.m and tutorial.m and type
`help BT'.

For more information and updates, check the website
      <https://imarkovs.github.io/bt/>

Reference:
@InProceedings{bt-l4dc,
  Author =    {I. Markovsky},
  Title =     {The Behavioral Toolbox},
  booktitle = {Proc. of Machine Learning Research},
  volume =    {242},
  pages =     {130--141},
  Year =      {2024}
}
