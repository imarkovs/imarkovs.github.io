function M = multmat(R, q, T)
[g, nc] = size(R); ell = nc / q - 1; 
M = zeros(g * (T - ell), T * q);
for i = 1:(T- ell)
  M(g * (i - 1) + 1:g * i, (1:(ell + 1) * q) + (i - 1) * q) = R; 
end
