function [Rp, ells] = BT2Rp(BT, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
c = BT2c(BT, q, ctol); ell1 = c(2) + 1; Rp = {}; ells = []; m = q; 
for L = 1:ell1
  BL = BT2BT(BT, q, L); r = rank(BL, tol);
  if (r < m * L + sum(ells)) 
    N = null(BL', tol)'; Np = R2M(Rp, q, L);
    if ~isempty(Np), Nnew = rspan_diff(N, Np, tol); else, Nnew = N; end
    Rp = [Rp; Nnew]; ells = [ells (L - 1) * ones(1, size(Nnew, 1))]; 
    m = m - size(Nnew, 1);
  end
end
