function [Rp, ells] = BT2Rp(BT, q, ellsctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ellsctol>
if exist('ellsctol', 'var') && ~isempty(ellsctol)
  if (ellsctol(1) > 0 && ellsctol(1) < 1), tol = ellsctol; ctol = tol;
  elseif all(size(ellsctol) == [1 3])
     c = ellsctol; [m, ell, n] = unpack_c(c); ctol = c;
  else, ells = ellsctol; [c, m, ell, n] = ells2c(ells, q); ctol = c; end
else, ellsctol = tol; ctol = tol; end
if ~exist('ell', 'var'), ell_max = size(BT, 1) / q - 1; 
else,                    ell_max = ell; end
if ~exist('ells', 'var') 
  ells_ = []; LL = 1:ell_max+1; rtol = tol;
else 
  LL = unique(ells); LL = vec(LL + 1)';
end
Rp = {};
for L = LL
  if ~isempty(Rp), R_perp = perp(R2M(Rp, q, L), tol);
  else,            R_perp = eye(q * L); end
  BL = BT(1:q*L, :);
  if exist('ells', 'var'),  rtol = size(R_perp, 1) - sum(L-1 == ells); 
  elseif exist('c', 'var'), rtol = ctol2rtol(c, L); end
  [~, Z] = lra(R_perp * BL, rtol);
  if ~isempty(Z) 
    Rnew = Z * R_perp; Rp = [Rp; Rnew]; 
    if ~exist('ells', 'var')
      ells_ = [ells_; (L-1) * ones(size(Rnew, 1), 1)];
    end
  end
end
if ~exist('ells', 'var'), ells = ells_; end
