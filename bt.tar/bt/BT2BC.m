function [BC, c] = BT2BC(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
[c, m, ell, n] = BT2c(BT, q, ctol); ell_ctr = n; % use an upper bound
Bini = BT(1:q * ell, :); % call BT2BT
BC = orth(BT((q * (ell + ell_ctr) + 1):end, :) * null(Bini, tol), tol);
