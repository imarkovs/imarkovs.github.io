ex = 'siso'; opt = 'stable';
%% <test-examples>
switch ex
  case{'static'},     m = 1; ells = 0;            
  case{'scalar'},     m = 0; ells = 1;
  case{'siso'},       m = 1; ells = 2;            
  case{'mimo'},       m = 3; ells = [1 2 3];        
  case{'aut-mo'},     m = 0; ells = [1 2];        
  case{'descriptor'}, m = 1; ells = [0 3];    
  case{'complex'},    m = 2; ells = [0 1 2 2 3]; 
end
p = length(ells); q = m + p; 
Rp = randB(q, ells, strcat('ells', opt)); 
c = ells2c(ells, q); ell = c(2); n = c(3);
T = 10; BT0 = R2BT(Rp, q, T); eBT = @(BTh) Bdist(BTh, BT0, q, T);
w0 = R2w(Rp, q, T); wn = rand(T, q); w = w0 + 1 * norm(w0) * wn / norm(wn);
d0 = dist(w, BT0); ew  = @(BTh) 100 * abs(dist(w, BTh) - d0) / d0;

%% Monte-Carlo
Td = 100; wd0 = R2w(Rp, q, Td); 
mc = 1000; s = 0.1; 
for i = 1:mc
  wn = rand(Td, q); wd = wd0 + s * norm(wd0) * wn / norm(wn);
  BTh = w2BT(wd, T, c); e1(i) = eBT(BTh); e2(i) = ew(BTh);
end
figure, histogram(rad2deg(e1), 20, 'Normalization', 'probability'), print_fig('e1')
figure, histogram(e2, 20), print_fig('e2')
