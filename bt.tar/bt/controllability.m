clear all, clc, echo on
%% Controllability

m = 2; p = 3; q = m + p; n_ctr = 5; n_aut = 2; opt = '';
n = n_aut + n_ctr; ell = ceil(n / p); c = [m ell n];

ell_ctr = ceil(n_ctr / p); c_ctr = [m, ell_ctr, n_ctr]; 
ell_aut = ceil(n_aut / q); c_aut = [0, ell_aut, n_aut]; 

R_ctr = randB(q, c_ctr, opt);
R_aut = randB(q, c_aut, opt); 

BT_ctr = R2BT(R_ctr, q, ell+1, c_ctr);
BT_aut = R2BT(R_aut, q, ell+1, c_aut);
BT = BTadd(BT_aut, BT_ctr, q);

n_unctr = isunctr(BT, q); n_unctr == n_aut 

echo off
