function BT = R2BT(R_or_Rp, q, T, ctol); 
if iscell(R_or_Rp) % shortest-lag, the complexity is known
  ctol = ells2c(Rp2ells(R_or_Rp, q), q); 
else % general kernel representation, the complexity is given or estimated
  if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
  %% <default-ctol>
  if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
  elseif length(ctol) == 1, tol = ctol;            % tolerence specification
  else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
end
M = R2M(R_or_Rp, q, T);
[~, BT] = lra(M, ctol2rtol(ctol, T, 'dual', q), 'dual');
