function BT = R2BT(R_or_Rp, q, T, ctol); 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
M = R2M(R_or_Rp, q, T);
if ~iscell(R_or_Rp) % general kernel representation
  if length(ctol) == 3, c = ctol; r = q * T - c2r(c, T);
  else, tol = ctol; r = tol; end
else                % shortest-lag kernel representation
  c = ells2c(Rp2ells(R_or_Rp, q), q); r = q * T - c2r(c, T);
end
[~, BT] = lra(M', r); BT = BT'; % approximate left-kernel
