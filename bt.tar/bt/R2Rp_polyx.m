function [Rp, ells] = R2Rp_polyx(R, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
Rp_ = punpck(prowred(ppck(R, size(R, 2) / q - 1), 'z', tol)); ell1 = size(Rp_, 2) / q;
for i = 1:size(Rp_, 1)
  Rp_i = Rp_(i, :);
  for j = ell1:-1:1, if norm(Rp_i(q * (j - 1) + 1:q * j)) > tol, break; end, end
  Rp{i} = Rp_i(1:q * j); ells(i) = j;
end
