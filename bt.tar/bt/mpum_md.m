function [R, info, wh] = mpum_md(wd, m, ell, n)
[T, q] = size(wd); p = q - m; 
Lmax = floor((T + 1) / (q + 1)) - 1;
R = []; info = false;

for i = 0:(Lmax - ell) 
  L = ell + i + 1; H = hank(wd, L); 

  %% group columns according to missing values patterns
  Hnan = isnan(H); j = size(H, 2); to_search = 1:j; 
  sl = {}; sr = {}; % row/column indeces of sub-matrices 
  while ~isempty(to_search)
    ind = find(all(Hnan(:, to_search(1) * ones(1, length(to_search))) ...
                                              == Hnan(:, to_search)));
    sli = setdiff(1:(q * L), find(Hnan(:, to_search(1))));
    if (length(ind) >= length(sli) - 1) & (i >= q * L - length(sli))
      sl = [sl sli]; sr = [sr to_search(ind)];
    end
    to_search(ind) = [];
  end

  %% collect the annihilators of the sub-matrices
  Ri = [];
  for i = 1:length(sr)
    Hi = H(sl{i}, sr{i}); 
    if rank(Hi) == m * L + n, 
      [~, rdi] = lra(Hi, m * L + n); % norm(rdi * H(sl{i}, sr{i})), pause
      if ~isempty(rdi)
        ri = zeros(size(rdi, 1), q * L);
        ri(:, sl{i}) = rdi; Ri = [Ri; ri];
      end
    end
  end
  if ~isempty(Ri)
    R = [[R zeros(size(R, 1), size(Ri, 2) - size(R, 2))]; Ri]; 
  end
  
  %% check the exit condition
  if rank(R) == p * L - n, info = true; break; end
end
R = orth(R')'; 

%% find wh
if nargout == 3 
  BT = R2BT(R, q, T); 
  vec_wd = vec(wd'); Ig = find(~isnan(vec_wd));
  wh = BT * (BT(Ig, :) \ wd(Ig));
end
