clear all, clc, echo on
%% Errors-in-variables smoothing

m = 1; p = 1; n = 3; q = m + p; B = drss(n, p, m); 
T = 10; w0 = B2w(B, T); wn = randn(size(w0)); 
w = w0 + 0.1 * norm(w0) * wn / norm(wn);

BT = ss2BT(B, T);

wh = BT * BT' * vec(w'); wh = reshape(wh, q, T)';

e = @(wh) 100 * norm(w0 - wh, 'fro') / norm(w0, 'fro');
[e(w) e(wh)] % ->  11.5682    8.1765

echo off
