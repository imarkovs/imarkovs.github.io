function [B, io, c] = R2ss(R, q, io, ctol) 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if ~iscell(R), ell1 = size(R, 2) / q; 
else, for i = 1:length(R),  ell1(i) = size(R{i}, 2) / q; end, end 
Tmin = 2 * max(ell1); BT = R2BT(R, q, Tmin, ctol);
if ~exist('io', 'var') || isempty(io)
  IO = BT2IO(BT, q); io = IO(1, :);
end
[B, io, c] = BT2ss(BT, q, io, ctol);
