function [B, io] = R2ss(R_or_Rp, q, io, ctol) 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
if ~exist('io', 'var') || isempty(io), io = 1:q; end % <default-io>
if iscell(R_or_Rp), [ctol, m, ell, n] = ells2c(Rp2ells(R_or_Rp, q), q);
else,               ell = size(R_or_Rp, 2) / q - 1; end
BT = R2BT(R_or_Rp, q, 2 * ell + 1, ctol); 
[B, io] = BT2ss(BT, q, io, ctol);
