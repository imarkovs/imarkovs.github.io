function [w, BT] = R2w(R_or_Rp, q, T, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
%% <default-ctol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; % nothing specified 
elseif length(ctol) == 1, tol = ctol;            % tolerence specification
else, c = ctol; [m, ell, n] = unpack_c(c); end   % complexity specification
BT = R2BT(R_or_Rp, q, T, ctol); 
w = reshape(BT * rand(size(BT, 2), 1), q, T)';
