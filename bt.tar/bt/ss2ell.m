function ell = ss2ell(B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
ell = lag(B, tol)
