function yf = u2y(BT, q, uf, wini)
[Tf, m] = size(uf); p = q - m; [Tini, q] = size(wini);
BT = BT2BT(BT, q, Tini+Tf); Bini = BT(1:q * Tini, :); 
[Uf, Yf] = BT2UYT(BT(q * Tini + 1:q * (Tini + Tf), :), m, p);
yf = Yf * (pinv([Bini; Uf]) * [vec(wini'); vec(uf')]);
yf = reshape(yf, p, Tf)';
