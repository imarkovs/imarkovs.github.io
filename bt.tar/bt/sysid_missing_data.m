clear all, clc, echo on
%% Identification from data with missing values

%% test example
ex = 'siso'; opt = '';
%% <test-examples>
switch ex
  case{'static'},     m = 1; ells = 0;            
  case{'scalar'},     m = 0; ells = 3;
  case{'siso'},       m = 1; ells = 5;            
  case{'mimo'},       m = 3; ells = [1 2 3]';
  case{'aut-mo'},     m = 0; ells = [1 2]';        
  case{'descriptor'}, m = 1; ells = [0 3]';    
  case{'complex'},    m = 2; ells = [0 1 2 2 3]'; 
end
p = length(ells); q = m + p; 
Rp = randB(q, ells, opt); 
c = ells2c(ells, q); ell = c(2); n = c(3);
R0 = Rp2R(Rp, q); 

%% generate data
Td = 500; wd0 = R2w(R0, q, Td); s = 0.0;
wn = randn(Td, q); wd = wd0 + s * wn * norm(wd0) / norm(wn); 
wd(ell+1:ell+1:end, :) = NaN; % periodically missing samples

%% additional randomly scattered missing elements
I = randperm(q * Td); 
extra_missing = I(1:round(0.1 * q * Td));
wd(extra_missing) = NaN;

%% identification
tic, [Rh_, status_] = w2R_md(wd, 1e-8, ell+10); t_noc = toc;
tic, [Rh, status] = w2R_md(wd, c, ell+10); t_c = toc;

%% validation
T = 100; BT0 = R2BT(R0, q, T);
e = @(BTh) Bdist(BT0, BTh, q);
if strcmp(status, 'success')
  [t_noc e(R2BT(Rh_, q, T, c));
  t_c    e(R2BT(Rh,  q, T, c))]
else, disp('failed'), end

echo off
