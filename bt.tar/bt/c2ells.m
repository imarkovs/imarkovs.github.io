function [ells, all_ells] = c2ells(c, q)
[m, ell, n] = unpack_c(c); p = q - m;
if (n < 0) || (n > p * ell), error('incorrect complexity'); end
ells = zeros(1, p); k = floor(n / ell);
ells(1:k) = ell; ells(k + 1) = mod(n, ell);
if nargout > 1                      % construction of all ells
  if p == 1, all_ells = n; return, end
  all_ells = [];
  for k = n:-1:0
    T = all_lags(p - 1, n - k);
    T = T(T(:, 1) <= k, :);
    all_ells = [all_ells; [k * ones(size(T, 1), 1), T]];
  end
end
