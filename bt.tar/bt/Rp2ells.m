function ells = Rp2ells(Rp, q); 
g = length(Rp); ells = [];
for i = 1:g, ells = [ells (size(Rp{i}, 2) / q - 1) * ones(1, size(Rp{i}, 1))]; end
