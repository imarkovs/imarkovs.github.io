clear all

%% simulation parameters
m  = 5; p = 1; n = 2; 
Tr = 20;  % control horizon
Td = 500; % number of data samples 
s = 1e-5; 
B = drss(n, p, 1); B = ss(B.a, [B.b s * rand(n, m-1)], B.c, [B.d s * rand(p, m-1)], -1);

%% reference trajectory
ur = zeros(Tr, m); yr = ones(Tr, p); 

%% simulate date 
wd = B2w(B, Td); % random trajectory, uses the behavioral toolbox

%% solve the problem and check the result
wh = input_selection(wd, [ur yr], m, 1e-2);
figure, plot(yr, '-r'), hold on, plot(wh(:, m+1:end), '--b') % tracking 
figure, stem(sum_square(ur - wh(:, 1:m))) % and sparsity of ur - uh
