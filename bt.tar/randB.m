function [B, R, BT] = randB(q, c_or_ells, opt)
if exist('opt') | length(c_or_ells) ~= 3 % specification of the lag structure 
    ells = c_or_ells; [c, m, ell, n] = ells2c(ells, q); p = q - m;
else % complexity specification
    c = c_or_ells; [m, ell, n] = unpack_c(c); p = q - m; ells = c2ells(c, q);
end
for i = 1:p, R{i} = rand(1, q * (ells(i) + 1)); end
% B = R2ss(R, q, 1:q, c);
BT = R2BT(R, q, 2 * (ell + 1), c); B = BT2ss(BT, q, 1:q, c);
