function ells = c2ells(c, q)
[m, ell, n] = unpack_c(c); p = q - m;
if (n < 0) | (n > p * ell), error('incorrect complexity'); end
ells = zeros(1, p); k = floor(n / ell); ells(1:k) = ell; ells(k + 1) = mod(n, ell);
