function Rmat = Rcell2Rmat(Rcell, q)
g = length(Rcell); Rmat = [];
for i = 1:g, ells(i) = size(Rcell{i}, 2) / q - 1; end; ell = max(ells);
for i = 1:g, Rmat = [Rmat; [Rcell{i}, zeros(size(Rcell{i}, 1), q * (ell - ells(i)))]]; end
