function Y0 = BT2Y0(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
[c, m] = BT2c(BT, q, ctol); p = q - m;
[UT, YT] = BT2UYT(BT, m, p); 
Y0 = YT * null(UT, tol);
