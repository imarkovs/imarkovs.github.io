function ans = is_io(BT, q, io, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
[c, m, ell, n] = BT2c(BT, q, ctol); 
p = q - m; T = size(BT, 1) / q;
BTp = BT(1:q * ell, :); BTf = BT(q * ell + 1:end, :); % selection from BT!
UTf = BT2UYT(BT2BT(BTf, q, io), m, p);
ans = rank([BTp; UTf], tol) == m * T + n;
