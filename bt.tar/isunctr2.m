function n_unctr = isunctr2(B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[p, m] = size(B); q = p + m; n = order(B); ell = lag(B); 
T = ell;              % is ell enough? 
BC = B2B0(B, T, tol); % TODO: B2B0 vs B2BC ?
n_unctr = m * size(BC, 1) / q + n - size(BC, 2);
