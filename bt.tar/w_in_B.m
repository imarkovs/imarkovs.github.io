function ans = w_in_B(w, B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if iscell(w)
  for i = 1:length(w), ans(i) = w_in_B(w{i}, B, tol); end
else
  ans = dist(w, B) < tol;
end
