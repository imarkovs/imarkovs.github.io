function n_unctr = isunctr(BTorR, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
if size(BTorR, 2) < size(BTorR, 1)
  BT = BTorR; % the given representation is BT
  [BC, c] = BT2BC(BT, q, ctol); 
  n_unctr = c(1) * size(BC, 1) / q + c(3) - size(BC, 2);
else
  R = BTorR; % the given representation is R
  [R, ells] = R2Rp(R, q, ctol); n = sum(ells); ell = max(ells);
  M = multmat(R, q, 2 * ell + n); Mc = M(:, q * ell + 1:(q + n) * ell);
  n_unctr = size(Mc, 2) - rank(Mc, tol);
end
