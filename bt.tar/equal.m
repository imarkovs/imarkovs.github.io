function ans = equal(B1, B2, q, tol, T)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('T', 'var') || isempty(T), T = 100; end % <default-horizon>
if ~exist('q', 'var'), q = []; end 
[d, B1T, B2T] = Bdist(B1, B2, q, T);
ans = d < tol & size(B1T, 2) == size(B2T, 2);
