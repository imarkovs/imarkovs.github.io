function C = rspan_diff(A, B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
C = perp(B / A) * A;
