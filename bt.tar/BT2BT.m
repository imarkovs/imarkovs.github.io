function BT = BT2BT(BT, q, Tio, ctol)
T = size(BT, 1) / q; 
if isscalar(Tio), Tnew = Tio; % horizon restriction/extension
  if T == Tnew, return, end   % nothing to do
  if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
  if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
  if T < Tnew, % extension
    R = BT2R(BT, q, ctol); BT = R2BT(R, q, T, ctol);
  else % restriction
    BTnew = []; 
    for i = 0:(T - Tnew)
      BTnew = [BTnew BT(i * q + 1:(i + Tnew) * q, :)]; 
    end
    if length(ctol) == 3
      BT = lra(BTnew, c2r(ctol, Tnew)); 
    else, BT = orth(BTnew, tol); end
  end
else, io = Tio;  % variables permutation
  BT = BT(q * kron(0:T-1, ones(1, q)) + kron(ones(1, T), io), :);
end
