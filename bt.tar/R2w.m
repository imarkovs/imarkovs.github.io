function [w, BT] = R2w(R, q, T, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
BT = R2BT(R, q, T, ctol); w = BT * rand(size(BT, 2), 1); w = reshape(w, q, T)';
