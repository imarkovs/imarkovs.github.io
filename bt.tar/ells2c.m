function [c, m, ell, n] = ells2c(ells, q)
n = sum(ells); ell = max(ells); p = length(ells);
m = q - p; c = [m, ell, n];
