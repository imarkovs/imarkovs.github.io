function wh = lqctr(B, wr, v, wp, wf, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
[Tr, q] = size(wr);
if ~exist('wp'), wp = []; Tp = 0; else, Tp = size(wp, 1); end
if ~exist('wf'), wf = []; Tf = 0; else, Tf = size(wf, 1); end
if ~exist('v') || isempty(v), v = ones(Tr, q); end
vec_v = vec(v'); vec_wr = vec(wr'); T = Tp + Tr + Tf;
if isa(B, 'ss'), BT = B2BT(B, T); else BT = BT2BT(BT, q, T, ctol); end
Bpf = BT([1:q * Tp, q * (Tp + Tr) + 1:end], :); 
Br  = BT(q * Tp + 1:q * (Tp + Tr), :); 
Br  = vec_v(:, ones(1, size(Br, 2))) .* Br; vec_wr = vec_v .* vec_wr;
if ~isempty(Bpf)
  N = null(Bpf, tol); gp = pinv(Bpf, tol) * [vec(wp'); vec(wf')];
  z = pinv(Br * N, tol) * (vec_wr - Br * gp);
  wh = Br * (gp + N * z);
else
  wh = Br * pinv(Br, tol) * vec_wr;
end
wh = reshape(wh, q, Tr)';
