function colA = row2col(rowA, q)
[g, nc] = size(rowA); ell1 = nc / q; colA = []; 
for i = 1:ell1, colA = [colA; rowA(:, (i-1) * q + 1: i * q)]; end
