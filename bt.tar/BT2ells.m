function ells = BT2ells(BT, q, tol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
T = size(BT, 1) / q; p = 0; m_ = q; ells = []; d_ = 0; 
for t = 1:T 
  d = rank(BT(1:q*t, :), tol); m = d - d_; dm = m_ - m;
  if dm, ells = [ells, (t-1) * ones(1, dm)]; m_ = m; p = p + dm; end
  d_ = d;
end
