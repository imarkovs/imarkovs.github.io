function HT = B2HT(B, T), HT = convm(B, T);
