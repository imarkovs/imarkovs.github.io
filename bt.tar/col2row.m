function rowA = col2row(colA, g)
[nr, q] = size(colA); ell1 = nr / g; rowA = []; 
for i = 1:ell1, rowA = [rowA, colA((i-1) * g + 1: i * g, :)]; end
