function [Rproper,degrees] = R2Rp(R,q,p,tol)
    if nargin<4, tol=1e-8; end
    R = Rcell2Rmat(R, q);
    cond = 1;
    while cond
        [degrees,idx] = sort(R2degrees(R,q,tol),'ascend');
        R = R(idx,:);
        Rrl = R2Rrl(R, q, tol);
        Rtilde = R;
        for k = 2:size(R,1)
            nsp = rref(null(Rrl(1:k,:)',tol)');
            row_id = find(abs(nsp(:,end))>tol,1,'first');
            coeff = nsp(row_id,:);
            if isempty(coeff), continue; end
    
            sum_z = 0;
            for i = 1:k-1
                sum_z = sum_z + coeff(i)*z(R(i,:),q*max(0,degrees(k)-degrees(i)));
            end
            Rtilde(k,:) = coeff(k)*R(k,:) + sum_z;
        end
        R = Rtilde;
        zero_rows = find(sum(abs(R),2)<tol);
        R = [R(setdiff(1:size(R,1),zero_rows),:); R(zero_rows,:)];

        if isempty(R(p+1:end,:))
            cond = rank(R2Rrl(R, q, tol),tol)~=p;
        else
            cond = sum(abs(R(p+1:end,:)),'all') > tol;
        end
    end
    degrees = R2degrees(R, q, tol);
    Rproper = R(:,1:q*(max(degrees)+1));
    for t = 1:length(degrees)
        if degrees(t)==0 && sum(abs(Rproper(t,:))) < tol
            degrees(t)=NaN;
        end
    end
    if ~isnan(degrees)
        [degrees,idx] = sort(R2degrees(R, q, tol),'ascend');
        Rproper = R(idx,1:q*(max(degrees)+1));
    end
    degrees = degrees(1:p);    % added: is this ok? 
    Rproper = Rproper(1:p, :); % added: is this ok? 
end

function Rrl = R2Rrl(R, q, tol)
    if nargin<3, tol=1e-8; end
    Rrl = zeros(size(R,1),q);
    for i=1:size(R,1)
        for k=1:size(R,2)/q
            if sum(abs(R(i,end-k*q+1:end))) > tol
                Rrl(i,:) = R(i,end-k*q+1:end-(k-1)*q); break
            end
        end
    end
end

function degrees = R2degrees(R, q, tol)
    if nargin<3, tol=1e-8; end
    degrees = zeros(1,size(R,1));
    d = size(R,2)/q;
    for i=1:size(R,1)
        for k=1:d
            if sum(abs(R(i,end-k*q+1:end))) > tol
                degrees(i) = d-k; break
            end
        end
    end
end
