function BT = BTintersect(BT1, BT2, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
BT = rspan_intersect(BT1', BT2', tol)';
