function BT = UYT2BT(UT, YT, m, p)
q = m + p; [mT, N] = size(UT); T = mT / m; BT = zeros(q * T, N);
for i = 1:m, BT(i:q:end, :) = UT(i:m:end, :); end
for i = 1:p, BT(m+i:q:end, :) = YT(i:p:end, :); end
