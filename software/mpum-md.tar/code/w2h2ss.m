function sys = w2h2ss(w, m, n, Th, i, j)
if iscell(w)
  N = length(w);
  for i = 1:N, 
    [q, T{i}] = size(w{i}); if T{i} < q, w{i} = w{i}'; [q, T{i}] = size(w{i}); end
  end
else
  if length(size(w)) == 3 
    [q, N, T] = size(w);
  else
    [q, T, N] = size(w); if T < q, w = w'; [q, T] = size(w); end
  end
end, p = q - m;

if m == 0
    sys = h2ss(w, n); sys = ss(sys.a, [], sys.c, [], -1);
else
    if ~exist('Th') | isempty(Th)
        Th = ceil(n / p) + ceil(n / m) + 1; 
    end
    T = Th; 
    if ~exist('i', 'var') | ~isreal(i) | isempty(i) 
        i = ceil(T * m / (m + p)); 
    end
    if ~exist('j', 'var') | ~isreal(j) | isempty(j) 
        j = T - i; 
    elseif j > T - i
        error('Not enough data.')
    end  
    sys = h2ss(w2h(w, m, n, Th), n, [], i, j);
end

