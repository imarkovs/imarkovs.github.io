function [sysh, wh] = hmc_nn(w, n, m)
if iscell(w)
  N = length(w);
  for i = 1:N, 
    [q, T{i}] = size(w{i}); if T{i} < q, w{i} = w{i}'; [q, T{i}] = size(w{i}); end
  end
else
  if length(size(w)) == 3 
    [q, N, T] = size(w);
  else
    [q, T, N] = size(w); if T < q, w = w'; [q, T] = size(w); end
  end
end, if ~iscell(T)
                                                   l = floor((T + 1) / (q + 1)) - 1;
                                                 else
                                                   l = floor((min(T{:}) + 1) / (q + 1)) - 1; 
                                                 end, if iscell(w)
                                                                   tts = blkhank(reshape(1:(q * T{1}), q, T{1}), l + 1); 
                                                                   for i = 2:N
                                                                     tts = [tts blkhank(max(tts(:)) + reshape(1:(q * T{i}), q, T{i}), l + 1)];
                                                                   end
                                                                 else
                                                                   if length(size(w)) == 3
                                                                     tts = blkhank(reshape(1:(q * T * N), q, N, T), l + 1);
                                                                   else
                                                                     tts = blkhank(reshape(1:(q * T), q, T), l + 1);
                                                                   end
                                                                 end
if iscell(w)
  vec_w = []; for i = 1:N, vec_w = [vec_w; w{i}(:)]; end
else
  vec_w = w(:);
end
ind_m = find(isnan(vec_w)); n_m = length(ind_m);
ind_d = find(~isnan(vec_w)); , vec_w0 = vec_w; vec_w0(ind_m) = 0; Hh0 = vec_w0(tts); 
tts_m = (n_m + 1) * ones(size(tts)); 
for i = 1:n_m, tts_m(tts == ind_m(i)) = i; end
cvx_begin sdp; cvx_quiet(true);
  variables wh_m(n_m + 1);
  minimize( norm_nuc(Hh0 + wh_m(tts_m)) );
  subject to
    wh_m(n_m + 1) == 0;
cvx_end
vec_wh = vec_w; vec_wh(ind_m) = wh_m(1:n_m);
if iscell(w)
  b_ind = 1; 
  for i = 1:N
    e_ind = b_ind + q * T{i} - 1;
    wh{i} = reshape(vec_wh(b_ind:e_ind), q, T{i});
    b_ind = e_ind + 1;
  end
else
  if length(size(w)) == 3
    wh = reshape(vec_wh, q, N, T);
  else
    wh = reshape(vec_wh, q, T);
  end
end, sysh = w2h2ss(wh, m, n);
if rank(vec_wh(tts)) > (n + m * size(tts, 1) / q), warning('hmc_nn: failed'), end
