function h = w2h(w, m, n, Ts)
if iscell(w)
  N = length(w); q = min(size(w{1})); p = q - m; l = ceil(n / p); 
  for i = 1:N, 
    [q, T{i}] = size(w{i}); 
    if T{i} < q, w{i} = w{i}'; [q, T{i}] = size(w{i}); end
    u{i} = w{i}(1:m, (l + 1):end); y{i} = w{i}((m + 1):q, (l + 1):end); 
    j{i} = T{i} - (l + Ts); 
  end
else
  if length(size(w)) == 3 
    [q, N, T] = size(w); p = q - m; l = ceil(n / p); 
    u = w(1:m, :, (l + 1):end); y = w((m + 1):q, :, (l + 1):end);     
  else
    [q, T, N] = size(w); if T < q, w = w'; [q, T] = size(w); end
    p = q - m; l = ceil(n / p); 
    u = w(1:m, (l + 1):end); y = w((m + 1):q, (l + 1):end); 
  end
  j = T - (l + Ts); 
end 
Hp  = blkhank_cell(w, l, j);  
Hfu = blkhank_cell(u, Ts, j); 
Hfy = blkhank_cell(y, Ts, j); 
wini_uf = [zeros(l * q, m); eye(m); zeros((Ts - 1) * m, m)];
h_ = Hfy * pinv([Hp; Hfu]) * wini_uf;
for ii = 1:Ts
  h(:, :, ii) = h_(((ii - 1) * p + 1):(ii * p), :); 
end
