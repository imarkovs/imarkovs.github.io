clear all, warning off
sys0 = ss(diag([0.8889 + 0.4402i
                0.8889 - 0.4402i
                0.4500 + 0.8801i
                0.4500 - 0.8801i
                0.6368 + 0.7673i
                0.6368 - 0.7673i]), [], ones(1, 6), [], -1); 

T = 500; n = 6; w0 = initial(ss(sys0), ones(n, 1), T - 1); 
Tm = sort(unique([1:7:T, 3:7:T, 5:7:T])); w = w0; w(Tm) = NaN;

figure, stem(w), hold on, plot(Tm, 0, 'rX', 'markersize', 12), 
Tp = 100; ax = axis; axis([1 Tp ax(3:4)]); print_fig('data')
dist = @(sys1, sys2) norm(poly(eig(sys1)) - poly(eig(sys2)));

ex = 'cdc-example'; eval(['!rm ' ex]), diary(ex) 
tic, sysh_nn = hmc_nn( w(1:Tp), n, 0); t_nn = toc, e_nn = dist(sys0, sysh_nn)
tic, sysh_ss = mpum_md(w(1:Tp), n, 0); t_ss = toc, e_ss = dist(sys0, sysh_ss)
diary off

ex = 'cdc-example-all-data'; eval(['!rm ' ex]), diary(ex) 
tic, sysh_ss = mpum_md(w, n, 0); t_ss = toc, e_ss = dist(sys0, sysh_ss)
diary off
