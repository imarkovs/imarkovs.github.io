clear all, close all, name = 'illustrative-example-smooth';
m = 0; p = 1; n = 4; s = 0.1; T = 100; L = 40;
%% two-sins-system
z = [exp(i * 0.24) exp(i * 0.06)]; 
sys0 = ss(zpk([], [z conj(z)], -1));
sys0 = ss(sys0.a, [], sys0.c, [], -1);
%% random-trajectories
ud = rand(T, m); wd = [ud lsim(sys0, ud, [], rand(n, 1))];
u0 = rand(L, m); w0 = [u0 lsim(sys0, u0, [], rand(n, 1))];
Im = 21:40;
%% test-interpolation
w = w0; wt = randn(L, m+p); 
w = w0 + s * norm(w0) * wt / norm(wt); w(Im) = NaN; 
[wh, N] = ddint(wd, w); norm(w0 - wh) / norm(w0)
[I, J] = ind2sub([L 2], Im);
for i = 1:(m+p)
  figure(i), hold on
  Imi = I(find(J == i)); Igi = setdiff(1:L, Imi);
  plot(w0(:, i),  'k:'), plot(w(:, i), 'k:')
  plot(Imi, w0(Imi, i), 'rx', 'markersize', 10)
  plot(Igi, w0(Igi, i), 'bx', 'markersize', 10)
  plot(Imi, wh(Imi, i), 'ro', 'markersize', 10)
  plot(Igi, wh(Igi, i), 'bo', 'markersize', 10)
  ax = axis; axis([1 L ax(3:4)])
  %plot(Imi, ax(3) * ones(size(Imi)), 'rx', 'markersize', 10)
  %plot(Igi, ax(3) * ones(size(Igi)), 'b+', 'markersize', 10)
  % axis off, 
  print_fig([name int2str(i)], 15), hold off
end
