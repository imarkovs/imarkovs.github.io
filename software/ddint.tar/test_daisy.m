clear all, close all, rng(0, 'twister'), addpath ~/slra/ident/data/
datasets = {'destill', 'pHdata', 'dryer', 'thermic-wall', 'heating-system'};
methods.name{1} = 'pinv';  methods.ls{1} = '-.r'; methods.comp{1} = 'wh = ddint(wd, w);';
methods.name{2} = 'lra';   methods.ls{2} = '--b'; methods.comp{2} = 'wh = ddint(wd, w, [], m, n);';
methods.name{3} = 'l1';    methods.ls{3} = '-+g'; methods.comp{3} = 'wh = ddint(wd, w, [], [], [], l);';
methods.name{4} = '2s-ml'; methods.ls{4} = '-sc'; methods.comp{4} = 'wh = ddint(ident(wd, m, ell), w);';
methods.name{5} = 'ml';    methods.ls{5} = '-k' ; methods.comp{5} = '[sysh, info, wh] = ident({wd, w}, m, ell); wh = wh{2};';
methods.name{6} = 'mb';    methods.ls{6} = '-k' ; methods.comp{6} = 'wh = ddint(ss(pem(wd, n)), w);';
F = [0.05 0.1 0.2]; K = [1 3]; I = 1:5; 
for i = 1:length(I)
  datasets{i}
  %% data-sets
  switch i
    case 1, destill         , ell = 1; l = 2.63;      
    case 2, pHdata          , ell = 6; l = 6.5;
    case 3, dryer           , ell = 5; l = 0.3;
    case 4, thermic_res_wall, ell = 2; l = 5;
    case 5, heating_system  , ell = 2; l = 0.5;
    case 6, erie            , ell = 1; l = 25;
    case 7, CD_player_arm   , ell = 1;
    case 8, robot_arm       , ell = 4;
    case 9, exchanger       , ell = 2;
    case 10, cstr           , ell = 1;
    case 11, steamgen       , ell = 1;
  end
  m = size(u, 2); p = size(y, 2); n = ell * p;
  T = size(u, 1); Td = round(3 / 4 * T); Ti = 1:Td; Tv = Td+1:T;
  wd = [u(Ti, :) y(Ti, :)]; 
  w0 = [u(Tv, :) y(Tv, :)]; 
  nt = length(w0(:)); nm = round(F(2) * nt)
  rng(0), Im = randperm(nt, nm); w = w0; w(Im) = NaN;
  Ig = setdiff(1:nt, Im);
  e = @(wh, I) 100 * norm(w0(I) - wh(I)) / norm(w0(I)); 
  %% plot-lambda
  np = 20; L = linspace(0, 2 * l, np);
  for j = 1:np, wh = ddint(wd, w, [], [], [], L(j)); el1(j) = e(wh,Im); end 
  [min_e, min_i] = min(el1); l = L(min_i)
  figure, hold on
  plot(L, el1(1:length(L))), plot(l, min_e, 'o')
  ax = axis; axis([L(1), L(end), ax(3:4)]), box off
  xlabel('$\lambda$','Interpreter','latex')
  ylabel('$e_{\rm missing}$','Interpreter','latex')
  print_fig([datasets{i} '-l'], 20, 1)
  for k = 1:length(K)
    eval(methods.comp{K(k)}); 
    Eg(i, k) = e(wh, Ig); 
    Em(i, k) = e(wh, Im); 
  end
  %% plot-g
  [wh, ~, g] = ddint(wd, w, [], [], [], l);
  figure, hold on
  stem(sort(abs(g), 'descend'), 'linewidth', 2), hold on, ax = axis; box off
  r = size(w, 1) * m + n; plot(r * ones(1,2), ax(3:4), ':', 'linewidth', 2)
  axis([1 length(g) ax(3:4)])
  xlabel('$i$','Interpreter','latex')
  ylabel('sorted $|g_i|$','Interpreter','latex')
  print_fig([datasets{i} '-g'], 20, 1)
end

%% results
res = [[' '; datasets'] [methods.name(K); num2cell(Em)]]
