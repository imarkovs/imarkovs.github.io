function [wh, N, g] = ddint(wd, w, S, m, n, l)
[Ts, q] = size(w); 
if ~exist('S') || isempty(S), S = ones(size(w)); end
if Ts < q, w = w'; S = S'; [Ts, q] = size(w); end
w_vec = vec(w'); S_vec = vec(S'); 
Ig = find(~isnan(w_vec)); 
if isa(wd, 'lti')
  m_ = size(wd, 2); n_ = order(wd); Tmin = (m_+1) * Ts + n_;
  ud = rand(Tmin, m_); 
  yd = lsim(wd, ud, [], rand(n_, 1)); 
  wd = [ud yd]; clear ud yd
end
Hwd = blkhank(wd, Ts); 
if exist('m') && exist('n') && ~isempty(m) && ~isempty(n)
  r = Ts * m + n; tol = 1e-12;
  if rank(Hwd, tol) < r, warning('wd not informative.'); end
  [~, Hwd] = lra(Hwd, r); 
end
A = S_vec(Ig, ones(1, size(Hwd, 2))) .* Hwd(Ig, :); 
b = S_vec(Ig) .* w_vec(Ig); 
if ~exist('l') || isempty(l) || l == 0 || isa(wd, 'lti')
  g = pinv(A) * b;
else
  g = lasso_cvx(A, b, l);
end
wh = reshape(Hwd * g, q, Ts)'; 
if nargout > 1, N = Hwd * null(A); end
