%% random marginally stable system generation
function sys = drss_ms(n, p, m)
if ~exist('p'), p = 1; end
if ~exist('m'), m = 0; end
w = 2 * pi * rand(floor(n / 2), 1); 
if mod(n, 2) ~= 0, wr = 0; else wr = []; end
sys = ss(zpk(1, exp(i * [w; -w; wr]), 1, 1));
sys = ss(sys.a, rand(n, m), rand(p, n), rand(p, m), -1);
