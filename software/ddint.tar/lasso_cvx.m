function g = lasso_cvx(A, b, l)
cvx_begin quiet
   variable g(size(A, 2), 1)
   minimize(norm(b - A * g) + l * norm(g, 1))
cvx_end
