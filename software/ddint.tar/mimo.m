clear all, close all
np = 10; s = 0; mc = 20;
M  = round(linspace(1 , 100, np)); 
P  = round(linspace(10, 500, np)); 
N  = round(linspace(10, 500, np)); 
LL = round(linspace(50, 500, np)); 
TT = round(linspace(10000, 50000, np));   
X = TT; name = 'T';
for j = 1:np
   for i = 1:mc
   m = M(1); p = P(1); n = N(1); L = LL(1); T = TT(j); ell = ceil(n / p); 

   wm = [ones(ell, m + p); [ones(L - ell, m) NaN * ones(L - ell, p)]]; 
   Im = find(isnan(wm)); 

   sys0 = drss(n, p, m);
   ud = rand(T, m); wd = [ud lsim(sys0, ud, [], rand(n, 1))];
   u0 = rand(L, m); w0 = [u0 lsim(sys0, u0, [], rand(n, 1))]; 

   w = w0; wt = randn(L, m+p); 
   w = w0 + s * norm(w0) * wt / norm(wt); w(Im) = NaN; 

   H = blkhank(wd, L); w_vec = vec(w'); Ig = find(~isnan(w_vec));
   tic, wh = H * (H(Ig,:) \ w_vec(Ig));       t_dd(i, j) = toc;
   tic, ys0 = lsim(sys0, u0, [], rand(n, 1)); t_mb(i, j) = toc;
   e(i, j) = norm(vec(w0') - wh) / norm(w0(:));
  end
end

figure(1), plot(X, mean(t_dd), '-k'), % hold on, plot(X, t_mb, '-.r')
box off, ax = axis; axis([X(1) X(end), ax(3:4)])
xlabel(['$' name '$'],'Interpreter','latex')
ylabel('time, sec','Interpreter','latex')
print_fig(['mimo-t-' name], 20)

figure(2), plot(X, mean(e), '-k'), print_fig('mimo-e-p', 15)
box off, ax = axis; axis([X(1) X(end), ax(3:4)])
xlabel(['$' name '$'],'Interpreter','latex')
ylabel('$e$, sec','Interpreter','latex')
print_fig(['mimo-e-' name], 20)
