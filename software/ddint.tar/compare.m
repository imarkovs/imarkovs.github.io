clear all, close all
m = 1; p = 1; s = 0; T = 100; L = 10; N = 100;
np = 15; SD = linspace(0, 0.1, np); l = 0.1; K = 1:4;
%% benchmark-system
Q = [0 0 0 0.28261 0.50666]; 
P = [1 -1.41833 1.58939 -1.31608 0.88642];
sys0 = ss(tf(Q, P, -1)); n = order(sys0); ell = n;
methods.name{1} = 'pinv';  methods.ls{1} = '-.r'; methods.comp{1} = 'wh = ddint(wd, w);';
methods.name{2} = 'lra';   methods.ls{2} = '--b'; methods.comp{2} = 'wh = ddint(wd, w, [], m, n);';
methods.name{3} = 'l1';    methods.ls{3} = '-+g'; methods.comp{3} = 'wh = ddint(wd, w, [], [], [], l);';
methods.name{4} = '2s-ml'; methods.ls{4} = '-sc'; methods.comp{4} = 'wh = ddint(ident(wd, m, ell), w);';
methods.name{5} = 'ml';    methods.ls{5} = '-k' ; methods.comp{5} = '[sysh, info, wh] = ident({wd, w}, m, ell); wh = wh{2};';
methods.name{6} = 'mb';    methods.ls{6} = '-k' ; methods.comp{6} = 'wh = ddint(ss(pem(wd, n)), w);';

ud0 = rand(T, m); wd0 = [ud0 lsim(sys0, ud0)];
u0 = [zeros(n, 1); ones(L-n, 1)]; w0 = [u0 lsim(sys0, u0)];
w_ = ones(L, m + p); w_(n+1:end, m+1:end) = NaN; 
Ig = find(~isnan(w_(:))); Im = find(isnan(w_(:)));
w = w0; wt = randn(L, m+p); w = w0 + s * norm(w0) * wt / norm(wt); w(Im) = NaN; 
e = @(wh, I) 100 * norm(w0(I) - wh(I)) / norm(w0(I)); 

%wn = randn(T, m + p); wd = wd0 + SD(5) * norm(wd0) * wn / norm(wn);
%i = 1; datasets{i} = 'compare';
%%% plot-lambda
%np = 20; L = linspace(0, 2 * l, np);
%for j = 1:np, wh = ddint(wd, w, [], [], [], L(j)); el1(j) = e(wh,Im); end 
%[min_e, min_i] = min(el1); l = L(min_i)
%figure, hold on
%plot(L, el1(1:length(L))), plot(l, min_e, 'o')
%ax = axis; axis([L(1), L(end), ax(3:4)]), box off
%xlabel('$\lambda$','Interpreter','latex')
%ylabel('$e_{\rm missing}$','Interpreter','latex')
%print_fig([datasets{i} '-l'], 20, 1)
%%% plot-g
%[wh, ~, g] = ddint(wd, w, [], [], [], l);
%figure, hold on
%stem(sort(abs(g), 'descend'), 'linewidth', 2), hold on, ax = axis; box off
%r = size(w, 1) * m + n; plot(r * ones(1,2), ax(3:4), ':', 'linewidth', 2)
%axis([1 length(g) ax(3:4)])
%xlabel('$i$','Interpreter','latex')
%ylabel('sorted $|g_i|$','Interpreter','latex')
%print_fig([datasets{i} '-g'], 20, 1)

for j = 1:np, j
  for i = 1:N
    wn = randn(T, m + p); wd = wd0 + SD(j) * norm(wd0) * wn / norm(wn);
    for k = K, eval(methods.comp{k}); Eg{k}(i,j) = e(wh, Ig); Em{k}(i,j) = e(wh, Im); end
  end
end

figure, hold on
for k = K, plot(SD, mean(Em{k}), methods.ls{k}), end
box off, ax = axis; axis([SD(1) SD(end), ax(3:4)])
xlabel('noise-to-signal ratio','Interpreter','latex')
ylabel('error $e$, \%','Interpreter','latex')
legend(methods.name(K), 'location', 'northwest')
legend boxoff, print_fig('compare')
save compare
