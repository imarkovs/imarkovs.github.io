clear all, close all, name = 'siso-sim';
m = 1; p = 1; s = 0; T = 100; L = 40; 
%% benchmark-system
Q = [0 0 0 0.28261 0.50666]; 
P = [1 -1.41833 1.58939 -1.31608 0.88642];
sys0 = ss(tf(Q, P, -1)); n = order(sys0); ell = n;
ud = rand(T, m); wd = [ud lsim(sys0, ud)];
u0 = [zeros(n, 1); ones(L-n, 1)]; w0 = [u0 lsim(sys0, u0)];
w_ = ones(L, m + p); w_(n+1:end, m+1:end) = NaN; Im = find(isnan(w_(:)));
w = w0; wt = randn(L, m+p); w = w0 + s * norm(w0) * wt / norm(wt); w(Im) = NaN; 
%% test-interpolation
w = w0; wt = randn(L, m+p); 
w = w0 + s * norm(w0) * wt / norm(wt); w(Im) = NaN; 
[wh, N] = ddint(wd, w); norm(w0 - wh) / norm(w0)
[I, J] = ind2sub([L 2], Im);
for i = 1:(m+p)
  figure(i), hold on
  Imi = I(find(J == i)); Igi = setdiff(1:L, Imi);
  plot(w0(:, i),  'k:'), plot(w(:, i), 'k:')
  plot(Imi, w0(Imi, i), 'rx', 'markersize', 10)
  plot(Igi, w0(Igi, i), 'bx', 'markersize', 10)
  plot(Imi, wh(Imi, i), 'ro', 'markersize', 10)
  plot(Igi, wh(Igi, i), 'bo', 'markersize', 10)
  ax = axis; axis([1 L ax(3:4)])
  %plot(Imi, ax(3) * ones(size(Imi)), 'rx', 'markersize', 10)
  %plot(Igi, ax(3) * ones(size(Igi)), 'b+', 'markersize', 10)
  % axis off, 
  print_fig([name int2str(i)], 15), hold off
end
