clear all, close all, load airpass-sys0, name = 'test-airpass-sim';
m = 0; p = 1; n = 6; s = 0.05;
wd0 = initial(sys0, x0, T-1); wn = randn(T, 1); 
wd = wd0 + s * norm(wd0) * wn / norm(wn); y = wd;
%% test-airpass

%% data
T = length(y); Td = 110; Tg = 17; Tm = T - Td - Tg;
wd = y(1:Td); w0 = y(Td+1:end); l = 72; K = 1:4;
w  = [w0(1:Tg); NaN(Tm, 1)]; Ig = 1:Tg; Im = Tg+1:Tg+Tm;
e = @(wh, I) 100 * norm(w0(I) - wh(I)) / norm(w0(I)); 
ell = n;

i = 1; datasets{i} = name;
%% plot-lambda
np = 20; L = linspace(0, 2 * l, np);
for j = 1:np, wh = ddint(wd, w, [], [], [], L(j)); el1(j) = e(wh,Im); end 
[min_e, min_i] = min(el1); l = L(min_i)
figure, hold on
plot(L, el1(1:length(L))), plot(l, min_e, 'o')
ax = axis; axis([L(1), L(end), ax(3:4)]), box off
xlabel('$\lambda$','Interpreter','latex')
ylabel('$e_{\rm missing}$','Interpreter','latex')
print_fig([datasets{i} '-l'], 20, 1)

methods.name{1} = 'pinv';  methods.ls{1} = '-.r'; methods.comp{1} = 'wh = ddint(wd, w);';
methods.name{2} = 'lra';   methods.ls{2} = '--b'; methods.comp{2} = 'wh = ddint(wd, w, [], m, n);';
methods.name{3} = 'l1';    methods.ls{3} = '-+g'; methods.comp{3} = 'wh = ddint(wd, w, [], [], [], l);';
methods.name{4} = '2s-ml'; methods.ls{4} = '-sc'; methods.comp{4} = 'wh = ddint(ident(wd, m, ell), w);';
methods.name{5} = 'ml';    methods.ls{5} = '-k' ; methods.comp{5} = '[sysh, info, wh] = ident({wd, w}, m, ell); wh = wh{2};';
methods.name{6} = 'mb';    methods.ls{6} = '-k' ; methods.comp{6} = 'wh = ddint(ss(pem(wd, n)), w);';
for k = K, 
  eval(methods.comp{k}); Wh{k} = wh; Eg(k) = e(wh, Ig); Em(k) = e(wh, Im); 
end

%% results
res = [{'' 'Ig' 'Im'}; [methods.name(K)', num2cell([Eg' Em'])]]

figure, hold on
plot(Ig, w0(Ig), 'bo:', 'markersize', 10)
plot(Im, w0(Im), 'r+:', 'markersize', 10)
for k = K, plot(Wh{k}, methods.ls{k}), end %'bo:', 'markersize', 10
legend(['w(Ig)' 'w(Im)' methods.name(K)], 'location', 'northwest')
legend boxoff, box off, ax = axis; axis([1 Tg+Tm 300 650])
print_fig(name), hold off
