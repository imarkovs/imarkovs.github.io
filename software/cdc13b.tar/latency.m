
function [L, weh, xini] = latency(w, sysh)
if isa(sysh, 'idss') || isa(sysh, 'idpoly'), sysh = id2ss(sysh); end
[p, m] = size(sysh); n = size(sysh, 'order'); ell = n / p; m = m - p;
opt.sys0 = sysh; opt.MaxIter = 0; opt.MaxFunEvals = 1; opt.Display = 'off';
[sysh, info, weh, xini] = slra_armax(w, m, ell, opt); L = info.L;
