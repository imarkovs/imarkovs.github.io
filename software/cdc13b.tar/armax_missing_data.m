clear all, T = 100; s = 0.01; m_io = [1 2]; 
switch 3
  case 1, Tm = [];
  case 2, Tm = [30:70];
  case 3, Tm = [30:3:70]; 
end
K = 5; NL = linspace(0, 0.1, K);

randn('seed', 0); rand('seed', 0); warning off
P0 =  [1 -1.4 0.7]; Q0 = -[1 0.3]; E0 =  [1 0.5]; 
err = @(Ph) real(acos( dot(P0, Ph) / norm(P0) / norm(Ph) ));
sys0 = idpoly(P0, Q0, E0); u0 = rand(T, 1); 

for i = 1:K
  nl = NL(i); e0 = nl * randn(T, 1); 
  sim_opt = simOptions('AddNoise', true, 'NoiseData', e0); 
  y0 = sim(sys0, u0, sim_opt); w0 = [u0 y0]; w = w0; w(Tm, m_io) = NaN; u = w(:, 1); y = w(:, 2);

  % PEM
  sysh = armax_(iddata(y, u), [2 3 2 0]); 
  [L, weh] = latency(w, sysh); %L 
  if isempty(Tm), 
      [L_pe, weh_pe] = latency_pe(w, idss(sysh)); %L_pe
  else
      wh = weh(:, 2:3); norm(w0(Tm, m_io) - wh(Tm, m_io)) / norm(w0(Tm, m_io));
  end
  [Qh, Ph] = tfdata(sysh(1, 1), 'vec'); E(2, i) = err(Ph);
  
  % SLRA
  opt.sys0 = id2ss(n4sid_(iddata(y, u), 2)); 
  [sysh, info, weh, xini] = slra_armax(w, 1, 2, opt); % idpoly(ss2id(sysh))
  [L, weh] = latency(w, sysh); %L 
  if isempty(Tm), 
      [L_pe, weh_pe] = latency_pe(w, sysh); %L_pe, 
  else
      wh = weh(:, 2:3); norm(w0(Tm, m_io) - wh(Tm, m_io)) / norm(w0(Tm, m_io));
  end  
  [Qh, Ph] = tfdata(sysh(1, 2), 'vec'); E(1, i) = err(Ph);
end

E
