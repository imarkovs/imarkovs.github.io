function [sys, wh, data] = n4sid_(data, varargin)
data = misdata(data, 10);
sys  = n4sid(data, varargin{:});
if nargout > 1
    out = compare(data, sys);
    if iscell(data.u)
      for k = 1:length(data.u)
        wh{k} = [data.u{k} out{k}.y];
      end
    else, wh = [data.u out.y]; end
end
