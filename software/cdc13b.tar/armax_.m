function [sys, wh, data] = armax_(data, varargin)
data = misdata(data, 10);
sys  = armax(data, varargin{:});
if nargout > 1
    out = compare(data, sys);
    if iscell(data.u)
      for k = 1:length(data.u)
        wh{k} = [data.u{k} out{k}.y];
      end
    else, wh = [data.u out.y]; end
end
