
function [L, weh, eh, xini] = latency_pe(w, sysh)
if ~isa(sysh, 'idss'), sysh = ss2id(ss(sysh)); end
[p, m] = size(sysh); opt = peOptions('InitialCondition', 'e');
[eh, xini] = pe(sysh, iddata(w(:, m + 1:end), w(:, 1:m)), [], [], opt);
weh = [eh.y w]; L = norm(eh.y) ^ 2;


