clear all
x = [1 0; 0 1];

c{1} = rand(2,1); % [.9; 0]; 
p{1} = rand(1,2); % [.9 0];
for i = 1:30
    f(i) = norm(x - c{i} * p{i},'fro');
    fprintf('f=%f, c'' = [%f %f], p = [%f %f]\n',f(i),c{i}(1),c{i}(2),p{i}(1),p{i}(2)) 
    % LS  
    p{i+1} = c{i} \ x;
    c{i+1} = x / p{i+1};
    % Normalize
    c{i+1} = c{i+1} / c{i+1}(1);
    p{i+1} = p{i+1} * c{i+1}(1);
end    
stem(f)

return

[u,sv,v] = svd(x); sv = diag(sv);
fprintf('%f\n',sv(2))
cs = u(:,1) / u(1,1)
ps = v(:,1)' * u(1,1) * sv(1)

return

syms c2 p1 p2

e = x-[1;c2]*[p1 p2];
f = trace(e*e.');
sol = solve(f-1,'c2','p1',p2)











