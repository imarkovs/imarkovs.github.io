randn('seed', 0); rand('seed', 0);

%% Continuous-time model
A = [0, 1; -k / (m + M), -d / (m + M)]; 
B = [0; -g / (m + M)]; C = [1, 0]; D = 0; 

%% Simulate a trajectory
sys = c2d(ss(A, B, C, D), ts); 
G = dcgain(sys); 
[p, m] = size(G); n = size(sys, 'order');
u0 = ones(T, 1) * M; % step input
y0 = lsim(sys, u0, [], xini);
y = y0 + randn(T, p) * s; 

%% Apply the methods and plot the results (single run)
uh_dd = stepid_dd(y, G, n, ff);
uh_af = stepid_shu(y, G, ff); 

figure, hold on, 
Tmin = 2 * n + 1; t = Tmin:T;
plot(t, y0(t, :) / G', 'k-'), plot(t, y(t, :) / G', 'k:'), 
plot(t, u0(t, :), 'k--'), plot(t, uh_dd(t, :), '--b'), 
plot(t, uh_af(t, :), '-.r'), ax = axis; 
legend('model free', 'adaptive', 'naive') 
xlabel('t'), ylabel('y(t)'), 
title(sprintf('Example %d; one run', ex))
axis([Tmin T ax(3:4)]), 

%% Monte-Carlo (average results)
clear e_dd e_af e_nv
for i = 1:N
    y = y0 + randn(T, p) * s;       
    e_nv(:, i) = sum(abs(u0 - y / G'), 2);
    uh_dd = stepid_dd(y, G, n, ff);  
    e_dd(:, i) = sum(abs(u0 - uh_dd), 2);
    uh_af = stepid_shu(y, G, ff);
    e_af(:, i) = sum(abs(u0 - uh_af), 2);
end

figure, hold on
plot(t, mean(e_dd(t, :), 2), '--b'), 
plot(t, mean(e_af(t, :), 2), '-.r'),
plot(t, mean(e_nv(t, :), 2), ':k'), 
legend('model free', 'adaptive', 'naive') 
xlabel('t'), ylabel('e(t)'), 
title(sprintf('Example %d; average error', ex))
ax = axis; axis([Tmin T 0 ax(4)]), 

