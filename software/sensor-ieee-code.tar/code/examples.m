%% Examples from I. Markovsky "Comparison of adaptive and model-free methods for dynamic measurement", IEEE-SPL, 2015

%% Constants
m = 1;    % mass of the platform
k = 1;    % spring constant
d = 1;    % damping constant
g = 9.81; % gravitational constant
N = 100;  % # of Monte-Carlo repetitions
ts = 1;   % sampling period
ff = 1;   % forgetting factor (1 = no forgetting)
xini = 0.1 * [1; 1]; % initial condition for the simulated trajectory

%% Example 1
ex = 1;  
M = 1;    % object mass
T = 13;   % simulation time
s = 0.02; % measurement noise standard deviation
test

%% Example 2
ex = 2; M = 10; T = 20; s = 0.05; test

%% Example 3
ex = 3; M = 100; T = 50; s = 0.5; test
