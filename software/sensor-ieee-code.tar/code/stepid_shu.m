%% Adaptive filtering for dynamic measurements 
%
% uh = stepid_shu(y, G, f)
% 
% y - measured output
% g - DC-gain
% f - forgetting factor
% uh - vector of input estimates (in real-time) 
% 
% W.-Q. Shu. "Dynamic weighing under nonzero initial conditions".
% IEEE Trans. Instrumentation Measurement, 42(4):806–811, 1993.

function uh = stepid_shu(y, G, l)

%% low-pass filter y
n = 2; y = filter(ones(1, n) / n, 1, y);
    
%% initial conditions
A = [- fliplr(blkhank(y(1:4), 3)) ones(3, 1)]; b = y(3:5);
th = pinv(A) * b; P = pinv(A' * A);
    
%% recursive algorithm
T = length(y); uh = NaN * ones(4, 1); linv = 1 / l;
uh(5) = 1 / G * th(3) / (1 + th(1) + th(2));
for k = 6:T
    h = [- y(k - 1); - y(k - 2); 1];
    L = linv * P * h / (linv * h' * P * h + l);
    P = linv * (P - L * h' * P);
    th = th + L * (y(k) - h' * th);
    uh(k) = 1 / G * th(3) / (1 + th(1) + th(2));
end

