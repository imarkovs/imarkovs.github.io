examples.m --- main file reproducing the examples in I. Markovsky "Comparison of adaptive and model-free methods for dynamic measurement", IEEE-SPL, 2015
stepid_dd.m --- model-free method for dynamic measurement (Algorithm 1 in the paper)
stepid_shu.m --- adaptive filtering for dynamic measurements  (the algorithm of reference [9])
blkhank.m --- construct the block-Hankel matrix H_i(w)
test.m --- helper script called by examples.m
