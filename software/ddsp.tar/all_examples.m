%% Examples from "A low-rank matrix completion approach to data-driven signal processing"
% Install first the SLRA package from http://slra.github.io/software-slra.html
% (use "Current version (unstable)")

clear all, n = 2; 
sys0 = ss(tf([1 -1 1], [1 -1.456 0.81], 1));

Td = 100; ud0 = rand(Td, 1); 
yd0 = lsim(sys0, ud0); 
wd0 = [ud0 yd0]; wt = rand(Td, 2); 
wd = wd0 + 0.1 * wt / norm(wt) * norm(wd0);

%% EIV smoothing

wp = NaN * ones(n, 2); Tf = 50; 
uf0 = ones(Tf, 1); yf0 = step(sys0, Tf - 1); 
wf0 = [uf0 yf0]; wft = randn(Tf, 2); 
wf = wf0 + 0.1 * wft / norm(wft) * norm(wf0);

e = @(wfh) norm(wf0 - wfh, 'fro') ...
           / norm(wf0, 'fro');

[M, wh] = misfit([wp; wf], sys0); 
wfh = wh(n + 1:end, :);
wfh_ks  = eiv_ks(wf, sys0); 
[e(wfh) e(wfh_ks)]

[sysh_id, info_id] = ident(wd, 1, n); 
wfh_id = eiv_ks(wf, sysh_id); e(wfh_id)

[sysh, info, wh] = ...
       ident({wd, [wp; wf]}, 1, n); 
e(wh{2}(n + 1:end, :))

%% Simulation

Tf = 50; s0 = step(sys0, Tf - 1); 
uf = ones(Tf, 1); yf = NaN * ones(Tf, 1); 
wf = [uf yf];

e = @(sh) norm(s0 - sh) / norm(s0);

opt.exct = 1; opt.wini = 0; 
[M, wfh] = misfit(wf, sys0, opt); 
sh = wfh(:, 2); e(sh)

[sysh_id, info_id, wd_id] = ident(wd, 1, n);
sh_id = step(sysh_id, Tf - 1); e(sh_id)

opt.exct = {[], 1}; opt.wini = {[], 0}; opt.sys0 = sysh_id;
[sysh, info, wh] = ident({wd wf}, 1, n, opt); 
sh = wh{2}(:, 2); e(sh)

