function R = w2r(w, n, method)
if exist('method') && strcmp(method, 'slra'), R = ss2r(ident(w, 1, n)); return, end
if exist('method')
  W = method(w, n + 1); r = 2 * n + 1;  % data matrix and required rank
elseif exist('n')
  W = blkhank(w, n + 1); r = 2 * n + 1; % the default method is 'Hankel'
else 
  W = w; r = size(W, 1) - 1;
end
R = lra(W, r); R = R / R(end); % approximate left kernel + normlization
