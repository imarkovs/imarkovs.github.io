function H = moshank(w, i)
if iscell(w)
  N = length(w); H = []; for k = 1:N, H = [H blkhank(w{k}, i)]; end
else
  H = blkhank(w, i);
end
