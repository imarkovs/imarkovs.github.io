function R = mpum(w, ell_max)
[T, q] = size(w); 
m = q; p = 0; ell = []; R = {};
for L = 1:ell_max
  H = blkhank(w, L);
  if rank(H) < m * L + sum(ell) 
    N  = null(H')';
    Np = multmat_(R);
    X  = Np / N;
    Xnew = perp(X);

    R{p + 1} = Xnew * N;
    ell(p + 1) = L;
    p = p + 1; m = m - 1; 
end
