function [R, P, Dh] = lra(D, r)
[u, s, v] = svd(D); R = u(:, (r + 1):end)'; P = u(:, 1:r);
if nargout > 2, Dh = u(:, 1:r) * s(1:r, 1:r) * v(:, 1:r)'; end
