m = 1; p = 1; n = 2;
sys = drss(n, p, m);
R = ss2r(sys);
