function S = multmat_(R, T, q)
if iscell(R)
  S = []; g = length(R);
  for i = 1:g
    S = [S; multmat_(R{i}, T, q)]
  end
else
  S = multmat_(R, T, q);
end
