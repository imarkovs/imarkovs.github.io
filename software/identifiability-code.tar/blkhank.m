function H = blkhank(w, i, j)
[q, T] = size(w); if T < q, w = w'; [q, T] = size(w); end
if nargin < 3 | isempty(j), j = T - i + 1; end
if j <= 0, error('Not enough data.'), end
H = zeros(i * q, j); 
for ii = 1:i
  H(((ii - 1) * q + 1):(ii * q), :) = w(:, ii:(ii + j - 1));
end
