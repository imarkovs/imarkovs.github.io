clear all, close all
Tshort = 5; N = 1000; s = 0.01; nmc = 500;
np = 10; NN = linspace(100, N, np); 
%% define-T
T = N * Tshort; % same total number of samples in the Hankel and trajectory matrices
% T = N + 4; % same number of columns in the Hankel and trajectory matrices
%% true-system
q = [ 0 0 0 0.28261 0.50666]; 
p = [1 -1.41833 1.58939 -1.31608 0.88642];
sys0 = ss(tf(q, p, 0.05)); n = order(sys0); R0 = ss2r(sys0);

%% true-data
u0 = rand(T, 1); x0 = rand(n, 1); y0 = lsim(sys0, u0, [], x0); w0 = [u0, y0]; 
W0 = zeros(2 * (n+1), N);
for k = 1:N
  u0k = rand(Tshort, 1); x0k = rand(n, 1); y0k = lsim(sys0, u0k, [], x0k); 
  W0(:, k) = vec([u0k y0k]');
end


%% Monte-Carlo simulation
for j = 1:np
  N = NN(j), 
  %% define-T
  T = N * Tshort; % same total number of samples in the Hankel and trajectory matrices
  % T = N + 4; % same number of columns in the Hankel and trajectory matrices
  for i = 1:nmc
    %% noisy-data
    w = w0 + s * randn(size(w0)); w = w(1:T, :);
    W = W0 + s * randn(size(W0)); W = W(:, 1:N);
    
    %% identification-methods
    M{1} = @() w2r(w, n, @blkhank); M_name{1} = 'Hankel'; M_line{1} = 'b--';
    M{2} = @() w2r(w, n, @page);    M_name{2} = 'Page';   M_line{2} = 'r.-';
    M{3} = @() w2r(W);              M_name{3} = 'Traj.';  M_line{3} = 'r-.';
    M{4} = @() w2r(w, n, 'slra');   M_name{4} = 'ML';     M_line{4} = 'b:';
    
    %% validation-criteria
    E{1} = @(Rh) norm(R0 - Rh) / norm(R0); 
    E_name{1} = '\bar{R}'; 
    E{2} = @(wh) norm(w0(1:T, :) - wh, 'fro') / norm(w0(1:T, :), 'fro'); 
    E_name{2} = 'w_d'; 
    E{4} = @(Wh) norm(W0(:, 1:N) - Wh, 'fro') / norm(W0(:, 1:N), 'fro');
    E_name{4} = '\bar{\cal W}';
    E{3} = @(wh) norm(w - wh, 'fro') / norm(w, 'fro');
    E_name{3} = '\bar{w}'; 
    E{5} = @(Wh) norm(W - Wh, 'fro') / norm(W, 'fro');
    E_name{5} = '{\cal W}_d'; 
    
    for k = 1:length(M)
      Rh = M{k}(); 
      %% validate
      wh = w2wh(w, Rh); Wh = W2Wh(W, Rh);
      errors = [E{1}(Rh) E{2}(wh) E{3}(wh) E{4}(Wh) E{5}(Wh)];
      e(i, k, j, :) = errors;
    end
  end
end

X = NN; f_name = 'f2'; legend_position = 'NorthEast'; x_label = 'sample size, $N$';
%% plot-results
res = squeeze(mean(e)); 
for i = 1:length(E)
  figure(i), hold on
  for k = 1:length(M)
    plot(X, res(k, :, i), M_line{k})
  end
  xlabel(x_label, 'Interpreter','latex'), 
  ylabel(['error, $e_{' E_name{i} '}$'], 'Interpreter','latex')
  legend(M_name, 'location', legend_position)
  legend boxoff, set(gca, 'box', 'off')
  ax = axis; axis([X(1) X(end) ax(3:4)]) 
  set(gca, 'xtick', [X(1) X(end)], 'ytick', ax(3:4))
  set(gca, 'fontsize', 17), eval(['print -depsc ' f_name int2str(i) '.eps'])
end
save(f_name)
