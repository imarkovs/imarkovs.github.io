function P = page(w, L)
[q, T] = size(w); if T < q, w = w'; [q, T] = size(w); end % assuming T > q
Tp = floor(T / L); P = reshape(w(:, 1:(Tp*L)), q * L, Tp);
