function sysh = r2ss(R)
q = - flip(R(1:2:end)); p = flip(R(2:2:end)); sysh = ss(tf(q, p, 1));
