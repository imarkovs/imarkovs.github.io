function [Alperp, Arperp] = perp(A)
if ~exist('tol'), tol = 1e-12; end
[u, s, v] = svd(A, tol); r = sum(s > tol);
Alperp = u(r+1:end, :); Arperp = v(:, r+1:end);
