function Wh = W2Wh(W, R)
P = null(R); Wh = P * (P \ W);
