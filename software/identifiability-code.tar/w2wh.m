function wh = w2wh(w, R)
try
  [M, wh] = misfit(w, r2ss(R)); % fast implementation
catch
  T = size(w, 1); B = null(multmat(R, T, 2));
  wh = B * pinv(B) * vec(w'); wh = reshape(wh, 2, T)';
end
