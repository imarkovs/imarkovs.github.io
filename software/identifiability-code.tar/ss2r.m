function R = ss2r(sys)
n = order(sys); [q, p] = tfdata(tf(sys), 'vec'); 
m = length(q) - 1; R = zeros(1, 2 * (n + 1)); 
R(1:2:end) = -flip([zeros(n - m) q]); R(2:2:end) = flip(p);
