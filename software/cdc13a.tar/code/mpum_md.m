function [sysh, wh] = mpum_md(w, n, m, dn)
if iscell(w)
  N = length(w);
  for i = 1:N, 
    [q, T{i}] = size(w{i}); if T{i} < q, w{i} = w{i}'; [q, T{i}] = size(w{i}); end
  end
else
  if length(size(w)) == 3 
    [q, N, T] = size(w);
  else
    [q, T, N] = size(w); if T < q, w = w'; [q, T] = size(w); end
  end
end
p = q - m; dn = 0; cont = 1; if iscell(w)
                               vec_w = []; for i = 1:N, vec_w = [vec_w; w{i}(:)]; end
                             else
                               vec_w = w(:);
                             end
while 1
  l = n + dn; if iscell(w)
                tts = blkhank(reshape(1:(q * T{1}), q, T{1}), l + 1); 
                for i = 2:N
                  tts = [tts blkhank(max(tts(:)) + reshape(1:(q * T{i}), q, T{i}), l + 1)];
                end
              else
                if length(size(w)) == 3
                  tts = blkhank(reshape(1:(q * T * N), q, N, T), l + 1);
                else
                  tts = blkhank(reshape(1:(q * T), q, T), l + 1);
                end
              end, h = vec_w(tts); 
  hnan = isnan(h); j = size(h, 2); 
  to_search = 1:j; sl = {}; sr = {};
  while ~isempty(to_search)
    ind = find(all(hnan(:, to_search(1) * ones(1, length(to_search))) ...
                   == hnan(:, to_search)));
    sli = setdiff(1:(q * (l + 1)), find(hnan(:, to_search(1))));           
    if (length(ind) >= length(sli) - 1) & (dn >= q * (l + 1) - length(sli))
      sl = [sl sli]; sr = [sr to_search(ind)];
    end        
    to_search(ind) = [];
  end
  R = [];
  for i = 1:length(sr)
    rdi = lra(h(sl{i}, sr{i}), length(sl{i}) - p); % norm(rdi * h(sl{i}, sr{i}))
    if ~isempty(rdi)
      ri = zeros(size(rdi, 1), q * (l + 1));
      ri(:, sl{i}) = rdi; R = [R; ri];
    end
  end
  g = size(R, 1); 
  if (g == 0) | (g < (dn + 1) * p) 
    dn = dn + 1;
  else
    break;
  end
end
if iscell(T), T = min(T{:}); end
S  = blksylv(R, q, T - size(R, 2) / q + 1);
ws = lra(S', size(S, 2) - (n + T * m)); 
wsr = zeros(q, n + T * m, T);
for i = 1:(n + T * m)
  wsr(:, i, :) = reshape(ws(i, :), q, 1, T);
end
sysh = w2h2ss(wsr, m, n); wh = est_md_cell(sysh, w);
