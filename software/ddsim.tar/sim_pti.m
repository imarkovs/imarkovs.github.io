function y = sim_pti(sys, u, wini)
T = size(u, 1); ell = size(wini, 1); 
w = [wini; zeros(T, 2)]; w(ell + 1:end, 1) = u;
for t = 1:T
  w(t + ell, 2) = sys.th' * sys.phi([vec(w(t:t + ell -1, :)'); w(t + ell, 1)]);
end
y = w(ell + 1:end, 2);
