% Data of the ball-and-beam setup in SISTA

load ballbeam.dat
u = ballbeam(:,1);
y = ballbeam(:,2);
clear ballbeam
