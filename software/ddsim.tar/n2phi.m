function phi = n2phi(N)
[nth, nx] = size(N); str = '';
for i = 1:nth
    str_i = ['x(1, :) .^ ' int2str(N(i, 1))];
    for j = 2:nx
        str_i = [str_i ' .* x(' int2str(j) ', :) .^ ' int2str(N(i, j))];
    end
    if i == 1, str = str_i; else, str = [str '; ' str_i]; end
end
eval(sprintf('phi = @(x) [%s];', str));
