function N = monomials(nx, n_max);
if n_max == 0, N = zeros(1, nx); return, end
if n_max == 1, N = eye(nx); return, end
if nx == 1, N = (0:n_max)'; return, end
N = []; 
for i = 0:n_max
    t = monomials(nx - 1, n_max);
    ni = [i * ones(size(t, 1), 1), t];
    N = [N; ni]; 
end
N(sum(n, 2) > n_max, :) = [];
