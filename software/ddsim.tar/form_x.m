function x = form_x(w, ell)
xext = blkhank(w, ell + 1); x = xext(1:end-1, :);
