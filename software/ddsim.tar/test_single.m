%% setup
clear all, s = 0; T = 100; L = 10; 

% Hammerstein
%% <example-h>
%    u(t) y(t) u(t+1)
ell = 1; th  = [0.95 1 2]'; 
N = [0    1    0 ; 
     0    0    1 ;
     0    0    2 ];
%% <define-sys>
phi = n2phi(N); 
ell = (size(N, 2) + 1) / 2 - 1; %% <N-to-ell>

sys.phi = phi; sys.th = th; sys.ell = ell; sys.N = N;


% <simulate-data>
ud0 = rand(T, 1); wdini0 = zeros(ell, 2);
yd0 = sim_pti(sys, ud0, wdini0); wd0 = [ud0, yd0];

wsini = rand(ell, 2); us = rand(L, 1); ys = sim_pti(sys, us, wsini); name = 'h';
% <plot-results>
ysh = ddsim_b(wd0, us, N, wsini); check = norm(ys - ysh)
figure(1)
plot([wsini(:, 1); us]), ax = axis; axis([1 ell + L ax(3:4)]), box off
xlabel('$t$', 'interpreter', 'latex'), ylabel('$u$', 'interpreter', 'latex')
print_fig([name '-u'])
figure(2)
plot([wsini(:, 2); ys], 'r-'), hold on, plot([wsini(:, 2); ysh], 'b--')
ax = axis; axis([1 ell + L ax(3:4)]), box off, hold off
xlabel('$t$', 'interpreter', 'latex'), ylabel('$y$', 'interpreter', 'latex')
print_fig([name '-y'])

% Volttera
%% <example-v>
%    u(t) y(t) u(t+1) y(t+1) u(t+2)
ell = 2;
Nnl = [0    0    0      0      2     ;
       0    0    1      0      1     ;
       1    0    1      0      1     ];
sysl = drss(ell); [q p] = tfdata(tf(sysl), 'v'); 
thl  = vec(fliplr([q; -p]));
th   = [thl(1:end-1); 0.1 * ones(size(Nnl, 1), 1)]; 
N = [eye(2 * ell + 1); Nnl];
%% <define-sys>
phi = n2phi(N); 
ell = (size(N, 2) + 1) / 2 - 1; %% <N-to-ell>

sys.phi = phi; sys.th = th; sys.ell = ell; sys.N = N;

% <simulate-data>
ud0 = rand(T, 1); wdini0 = zeros(ell, 2);
yd0 = sim_pti(sys, ud0, wdini0); wd0 = [ud0, yd0];

wsini = ones(ell, 2); us = zeros(L, 1); ys = sim_pti(sys, us, wsini); name = 'v'; 
% <plot-results>
ysh = ddsim_b(wd0, us, N, wsini); check = norm(ys - ysh)
figure(1)
plot([wsini(:, 1); us]), ax = axis; axis([1 ell + L ax(3:4)]), box off
xlabel('$t$', 'interpreter', 'latex'), ylabel('$u$', 'interpreter', 'latex')
print_fig([name '-u'])
figure(2)
plot([wsini(:, 2); ys], 'r-'), hold on, plot([wsini(:, 2); ysh], 'b--')
ax = axis; axis([1 ell + L ax(3:4)]), box off, hold off
xlabel('$t$', 'interpreter', 'latex'), ylabel('$y$', 'interpreter', 'latex')
print_fig([name '-y'])

% Bilinear
%% <example-b>
%    u(t) y(t) u(t+1) y(t+1) u(t+2)
ell = 2;
Nnl = [0    1    0      0      2     ;
       0    0    1      1      1     ;
       1    0    1      0      1     ];
sysl = drss(ell); [q p] = tfdata(tf(sysl), 'v'); 
thl  = vec(fliplr([q; -p]));
th   = [thl(1:end-1); 0.1 * ones(size(Nnl, 1), 1)]; 
N = [eye(2 * ell + 1); Nnl];
%% <define-sys>
phi = n2phi(N); 
ell = (size(N, 2) + 1) / 2 - 1; %% <N-to-ell>

sys.phi = phi; sys.th = th; sys.ell = ell; sys.N = N;

% <simulate-data>
ud0 = rand(T, 1); wdini0 = zeros(ell, 2);
yd0 = sim_pti(sys, ud0, wdini0); wd0 = [ud0, yd0];

wsini = zeros(ell, 2); us = ones(L, 1); ys = sim_pti(sys, us, wsini); name = 'b'; 
% <plot-results>
ysh = ddsim_b(wd0, us, N, wsini); check = norm(ys - ysh)
figure(1)
plot([wsini(:, 1); us]), ax = axis; axis([1 ell + L ax(3:4)]), box off
xlabel('$t$', 'interpreter', 'latex'), ylabel('$u$', 'interpreter', 'latex')
print_fig([name '-u'])
figure(2)
plot([wsini(:, 2); ys], 'r-'), hold on, plot([wsini(:, 2); ysh], 'b--')
ax = axis; axis([1 ell + L ax(3:4)]), box off, hold off
xlabel('$t$', 'interpreter', 'latex'), ylabel('$y$', 'interpreter', 'latex')
print_fig([name '-y'])
