clear all, close all
switch 6
  case 1, dryer,          ell = 5; Ti = 1:800;  Tv = 801:1000;
  case 2, ballbeam,       ell = 2; Ti = 1:800;  Tv = 801:1000;
  case 3, flutter,        ell = 5; Ti = 1:800;  Tv = 801:1024;
  case 4, robot_arm,      ell = 4; Ti = 1:800;  Tv = 801:1024;
  case 5, heating_system, ell = 2; Ti = 1:600;  Tv = 601:801;
  case 6, exchanger,      ell = 2; Ti = 1:3200; Tv = 3201:4000;
end
N = [eye(2 * ell + 1); zeros(1, 2 * ell + 1)]; 
wd = [u(Ti) y(Ti)];
w  = [u(Tv) y(Tv)]; 
wini = w(1:ell, :); 
us = w(ell+1:end, 1);
ys = w(ell+1:end, 2);
e = @(ysh) 100 * norm(ys - ysh) / norm(ys);
[ysh_m, sysh] = ddsim_m(wd, us, N, wini);
ysh_d = ddsim_b(wd, us, N, wini);
plot(ys, 'k'), hold on, plot(ysh_m, 'r-.'), plot(ysh_d, 'b--')
[e(ysh_m) e(ysh_d)]
