% Data from a flexible robot arm

load robot_arm.dat
u = robot_arm(:,1);
y = robot_arm(:,2);
clear robot_arm
