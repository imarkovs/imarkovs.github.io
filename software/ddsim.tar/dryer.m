% Data of a laboratory setup acting like a hair dryer

load dryer.dat
u = dryer(:,1);
y = dryer(:,2);
clear dryer
