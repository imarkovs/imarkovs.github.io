function ys = ddsim_b(wd, us, N, wini, pp)
ell = (size(N, 2) + 1) / 2 - 1; %% <N-to-ell>
 L = length(us); T = size(wd, 1);
if ~exist('wini'), wini = zeros(ell, 2); end 

%% seperate linear and nonlinear terms
N_l = N(sum(N, 2) == 1, :); phi_l = n2phi(N_l); 
N_n = N(sum(N, 2) ~= 1, :); phi_n = n2phi(N_n); 
mn = size(N_n, 1); q = mn + 2;

%% construct the extended data matrix
xd = form_x(wd, ell); wdext = [wd(1:T-ell, :) phi_n(xd)'];
Swd = blkhank(wdext, ell + L); 
if exist('pp') && pp == 1
  [~, Swd] = lra(Swd, (mn+1) * (ell+L) + ell);
end
Ud = Swd(1:q:end, :); Yd = Swd(2:q:end, :); 
Nd = Swd; Nd([1:q:end 2:q:end], :) = [];

%% construction of the Phi(u) matrix
I = eye(ell+L); u = [wini(:, 1); us];
phi0 = vec(phi_n(form_x([u zeros(ell+L, 1)], ell)));
for i = 1:ell+L
  Phi(:, i) = vec(phi_n(form_x([u I(:, i)], ell))) - phi0;
end

%% solve the system of equations
A = [Ud; Yd(1:ell, :);
     Nd(1:end-mn*ell, :) - Phi(:, ell+1:end) * Yd(ell+1:end, :)];
b = [u; wini(:, 2); phi0 + Phi(:, 1:ell) * wini(:, 2)];
ys = Yd(ell+1:end, :) * pinv(A) * b;
