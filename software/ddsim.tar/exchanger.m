% Liquid-saturated steam heat exchanger

load exchanger.dat
u = exchanger(:,2);
y = exchanger(:,3);
clear exchanger
