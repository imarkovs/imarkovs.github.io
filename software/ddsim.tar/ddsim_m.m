function [ys, sysh] = ddsim_m(wd, us, N, wini)
ell = (size(N, 2) + 1) / 2 - 1; %% <N-to-ell>
 L = length(us); phi = n2phi(N); 
if ~exist('wini'), wini = zeros(ell, 2); end 
thh_ext = lra([phi(blkhank(wd, ell + 1)); wd(ell+1:end, 2)'])';
sysh.th = - thh_ext(1:end-1) / thh_ext(end); 
sysh.phi = phi; sysh.ell = ell; sysh.N = N;
ys = sim_pti(sysh, us, wini);
