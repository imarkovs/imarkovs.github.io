function ans = is_trajectory(w, sys)
ans = norm(sys.th' * sys.phi(blkhank(w, sys.ell + 1)) - w(sys.ell+1:end, 2)');
