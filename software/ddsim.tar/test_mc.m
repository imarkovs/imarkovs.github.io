%% setup
clear all, close all
T = 1000; L = 10; NN = 100; np = 10; S = linspace(0, 0.005, np); 
%% <example-b>
%    u(t) y(t) u(t+1) y(t+1) u(t+2)
ell = 2;
Nnl = [0    1    0      0      2     ;
       0    0    1      1      1     ;
       1    0    1      0      1     ];
sysl = drss(ell); [q p] = tfdata(tf(sysl), 'v'); 
thl  = vec(fliplr([q; -p]));
th   = [thl(1:end-1); 0.1 * ones(size(Nnl, 1), 1)]; 
N = [eye(2 * ell + 1); Nnl];
%% <define-sys>
phi = n2phi(N); 
ell = (size(N, 2) + 1) / 2 - 1; %% <N-to-ell>

sys.phi = phi; sys.th = th; sys.ell = ell; sys.N = N;

wsini = rand(ell, 2); us = rand(L, 1); ys = sim_pti(sys, us, wsini); 
e = @(ysh) 100 * norm(ys - ysh) / norm(ys);
% <simulate-data>
ud0 = rand(T, 1); wdini0 = zeros(ell, 2);
yd0 = sim_pti(sys, ud0, wdini0); wd0 = [ud0, yd0];

for j = 1:np, s = S(j);
  for i = 1:NN
    wn  = randn(T, 2); wd = wd0 + s * norm(wd0) * wn / norm(wn);
    ed(i, j) = e(ddsim_b(wd, us, N, wsini));
    em(i, j) = e(ddsim_m(wd, us, N, wsini));
  end
end
plot(S, mean(ed), 'b--'), hold on, plot(S, mean(em), 'r-')
ax = axis; axis([S(1) S(end) ax(3:4)]), box off
xlabel('noise to signal ratio', 'interpreter', 'latex')
ylabel('$e$, \%', 'interpreter', 'latex'), print_fig('error')
