% Form the product R_k = E_k R_{k-1}

function Rnew = er(E,R)

Rnew{1,1} = conv(E{1,1},R{1,1}) + conv(E{1,2},R{2,1});
Rnew{1,2} = conv(E{1,1},R{1,2}) + conv(E{1,2},R{2,2});
Rnew{2,1} = conv(E{2,1},R{1,1}) + conv(E{2,2},R{2,1});
Rnew{2,2} = conv(E{2,1},R{1,2}) + conv(E{2,2},R{2,2});
