% Compute recursively the MPUM of a vector sequence w
function R = mpum2(w)

[T,q] = size(w);
q1 = q + 1;

% Initialize R = I
R(:,:,1) = eye(q1);
l = zeros(q1,1);

% Recursion
for k = 0:T-1
  ek = simul(w(1:k+1,:),R(1:q,1:q,:));
  [E,l]  = error_mpum(ek,l);
  R  = mult(E,R);
  r21 = R(2,1,:); r21 = r21(:)';
  r22 = R(2,2,:); r22 = r22(:)';  
  disp([r21(1:min(3,length(r21))) r22(1:min(3,length(r21)))] / R(2,1,1))
  %print_iter(k,ek,l(2),R(2,:,:)); 
  %r = R(1,1,:); disp(r(:)'), pause
end


% Compute the first q elements of the error e = R(\sigma)w
function [ek,l] = simul(w,R)

l  = size(R,3);
ek = 0;
for i = 1:l
  ek = ek + R(:,:,i) * w(end-i+1,:)';
end


% Form the error
function [E,l] = error_mpum(ek,l)

EPS = 1e-7; % tolerance for ek = 0
q  = length(ek);
q1 = length(l);

% find index_min( l(j) | e(j) ~= 0 )
ll = l(1:q);
ll(find(abs(ek) < EPS)) = -1;
[ml,iml] = min(ll); 

% assign E
E(:,:,1) = eye(q1);
E(:,:,2) = zeros(q1);
if (abs(ek(iml)) < EPS) | (l(iml) > l(q1))
  E(1:q,q1,1) = - ek(1:q);
  E(q1,q1,2) = 1; % = s
else
  j = 1:q; j(iml) = [];
  E(j,iml,1)  = - ek(j) / ek(iml);
  E(iml,q1,1) = -ek(iml);
  E(q1,iml,2) = 1 / ek(iml); % = s/ek(iml)
  l([iml,q1]) = l([q1,iml]); % swap the iml and q1 entries
end
E(q1,q1,1) = 0;
l(q1) = l(q1) + 1;


% Form the product R_k = E_k R_{k-1}
function Rnew = mult(E,R)

EPS = 1e-10;
q1 = size(R,1);
l  = size(R,3);

Rnew(:,:,1) = E(:,:,1) * R(:,:,1);
for i = 2:l
  Rnew(:,:,i) = E(:,:,1) * R(:,:,i) + E(:,:,2) * R(:,:,i-1);
  % if the coefficient is small, make it zero
  if norm(Rnew(:,:,i)) < EPS
    Rnew(:,:,end) = zeros(q1);
  end
end
Rnew(:,:,l+1) = E(:,:,2) * R(:,:,l);


% Print the results on the current iteration step
function print_iter(k,ek,l,R)

fprintf('%2d & ', k)
if length(ek) > 1
  print_mat(ek), fprintf(' & '), print_mat(l), fprintf(' & ')
else
  fprintf('%4.1f & %d & ',ek,l(1))
end
%print_mat(E), fprintf(' & '), 
print_mat(R)
fprintf('\\\\[5mm]\n')


