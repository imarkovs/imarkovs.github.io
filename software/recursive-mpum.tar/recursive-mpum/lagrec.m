% Lag recursive computation of the MPUM
function R = lagrec(w)

q = size(w,2);
EPS = 1e-7;

if w == 0
  R = eye(q);
  return
else
  r = detect_annihilator(w);
  if isempty(r)
    R = ppck(zeros(q),0);
    return
  end
  D = find_dual(r);
  w = simulate(D,w);
  s = lagrec(w);
  if norm(punpck(s)) > EPS
    R = prowjoin(r, pmul(s,D));
  else
    R = r;
  end
end


% Find the first time when H(w) is rank deficient
function r = detect_annihilator(w)

TOL = 1e-7;
[T,q] = size(w);

l = 1;
s = svd(w);
while (s(end) > TOL)
  l = l + 1;
  if (T - l + 1 > 0)
    s = svd(blkhankel(w,l));
  else
    r = [];
    return
  end
end
[u,s,v] = svd(blkhankel(w,l),0);
r = u(:,end);
r = ppck(r',l-1);


% Find the dual to ker(r) system
function D = find_dual(r)

[t,tt,c] = pinfo(r);

% Solve the Bezout equation
[b,a] = axbyc(psel(r,1,1),pscl(psel(r,1,2),-1),1);
D = ppck([zeros(1,c); zeros(c-2,2) eye(c-2)],0);
D = pput(D,1,1,a);
D = pput(D,1,2,b);


% Simulate R(\sigma) with w
function Rw = simulate(R,w);

[T,q] = size(w);
[t,r,c,d] = pinfo(R);
R = punpck(R);
w = w'; w = w(:);

Rw = zeros(r,T-d-1);
for i = 1:T-d-1
  Rw(:,i) = R * w(1+(i-1)*q:(i-1)*q+(d+1)*q);
end
Rw = Rw';

