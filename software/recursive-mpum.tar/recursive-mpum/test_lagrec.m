addpath ../ident % blkhankel
addpath ../polyx 

n = 4;
p = 2;
m = 1;
T = 50;

sys = drss(n,p,m);
u = rand(T,m);
y = lsim(sys,u);
w = [u y];

% convert to kernel
[a0,b0,c0,d0] = ssdata(sys);
[Q0,P0] = ss2lmf(a0,b0,c0,d0);
R0 = pcoljoin(pscl(Q0,-1),P0);

% recursive modeling
R = lagrec(w);
Q = pscl(psel(R,':',[1:m]),-1);
P = psel(R,':',[m+1:m+p]);
[a,b,c,d] = lmf2ss(Q,P);

% check
norm(ss(a,b,c,d)-ss(a0,b0,c0,d0),'inf')

