%w = [0 1 1 1 1 1 1 1 1 1]';
%w = [1 1 2 3 5 8 13 21 34 55]';
%w = [ 0 0 1 1 0 ]';

w = [ 0 0 -1 0 0 0 1 -1 1 0 ; 
      0 0  1 0 1 0 1  1 2 1 ]';

%!rm -f d.tex
%diary d.tex
R = mpum2(w);
%diary off


%    setenv LD_ASSUME_KERNEL 2.4.1

