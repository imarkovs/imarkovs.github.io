% Print a polynomial matrix in LaTeX format
function print_mat(M)

EPS = 1e-10;
[m,n,l] = size(M);
syms z

fprintf('\\bmx ')
for i = 1:m
  for j = 1:n
    p = M(i,j,:); p = p(:);
    % truncate zeros at the end
    while ( abs(p(end)) < EPS & length(p) > 1 )
      p(end) = [];
    end
    l = length(p);
    exp = '';
    for k = 1:l
      if abs(p(k)) > EPS
        if strcmp(exp,'')
          exp = [ num2str(p(k)) '\, z^' int2str(k-1) ];
        elseif p(k) > 0 
          exp = [ exp ' + ' num2str(p(k)) '\, z^' int2str(k-1) ];
        else
          exp = [ exp num2str(p(k)) '\, z^' int2str(k-1) ];
        end
      end
    end
    if strcmp(exp,'')
      exp = '0';
    end
    if j == n
      fprintf('%s ', exp)
    else
      fprintf('%s & ', exp)
    end
  end
  if i < m
   fprintf('\\\\ ')
  end
end
fprintf('\\emx ')
