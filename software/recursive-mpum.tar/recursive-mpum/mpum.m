% Compute recursively the MPUM of a scalar sequence w

function R = mpum(w)

T = length(w);
w = w(:)'; % make it a row vector 

% Initialize
R{1,1} = 1; R{1,2} = 0; R{2,1} = 0; R{2,2} = 1;
l  = 0;
% Recursion
for k = 0:T-1
  ek = simul(w,R,k);
  E  = error_mpum(ek,l,k);
  [R,l]  = mult(E,R);
  print_iter(k,ek,l,E,R); %pause
end

% Form the error
function E = error_mpum(ek,l,k)

EPS = 1e-10; % tolerance for ek = 0

E{1,1} = 1;
if (abs(ek) < EPS) | (l > k/2)
  E{1,2} = -ek;
  E{2,1} = 0;
  E{2,2} = [0 1];
else  
  E{1,2} = -ek;
  E{2,1} = [0 1/ek];
  E{2,2} = 0;
end

% Form the product R_k = E_k R_{k-1}
function [Rnew,lnew] = mult(E,R)

Rnew{1,1} = add(conv(E{1,1},R{1,1}),conv(E{1,2},R{2,1}));
Rnew{1,2} = add(conv(E{1,1},R{1,2}),conv(E{1,2},R{2,2}));
Rnew{2,1} = add(conv(E{2,1},R{1,1}),conv(E{2,2},R{2,1}));
Rnew{2,2} = add(conv(E{2,1},R{1,2}),conv(E{2,2},R{2,2}));
lnew  = max(length(Rnew{1,1}),length(Rnew{1,2})) - 1;

% Polynomial addition
function c = add(a,b)

a = trimzeros(a);
b = trimzeros(b);

[l,in] = min([length(a),length(b)]);
if in == 1
  c = [a(1:l)+b(1:l) b(l+1:end)];
else
  c = [a(1:l)+b(1:l) a(l+1:end)];
end

c = trimzeros(c);

% Remove 0's at the end of the polynomial a 
function  a = trimzeros(a)

EPS = 1e-10; % tolerance for deciding when a number is 0

l = length(a);
k = 0;
while ( k < l-1 ) & ( abs(a(end-k)) < EPS )
  k = k + 1;
end
a = a(1:end-k);

% Compute the first element of the error e = R(\sigma) w at time k
function [ek,l] = simul(w,R,k)

r  = R{1,1};
l  = length(r) - 1;
ek = r * w(k+1:-1:k+1-l)';

% Print the results on the current iteration step
function print_iter(k,ek,l,E,R)

fprintf('%2d & %4.1f & %d & ', k, ek, l)
print_mat(E)
fprintf(' & ')
print_mat(R)
fprintf('\\\\[5mm]\n')

% Print a polynomial matrix in LaTeX format
function print_mat(M)

EPS = 1e-10;
[m,n] = size(M);
syms z

fprintf('\\bmx ')
for i = 1:m
  for j = 1:n
    p = M{i,j};
    l = length(p);
    exp = '';
    for k = 1:l
      if abs(p(k)) > EPS
        if strcmp(exp,'')
          exp = latex(p(k) * z^(k-1));
        elseif p(k) > 0 
          exp = [ exp ' + ' latex(p(k) * z^(k-1)) ];
        else
          exp = [ exp latex(p(k) * z^(k-1)) ];
        end
      end
    end
    if strcmp(exp,'')
      exp = '0';
    end
    if j == n
      fprintf('%s ', exp)
    else
      fprintf('%s & ', exp)
    end
  end
  if i < m
   fprintf('\\\\ ')
  end
end
fprintf('\\emx ')
