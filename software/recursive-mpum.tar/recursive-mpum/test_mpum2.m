clear all, close all

nx = 2;
m  = 1;
p  = 1;
T  = 20;
sys0 = tf([1 .5 1],[1 .85 1],-1); % drss(nx,p,m); % load sys0;
u  = rand(T,m);
y  = lsim(sys0,u);
%u = [];
%y = initial(sys0,rand(nx,1),T);
w  = [y u];

%!rm -f d.tex
%diary d.tex
R = mpum2(w);
%diary off

%r0 = [1 .85 0 -1]
r0 = [1 .85 1 -1 -0.5 -1]
a2 = [R(2,1,1) R(2,1,2) R(2,1,3) R(2,2,1) R(2,2,2) R(2,2,3)] / R(2,1,1)

