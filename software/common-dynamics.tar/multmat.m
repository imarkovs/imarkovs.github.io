function Mc = multmat(C, m, dA)
n = size(C, 2); d1 = size(C, 1) / m;
Mc = zeros((d1 + dA) * m, (dA + 1) * m);
for i = 0:dA
    Mc((i * m + 1):((i + d1) * m), (i * n + 1):((i + 1) * n)) = C;
end
