function [rc, y0h, yth] = common_dynamics(y, nt, nc, opt)
% x -> y, K -> nt, G = 2
N = size(y, 1); L = round(N / 2); M = N - L + 1;
if ~exist('opt'), opt.m = 'gv'; opt.tls = 0; end
% step 1
H1 = blkhank(y(:, 1), L); [r1, p1] = lra(H1, nt(1) + nc);
H2 = blkhank(y(:, 2), L); [r2, p2] = lra(H2, nt(2) + nc);
if ~isfield(opt, 'tls') || ~opt.tls
  r1 = poly(eig(p1(1:end-1, :) \ p1(2:end, :)));
  r2 = poly(eig(p2(1:end-1, :) \ p2(2:end, :)));
else
  r1 = poly(eig(tls(p1(1:end-1, :), p1(2:end, :))));
  r2 = poly(eig(tls(p2(1:end-1, :), p2(2:end, :))));
end
% step 2
switch lower(opt.m)
  case 'papy'
    [rc, pc] = lra([p1 p2], nc); 
    if ~isfield(opt, 'tls') || ~opt.tls
      rc = poly(eig(pc(1:end-1, :) \ pc(2:end, :)));
    else
      rc = poly(eig(tls(pc(1:end-1, :), pc(2:end, :))));
    end
  case 'gv' 
    [rc, ~, p1p2h] = lra([p1 p2]', nt(1) + nt(2) + nc); 
    pc = p1p2h(1:nt(1) + nc, :)' * rc(:, 1:nt(1) + nc)'; 
    if ~isfield(opt, 'tls') || ~opt.tls
      rc = poly(eig(pc(1:end-1, :) \ pc(2:end, :)));
    else
      rc = poly(eig(tls(pc(1:end-1, :), pc(2:end, :))));
    end
  case 'raw' 
    j = N - max(nt) - nc + 1;
    H1 = blkhank(y(:, 1), nt(1) + nc, j);
    H2 = blkhank(y(:, 2), nt(2) + nc, j);
    [rc, ~, p1p2h] = lra([H1; H2], nt(1) + nt(2) + nc); 
    pc = p1p2h(1:nt(1) + nc, :)' * rc(:, 1:nt(1) + nc)'; 
    if ~isfield(opt, 'tls') || ~opt.tls
      rc = poly(eig(pc(1:end-1, :) \ pc(2:end, :)));
    else
      rc = poly(eig(tls(pc(1:end-1, :), pc(2:end, :))));
    end
  case 'alcf'
    [rc, rh] = alcf_ss(collect(r1', r2'), 1, nc); 
  otherwise
    disp('Unknown method.')
end
% step 3
if nargout > 1
  if ~exist('rh')
    [~, rh] = costfun(rc(2:end)', collect(r1', r2'), 1, max(nt)); rc = rc';
  end
  [y0h, yth] = ry2yh2(rh, rc, y); 
end
