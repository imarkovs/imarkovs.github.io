function yh = ry2yh(r, y)
T = length(y);
R = multmat(fliplr(r)', 1, T - length(r))'; P = null(R);
yh = P * (P \ y);
