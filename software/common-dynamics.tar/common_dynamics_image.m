function [ch, yh1, yh2] = common_dynamics_image(y1, y2, n1, n2, nc, opt)
% x -> y, K -> n, G = 2
N = length(y1); L = round(N / 2); M = N - L + 1;
if ~exist('opt'), opt.m = 'papy'; opt.tls = 1; end
% step 1
H1 = blkhank(y1, L); [r1, p1] = lra(H1, n1 + nc);
H2 = blkhank(y2, L); [r2, p2] = lra(H2, n2 + nc);
<<image -> kernel>>
% step 2
switch lower(opt.m)
  case 'papy'
    [rc, pc] = lra([p1 p2], nc); 
    <<ch -> rh>>
  case 'gv1'
    rc = lra([p1 p2]', n1 + n2 + nc); 
    pc = p1 * rc(:, 1:n1 + nc)'; 
    % pc = p2 * rc(:, n1 + nc + 1:end)'; 
    <<ch -> rh>>
  case 'gv2' 
    [rc, ~, p1p2h] = lra([p1 p2]', n1 + n2 + nc); 
    pc = p1p2h(1:n1 + nc, :)' * rc(:, 1:n1 + nc)'; 
    % pc = p1p2h(n1 + nc + 1:end, :)' * rc(:, n1 + nc + 1:end)'; 
    <<ch -> rh>>
  case 'alcf'
    [ch, rh] = alcf_ss(collect(r1', r2'), 1, nc); 
  otherwise
    disp('Unknown method.')
end
% step 3
if nargout > 1
  [f, rh] = costfun(ch(:, 2:end)', collect(r1', r2'), 1, max(n1, n2));
  yh1 = ry2yh(rh(:, 1)', y1); yh2 = ry2yh(rh(:, 2)', y2); 
end
