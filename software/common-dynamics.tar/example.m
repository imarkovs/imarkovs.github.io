clear all, 

% simulation parameters
T = 1000; s = 1;

% true signals
t = (1:T)'; 
y01 = 2 * sin(0.05 * t) + 1 * sin(0.03 * t);
y02 = 2 * sin(0.05 * t) - 1 * sin(0.03 * t);

% structured noises
yt1 = -2 * sin(0.04 * t - 150); 
yt2 =  2 * sin(0.07 * t + 150);

% noisy signals
y1 = y01 + yt1 + s * randn(size(y01));
y2 = y02 + yt2 + s * randn(size(y02));

% plot signals
%figure(1), hold off, plot(t, y01, 'r-'), hold on, plot(t, y1, 'k:')
%figure(2), hold off, plot(t, y02, 'r-'), hold on, plot(t, y2, 'k:')

% estimation
y  = [y1  y2]; nt = [2 2]; nc = 4; opt.m = 'gv';
[ch, y0h, yth] = common_dynamics(y, nt, nc, opt); 

% check results
y0 = [y01 y02]; yt = [yt1 yt2];  
norm(y0(:) - y0h(:)) / norm(y0(:))
norm(yt(:) - yth(:)) / norm(yt(:))

% figure
Tf = 250;

figure % observed y1
plot(t, y(:, 1), 'r-'), hold on
plot(t, y0h(:, 1) + yth(:, 1), 'b--', 'linewidth', 3) 
xlabel(''), ylabel('y1'), title('observed'), axis([1 Tf -5 5])
set(gca, 'fontsize', 20), print -depsc f11.eps

figure % observed y2
plot(t, y(:, 2), 'r-'), hold on
plot(t, y0h(:, 2) + yth(:, 2), 'b--', 'linewidth', 3) 
xlabel('time'), ylabel('y2'), title(''), axis([1 Tf -5 5])
set(gca, 'fontsize', 20), print -depsc f21.eps

figure % true y01
plot(t, y0(:, 1), 'r-'), hold on
plot(t, y0h(:, 1), 'b--') 
xlabel(''), ylabel('y1'), title('true'), axis([1 Tf -5 5])
set(gca, 'fontsize', 20), print -depsc f12.eps

figure % true y02
plot(t, y0(:, 2), 'r-'), hold on
plot(t, y0h(:, 2), 'b--') 
xlabel('time'), ylabel('y2'), title(''), axis([1 Tf -5 5])
set(gca, 'fontsize', 20), print -depsc f22.eps

figure % structured noise yt1
plot(t, yt(:, 1), 'r-'), hold on
plot(t, yth(:, 1), 'b--') 
xlabel(''), ylabel('y1'), title('structured noise'), axis([1 Tf -5 5])
set(gca, 'fontsize', 20), print -depsc f13.eps

figure % structured noise yt2
plot(t, yt(:, 2), 'r-'), hold on
plot(t, yth(:, 2), 'b--') 
xlabel('time'), ylabel('y2'), title(''), axis([1 Tf -5 5])
set(gca, 'fontsize', 20), print -depsc f23.eps

figure % random noise e1
plot(t, y(:, 1) - y0(:, 1) - yt(:, 1), 'r-'), hold on
plot(t, y(:, 1) - y0h(:, 1) - yth(:, 1), 'b--')
xlabel(''), ylabel('y1'), title('random noise'), axis([1 Tf -5 5])
set(gca, 'fontsize', 20), print -depsc f14.eps

figure % random noise e2
plot(t, y(:, 2) - y0(:, 2) - yt(:, 2), 'r-'), hold on
plot(t, y(:, 2) - y0h(:, 2) - yth(:, 2), 'b--') 
xlabel('time'), ylabel('y2'), title(''), axis([1 Tf -5 5])
set(gca, 'fontsize', 20), print -depsc f24.eps
