function [Ch, Ph, f] = alcf_ss(P, m, d)
dP = size(P, 1) / m - 1; dA = dP - d; T = 2 * dP + 1;
Mp = multmat(P, m, T - dP - 1); Y = lra(Mp, size(Mp, 1) - d)';
for i = 1:d, w{i} = reshape(Y(:, i), m, T); end
Ch = lra(moshank(w, d + 1), d * m)'; Ch = Ch / Ch(1:m, :);
[f, Ph] = costfun(Ch(m+1:end, :), P, m, dA);
