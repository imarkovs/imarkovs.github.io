function [rc, y0h, yth] = common_dynamics_alcf(y, nt, nc)
% step 1
r1 = poly(eig(y02ss(y(:, 1), nt(1) + nc))); 
r2 = poly(eig(y02ss(y(:, 2), nt(2) + nc))); 
% step 2
[rc, rh] = alcf_ss(collect(r1', r2'), 1, nc); 
% step 3
[y0h, yth] = ry2yh2(rh, rc, y);
