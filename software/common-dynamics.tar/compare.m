clear all 

% simulation parameters
T = 150; t = (1:T)'; 
k = [2 2]; kc = 2; n = 2 * k; nc = 2 * kc;
s = 0.25; N = 100;

w = rand(1, kc + sum(k)); phi = rand(1, kc + sum(k));
Y = sin(2 * pi * t * w + phi(ones(T, 1), :));
y(:, 1) = Y(:, 1:(kc + k(1))) * rand(kc + k(1), 1);
y(:, 2) = Y(:, [1:kc (kc + k(1) + 1):(kc + sum(k))]) * rand(kc + k(2), 1);
% plot(y, '-'), hold on, plot(yd, '--')

sys1 = y02ss(y(:, 1), n(1) + nc); 
sys2 = y02ss(y(:, 2), n(2) + nc); 
[ch, yh] = common_dynamics_alcf(y, n, nc); norm(y(:) - yh(:)) / norm(y(:))
pc = poly(roots(ch))';

%% methods
opt{1}.m = 'papy'; opt{1}.tls = 1;
opt{2}.m = 'papy'; opt{2}.tls = 0;
opt{3}.m = 'gv'  ; opt{3}.tls = 0;
opt{4}.m = 'raw' ; opt{4}.tls = 0;
opt{5}.m = 'alcf'; opt{5}.tls = 0;

%% MC simulation
for i = 1:N
  yt = randn(size(y)); yd = y + s * yt / norm(yt(:)) * norm(y(:)); % noisy data
  for j = 1:length(opt)
    [ch, yh] = common_dynamics(yd, n, nc, opt{j}); 
    Ph{j}(:, i) = poly(roots(ch))'; Yh{j}(:, i) = yh(:);
  end
end

%% print results
vec_y = y(:); Y = vec_y(:, ones(1, N)); Pc = pc(:, ones(1, N));
for j = 1:length(opt)
  res(j, :) = [norm(Y - Yh{j}, 'fro') / norm(Y),  norm(Pc - Ph{j}, 'fro') / norm(Pc)];
end

[{'' 'Ey' 'Ez'}; [{'papy'; 'papy-ls'; 'gv'; 'raw'; 'alcf'}, num2cell(res)]]
