clear all 

% simulation parameters
k = [8 8]; kc = 6; kt = k - kc;
n = 2 * k; nc = 2 * kc; nt = 2 * kt;
T = 150; t = (1:T)'; N = 50;
ns = 7; S = linspace(0, 0.1, ns); 

w = rand(1, kc + sum(kt)); phi = rand(1, kc + sum(kt));
%w =   [0.0651    0.0918    0.4145    0.4396    0.5948    0.6918    0.7197    0.8455    0.8556    0.9706];
%phi = [0.0826    0.0477    0.8644    0.4936    0.8085    0.4919    0.0976    0.1284    0.7002    0.1510];
B = sin(2 * pi * t * w + phi(ones(T, 1), :));
y(:, 1) = B(:, 1:(kc + kt(1))) * rand(kc + kt(1), 1);
y(:, 2) = B(:, [1:kc (kc + kt(1) + 1):(kc + sum(kt))]) * rand(kc + kt(2), 1);
% plot(y, '-'), hold on, plot(yd, '--')
sys1 = y02ss(y(:, 1), n(1)); 
sys2 = y02ss(y(:, 2), n(2)); 
[rc, yh] = common_dynamics_alcf(y, nt, nc); 
norm(y(:) - yh(:)) / norm(y(:))
pc = poly(roots(rc))'; Pc = pc(:, ones(1, N));

%% methods
methods_names = {'papy'; 'papy-ls'; 'gv'; 'raw'; 'alcf'};
opt{1}.m = 'papy'; opt{1}.tls = 1;
opt{2}.m = 'papy'; opt{2}.tls = 0;
opt{3}.m = 'gv'  ; opt{3}.tls = 0;
opt{4}.m = 'raw' ; opt{4}.tls = 0;
opt{5}.m = 'alcf'; opt{5}.tls = 0;

%% MC simulation
vec_y = y(:); Y = vec_y(:, ones(1, N)); 
for k = 1:ns
  s = S(k);
  for i = 1:N
    yt = randn(size(y)); yd = y + s * yt / norm(yt(:)) * norm(y(:)); % noisy data
    for j = 1:length(opt)
      [rc, yh] = common_dynamics(yd, n, nc, opt{j}); 
      Ph{j}(:, i) = poly(roots(rc))'; Yh{j}(:, i) = yh(:);
    end
  end
  for j = 1:length(opt)
    e_y(j, k) = norm(Y - Yh{j}, 'fro') / norm(Y);
    e_p(j, k) = norm(Pc - Ph{j}, 'fro') / norm(Pc);
  end
end
 
%% results  
figure(1), plot(S, e_y), legend(methods_names, 'location', 'northwest')
figure(2), plot(S, e_p), legend(methods_names, 'location', 'northwest')
