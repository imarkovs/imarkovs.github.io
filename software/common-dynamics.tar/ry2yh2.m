function [y0h, yth] = ry2yh2(rh, rc, y)
T = length(y); nc = length(rc) - 1;
[rt1, e1] = deconv(rh(:, 1), rc);
[rt2, e2] = deconv(rh(:, 2), rc);

Rt1 = multmat(flip(rt1), 1, T - length(rt1))'; Pt1 = null(Rt1);
Rt2 = multmat(flip(rt2), 1, T - length(rt2))'; Pt2 = null(Rt2);
Rc  = multmat(flip(rc), 1, T - length(rc))';   Pc  = null(Rc);

g = [Pc Pt1] \ y(:, 1); y0h(:, 1) = Pc * g(1:nc); yth(:, 1) = Pt1 * g(nc+1:end); 
g = [Pc Pt2] \ y(:, 2); y0h(:, 2) = Pc * g(1:nc); yth(:, 2) = Pt2 * g(nc+1:end);
