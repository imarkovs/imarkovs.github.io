function [sys, yh, xini, err] = y02ss(y, n)

if length(size(y)) == 2
    [p, T] = size(y);
    if p > T
        y = [zeros(1, T); y];
    else
        y = [zeros(p, 1), y];
    end
else
    error('3d y not implemented yet')
end
    
[sys, yh, O, C, err] = h2ss(y, n); yh = yh(2:end, :);
xini = sys.b; sys = ss(sys.a, [], sys.c, [], -1);