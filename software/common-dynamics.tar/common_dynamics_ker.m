function [ch, yh1, yh2] = common_dynamics_ker(y1, y2, n1, n2, nc)
% step 1
r1 = poly(eig(y02ss(y1, n1 + nc))); 
r2 = poly(eig(y02ss(y2, n2 + nc))); 
% step 2
[ch, rh] = alcf_ss(collect(r1', r2'), 1, nc); 
% step 3
yh1 = ry2yh(rh(:, 1)', y1); 
yh2 = ry2yh(rh(:, 2)', y2);
