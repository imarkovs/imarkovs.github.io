function [ch, yh1, yh2] = common_dynamics_papy(y1, y2, n1, n2, nc, method, tls_or_ls, L)
% x -> y, K -> n, G = 2
N = length(y1); if ~exist('L'), L = round(N / 2); end, M = N - L + 1;
if ~exist('method'), method = 1; end
if ~exist('tls_or_ls'), tls_or_ls = 1; end
H1 = blkhank(y1, L); [r1, p1] = lra(H1, n1 + nc);
H2 = blkhank(y2, L); [r2, p2] = lra(H2, n2 + nc);
if method == 1,
  [rc, pc] = lra([p1 p2], nc); 
elseif method == 2,
  rc = lra([p1 p2]', n1 + n2 + nc); 
  pc = p1 * rc(:, 1:n1 + nc)'; 
  % pc = p2 * rc(:, n1 + nc + 1:end)'; 
else 
  [rc, ~, p1p2h] = lra([p1 p2]', n1 + n2 + nc); 
  pc = p1p2h(1:n1 + nc, :)' * rc(:, 1:n1 + nc)'; 
  % pc = p1p2h(n1 + nc + 1:end, :)' * rc(:, n1 + nc + 1:end)'; 
end
if tls_or_ls
  ch = poly(eig(tls(pc(1:end-1, :), pc(2:end, :))));
else
  ch = poly(eig(pc(1:end-1, :) \ pc(2:end, :)));
end
if nargout > 1
  if tls_or_ls
    r1 = poly(eig(tls(p1(1:end-1, :), p1(2:end, :))));
    r2 = poly(eig(tls(p2(1:end-1, :), p2(2:end, :))));
  else
    r1 = poly(eig(p1(1:end-1, :) \ p1(2:end, :)));
    r2 = poly(eig(p2(1:end-1, :) \ p2(2:end, :)));
  end
  [f, rh] = costfun(ch(:, 2:end)', collect(r1', r2'), 1, max(n1, n2));
  yh1 = ry2yh(rh(:, 1)', y1); 
  yh2 = ry2yh(rh(:, 2)', y2); 
end
