function [wc, bwc] = const_wc(Rlin, Rc, q, T); 
ell = size(Rlin, 2) / q - 1;
bwc = pinv(multmat(Rlin, q, T) * kron(ones(T, 1), eye(q))) * kron(ones(T - ell, 1), -Rc);
wc = kron(ones(T, 1), bwc');
