function [Rlin, Rc, wh, info] = ati_ident(wd, m, ell, opt)
[Td, q] = size(wd); L = ell + 1;
if ~exist('opt'); opt = []; end

ss.m = [1; L * ones(q, 1)];
ss.w = [inf * ones(Td-ell, 1); ones(q * Td, 1)]; 
[ph, info] = slra([ones(Td-ell, 1); vec(wd)], ss, q * ell + m + 1, opt);
wh = reshape(ph(Td-ell+1:end), Td, q);

R_ = info.Rh(:, 2:end); Rlin = []; for i = 1:L, Rlin = [Rlin R_(:, i:L:end)]; end
Rc = info.Rh(:, 1);
