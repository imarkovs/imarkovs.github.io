function wc = min_norm_wc(Rlin, Rc, q, T); 
ell = size(Rlin, 2) / q - 1;
wc = pinv(multmat(Rlin, q, T)) * kron(ones(T - ell, 1), -Rc);
wc = reshape(wc, q, T)';
