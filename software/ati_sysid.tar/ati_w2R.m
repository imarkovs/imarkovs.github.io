function [Rlin, Rc] = ati_w2R(wd, c, opt)
[Td, q] = size(wd); L = c(2) + 1; r = c(1) * L + c(3) + 1;
if ~exist('opt')
  [~, R] = lra([ones(1, Td-c(2)); hank(wd, L)], r);
else
  [~, R] = glra2([ones(1, Td-c(2)); hank(wd, L)]', 1, r); R = R';
end
Rc = R(:, 1); Rlin = R(:, 2:end);
