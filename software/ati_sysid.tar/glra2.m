function [Xh, R] = glra(X, k, r, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
X1 = X(:, 1:k); X2 = X(:, k+1:end);
[U, S, V] = svd(X1); rX1 = sum(diag(S) > tol);
P  = U(:, 1:rX1) * U(:, 1:rX1)';
Pp = U(:, rX1+1:end) * U(:, rX1+1:end)';
[~, ~, H] = lra((Pp * X2)', r - rX1);
Xh = [X1 P * X2 + H']; R = null(Xh);
