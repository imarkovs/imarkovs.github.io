function wh = ati_ddint(wd, w)
[T, q] = size(w);
H = hank(wd, T); vec_w = vec(w'); I = find(~isnan(vec_w)); 
A = [H(I, :); ones(1, size(H, 2))]; b = [vec_w(I); 1]; g = pinv(A) * b; 
% lasso_cvx(A, b, 1); % lseq(H(I, :), vec_w(I), ones(1, size(H, 2)), 1); 
wh = reshape(H * g, q, T)';
