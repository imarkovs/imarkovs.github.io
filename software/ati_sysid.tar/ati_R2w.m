function w = ati_R2w(R, Rc, q, T);
ell = size(R, 2) / q - 1;
M = multmat(R, q, T); N = null(M); z = rand(size(N, 2), 1);
w =  M \ kron(ones(T - ell, 1), -Rc) + N * z;
w = reshape(w, q, T)';
