clear all, addpath ../bt
%% benchmark-system
Q = [0 0 0 0.28261 0.50666]; 
P = [1 -1.41833 1.58939 -1.31608 0.88642];
B = ss(tf(Q, P, -1)); 

%% simulation parameters
[p, m] = size(B); n = order(B); ; % m = 1; p = 1; n = 2; 
Td = 1000; Tp = n; Tf = 50; 
N  = 50; np = 7; S = linspace(0, 0.2, np); 

%% data-generating system
% B  = drss(n, p, m); 
q = m + p; T = Tp + Tf; 
ell = lag(B); c = [m, ell, n];

%% simulated data
wd0 = B2w(B, Td);
w0  = B2w(B, T); 
w   = w0; w(Tp+1:end, m+1:end) = NaN;

%% validation critera
eBh = @(Bh) norm(B - Bh) / norm(B);
ewh = @(wh) 100 * norm(w0 - wh, 'fro') / norm(w0, 'fro');

for j = 1:np
  s = S(j) 
  for i = 1:N, i = i
    wn  = randn(size(wd0)); wd = wd0 + s * norm(wd0) * wn / norm(wn);

%% direct data-driven method
wh1 = ddint(wd, w, [], c); 

%% model-based method
Bh2 = ss(n4sid(iddata(wd(:, m+1:end), wd(:, 1:m)), n, ...
              'Feedthrough', ones(1, m) , 'DisturbanceModel', 'none'));
wh2 = ddint(Bh2, w);

%% ML method based on SLRA
Bh3 = ident(wd, m, ell); 
wh3 = ddint(Bh3, w);

EB(i, j, :) = [NaN, eBh(Bh2), eBh(Bh3)];
EW(i, j, :) = [ewh(wh1), ewh(wh2), ewh(wh3)];
  
  end
end

%% results
mEB = squeeze(mean(EB)); 
figure(1), plot(S, mEB(:, 2:end)')
xlabel('s'), ylabel('e(Bh)')
legend('n4sid', 'ml')
ax = axis; axis([S(1) S(end) 0 ax(4)]), 
print_fig('eb-lti')

mEW = squeeze(mean(EW)); 
figure(2), plot(S, mEW)
xlabel('s'), ylabel('e(wh)')
legend('DDD', 'n4sid', 'ml')
ax = axis; axis([S(1) S(end) 0 ax(4)]), 
print_fig('ew-lti')
