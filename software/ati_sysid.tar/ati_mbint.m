function wh = ati_mbint(Blin, wc, w)
[T, q] = size(w); 
wh = ddint(Blin, w - wc) + wc;
