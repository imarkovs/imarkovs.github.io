clear all, close all

%% data-generating system
M = 1; d = 0.1; k = 1;
B = c2d(ss(tf(1, [M d k])), 0.1); 
B = ss(B.a, [], B.c, [], -1);

%% simulation parameters
[p, m] = size(B); n = order(B);
Td = 100; T = 10; nm = T - n;
N = 100; np = 5; S = linspace(0, 0.001, np); 

%% data-generating system
% B  = drss(n, p, m); 
q = m + p; R = B2R(B); Rc = 1 * ones(size(R, 1), 1);
ell = lag(B); c = [m, ell, n];

%% simulated data
wd0 = ati_R2w(R, Rc, q, Td); % plot(wd0)
w0  = ati_R2w(R, Rc, q, T);

w = w0; 
% Im = randperm(q * T); Im = Im(1:nm); 
Im = T-nm+1:T;
w(Im) = NaN;

%% validation critera
eBh = @(Rh) 100 * norm([Rc R] - Rh) / norm([Rc R]);
ewh = @(wh) 100 * norm(w0(Im) - wh(Im)) / norm(w0(Im));

for j = 1:np
  s = S(j) 
  for i = 1:N, i = i
    wn = randn(size(wd0)); 
    wd = wd0 + s * norm(wd0) * wn / norm(wn);

    %% ATI direct data-driven method
    wh1  = ati_ddint(wd, w); % wh1_ = ati_ddint2(wd, w); 

    %% Method based on difference equation representation
    [Rh3, Rch3] = ati_w2R(wd, c); R3 = [Rch3 Rh3]; R3 = R3 / R3(1); 
    Bh3 = R2ss(Rh3, q, 1:q, c); 
    wch3 = min_norm_wc(Rh3, Rch3, q, T); 
    wh3  = ati_mbint(Bh3, wch3, w);

    [Rh3_, Rch3_] = ati_w2R(wd, c, 1); R3_ = [Rch3_ Rh3_]; R3_ = R3_ / R3_(1); 
    Bh3_ = R2ss(Rh3_, q, 1:q, c);
    wch3_ = min_norm_wc(Rh3_, Rch3_, q, T); 
    wh3_ = ati_mbint(Bh3_, wch3_, w);

    %% centering + LTI identification
    wch4 = mean(wd);
    wd_ = wd - wch4(ones(Td, 1), :);
    Bh4 = ss(n4sid(iddata(wd_(:, m+1:end), wd_(:, 1:m)), n, 'Feedthrough', ones(1, m)));
    wh4  = ati_mbint(Bh4, wch4(ones(T, 1), :), w);
    R4 = [wch4 B2R(Bh4)]; R4 = R4 / R4(1); 

    %% ML method based on SLRA
    opt.opt.Rini = [Rh3_, Rch3_];
    [Rh5, Rch5, wh, info] = ati_ident(wd, m, ell, opt); R5 = [Rch5 Rh5]; R5 = R5 / R5(1); 
    Bh5 = R2ss(Rh5, q, 1:q, c);
    wch5 = min_norm_wc(Rh5, Rch5, q, T); 
    wh5  = ati_mbint(Bh5, wch5, w);

    EB(i, j, :) = [NaN,      eBh(R3), eBh(R3_), eBh(R5), eBh(R4)];
    EW(i, j, :) = [ewh(wh1), ewh(wh3), ewh(wh3_), ewh(wh5), ewh(wh4)];  
  end
end

mns = {'std' 'DDR', 'LRA', 'GLRA', 'SLRA', '2-step'};
mEB = squeeze(mean(EB)); 
mEW = squeeze(mean(EW)); 

[mns; num2cell([S' mEB])]
[mns; num2cell([S' mEW])]

% return

%% results
ls = {'b--', 'r-.', 'c-.', 'g-', 'k:'};

figure(1), hold on
for i = 2:5, plot(S, mEB(:, i), ls{i}), end
xlabel('noise level'), ylabel('$e_R$, \%')
legend(mns{3:end}, 'Location', 'northeast')
legend('boxoff')   
ax = axis; axis([S(1) S(end) 0 ax(4)]), 
print_fig('eb')

figure(2), hold on
for i = 1:5, plot(S, mEW(:, i), ls{i}), end
xlabel('noise level'), ylabel('$e_y$, \%')
legend(mns{2:end}, 'Location', 'northeast')
ax = axis; axis([S(1) S(end) 0 ax(4)]), 
legend('boxoff')   
print_fig('ew')
