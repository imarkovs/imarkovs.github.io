function ans = ati_w_in_B(w, Rlin, Rc, tol); 
if ~exist('tol'), tol = 1e-10; end 
[T, q] = size(w); ell = size(Rlin, 2) / q - 1; 
ans = norm(multmat(Rlin, q, T) * vec(w') - kron(ones(T - ell, 1), -Rc)) < tol;
