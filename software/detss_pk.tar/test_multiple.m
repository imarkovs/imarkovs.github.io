
clear all, warning off
T = 50; delta = 10; N = 100; s = 0.01; eiv = 1;
nu = 1; ny = 1; n = 2;

m = 1; k = 10; d = 1;
A = [0 1; -k/m -d/m]; B = [0; 1/m]; C = [1 0]; D = 0;
sys = c2d(ss(A, B, C, D), 0.2); sys.ts = -1;
H = impulse(sys, delta - 1);

u0 = rand(T, nu); y0 = lsim(sys, u0); w0 = [u0 y0]; 
E = rand(10, delta); F = E * H; ep = []; fp = [];
for i = 1:10
  fprintf('i = %d\n', i)
  e = E(1:i, :); f = F(1:i, :);
  for j = 1:N
    fprintf('%d, ', j)
    if eiv
      wt = randn(T, nu + ny); w = w0 + s * norm(w0) * wt / norm(wt); 
    else
      wt = [zeros(T, nu) randn(T, ny)]; w = w0 + s * norm(w0(:, nu + 1:end)) * wt / norm(wt); 
    end
    u = w(:, 1:nu); y = w(:, nu+1:end);
    [sysh1, Hh1, Hh1_] = uy2ss_pk(u, y, n, delta, e, f, ep, fp);
    [sysh2, Hh2, Hh2_] = uy2ss_pk(u, y, n, delta);
    sysh3 = n4sid(iddata(y, u), n); Hh3 = impulse(sysh3, delta - 1);
    e_sys(j, :) = [norm(sys - sysh1) norm(sys - sysh2) norm(sys - sysh3)] / norm(sys);
    e_h(j, :)   = [norm(vec(H - Hh1)) norm(vec(H - Hh2)) norm(vec(H - Hh3))] / norm(vec(H));
    e_hh(j, :)  = [norm(vec(H - Hh1_)) norm(vec(H - Hh2_)) NaN] / norm(vec(H));
  end
  fprintf('\n')
  E_sys(i, :) = mean(e_sys); E_h(i, :) = mean(e_h); E_hh(i, :) = mean(e_hh);
end

figure(1), 
plot(E_sys(:, 1), 'b--'), hold on, 
plot(E_sys(:, 2), 'r-'), 
plot(E_sys(:, 3), 'r-.'), 
legend('uy2ss\_pk', 'uy2ss', 'n4sid', 'location', 'SouthWest'), 
ax = axis; axis([1 i ax(3:4)])
print_fig('ijc_f1')

figure(2), 
plot(E_h(:, 1), 'b--'), hold on, 
plot(E_h(:, 2), 'r-'),  
plot(E_h(:, 3), 'r-.'),    
legend('uy2ss\_pk', 'uy2ss', 'n4sid', 'location', 'SouthWest'), 
ax = axis; axis([1 i ax(3:4)])
print_fig('ijc_f2')

figure(3), 
plot(E_hh(:, 1), 'b--'), hold on, 
plot(E_hh(:, 2), 'r-'),  
legend('uy2ss\_pk', 'uy2ss', 'location', 'SouthWest'), 
ax = axis; axis([1 i ax(3:4)])
print_fig('ijc_f3')
