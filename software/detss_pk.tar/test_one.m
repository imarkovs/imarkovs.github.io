
clear all, warning off
T = 50; delta = 10; N = 100; s = 0.01; eiv = 1;
nu = 1; ny = 1; n = 2;

m = 1; k = 10; d = 1;
A = [0 1; -k/m -d/m]; B = [0; 1/m]; C = [1 0]; D = 0;
sys = c2d(ss(A, B, C, D), 0.2); sys.ts = -1;
H = impulse(sys, delta - 1);

u0 = rand(T, nu); y0 = lsim(sys, u0); w0 = [u0 y0]; 
e = ones(1, delta); f = e * H; ep = []; fp = [];
for j = 1:N
  fprintf('%d, ', j)
  if eiv
    wt = randn(T, nu + ny); w = w0 + s * norm(w0) * wt / norm(wt); 
  else
    wt = [zeros(T, nu) randn(T, ny)]; w = w0 + s * norm(w0(:, nu + 1:end)) * wt / norm(wt); 
  end
  u = w(:, 1:nu); y = w(:, nu+1:end);
  [sysh1, Hh1, Hh1_] = uy2ss_pk(u, y, n, delta, e, f, ep, fp);
  [sysh2, Hh2, Hh2_] = uy2ss_pk(u, y, n, delta);
  sysh3 = n4sid(iddata(y, u), n); Hh3 = impulse(sysh3, delta - 1);
  e_sys(j, :) = [norm(sys - sysh1) norm(sys - sysh2) norm(sys - sysh3)] / norm(sys);
  e_h(j, :)   = [norm(vec(H - Hh1)) norm(vec(H - Hh2)) norm(vec(H - Hh3))] / norm(vec(H));
  e_hh(j, :)  = [norm(vec(H - Hh1_)) norm(vec(H - Hh2_)) NaN] / norm(vec(H));
end
fprintf('\n')
[{'' 'uh2ss_pk' 'uh2ss' 'n4sid'}
['e_sys' num2cell(mean(e_sys))]
['e_h'   num2cell(mean(e_h))]
['e_hh'  num2cell(mean(e_hh))]]
