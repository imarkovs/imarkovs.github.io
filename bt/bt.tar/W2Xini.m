function [Xini, e] = W2Xini(W, B)
[p, m] = size(B); q = m + p; T = size(W, 1) / q;
[U, Y] = BT2UYT(W, m, p);
if m > 0, 
  Y0 = Y - convm(B, T) * U; 
else, Y0 = Y; end
O = obsvm(B, T); Xini = O \ Y0; 
if nargout > 1
  E = Y0 - O * Xini; e = sqrt(sum(E .^ 2)); 
end
