function U0 = ss2U0(B, T); 
% TODO
