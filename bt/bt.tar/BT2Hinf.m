function [Hinf, HT, uinf] = BT2Hinf(BT, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
HT = BT2HT(BT, q, ctol); 
[u, s, v] = svd(HT); Hinf = s(1); uinf = v(:, 1);
