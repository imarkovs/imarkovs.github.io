function L = all_lags(p, n)
if p == 1 L = n; return, end
L = [];
for k = n:-1:0
    T = all_lags(p - 1, n - k);
    T = T(T(:, 1) <= k, :);
    L = [L; [k * ones(size(T, 1), 1), T]];
end
