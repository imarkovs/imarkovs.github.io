function ans = is_subspace(A, B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
ans = norm(A - B * pinv(B) * A) < tol;
