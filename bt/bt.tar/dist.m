function [d, wh] = dist(w, B)
if isa(w, 'ss') % distance between systems
  d = Bdist(w, B); 
else            % distance from signal to system          
  if iscell(w)
    for i = 1:length(w), 
      [d(i) wh{i}] = dist(w{i}, B);
    end
  else
    [T, q] = size(w); 
    if isa(B, 'ss'), BT = B2BT(B, T); else, BT = BT2BT(B, q, T); end
    wh_vec = ProjBT(vec(w'), BT); wh = reshape(wh_vec, q, T)';
    d = norm(w - wh, 'fro');
  end
end
