function [d, wh] = dist(w, B, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
if isa(w, 'ss') % distance between systems
  d = Bdist(w, B, ctol); 
else            % distance from signal to system          
  if iscell(w)
    for i = 1:length(w), 
      [d(i) wh{i}] = dist(w{i}, B, ctol);
    end
  else
    [T, q] = size(w); 
    if isa(B, 'ss'), BT = B2BT(B, T); else, BT = BT2BT(B, q, T, ctol); end
    wh_vec = ProjBT(vec(w'), orth(BT)); wh = reshape(wh_vec, q, T)';
    d = norm(w - wh, 'fro');
  end
end
