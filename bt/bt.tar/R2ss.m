function [B, io] = R2ss(R, q, io, ctol) 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
ell1 = size(R, 2) / q; Tmin = 2 * ell1;
BT = R2BT(R, q, Tmin, ctol);
if ~exist('io', 'var') || isempty(io)
  IO = BT2IO(BT, q); io = IO(1, :);
end
[B, io] = BT2ss(BT, q, io, ctol);
