function H = hank(w, L)
if ~iscell(w), H = blkhank(w, L); return, end 
N = length(w); H = []; 
for k = 1:N, H = [H blkhank(w{k}, L)]; end
