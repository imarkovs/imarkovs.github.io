function ans = is_lti(BT, q, c, tol) 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
ans = all(dist_lti(BT, q, c) <= tol);
