function [d, B1T, B2T] = Bdist(B1, B2, q, T, ctol)
if ~exist('T', 'var') || isempty(T), T = 100; end % <default-horizon>
if isa(B1, 'ss'), B1T = B2BT(B1, T); q = sum(size(B1)); else, B1T = B1; end
if isa(B2, 'ss'), B2T = B2BT(B2, T); q = sum(size(B2)); else, B2T = B2; end
if exist('q') && ~isempty(q)
  T = min(size(B1T, 1), size(B2T, 1)) / q;
  if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
  if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
  B1T = BT2BT(B1T, q, T, ctol); B2T = BT2BT(B2T, q, T, ctol); 
end
d = subspace(B1T, B2T);
