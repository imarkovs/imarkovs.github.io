function d = Bdist(B1, B2, T)
if ~exist('T', 'var') || isempty(T), T = 100; end % <default-horizon>
if isa(B1, 'ss'), B1 = B2BT(B1, T); end
if isa(B2, 'ss'), B2 = B2BT(B2, T); end
qT = min(size(B1, 1), size(B2, 1));
d = subspace(B1(1:qT, :), B2(1:qT, :));
