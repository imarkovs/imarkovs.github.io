%% Tutorial to the Behavioral Toolbox
clear all
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>

%% Restricted behavior

%% Simulation parameters

m = 2; p = 1; q = m + p; n = 3; B = drss(n, p, m);

%% The restricted behavior

T = 10; BT = B2BT(B, T);

check(size(BT, 2) == m * T + n)

w = B2w(B, T); check(w_in_B(w, B))

W = BT2W(BT, q); check(all(w_in_B(W, B)))

%% Input/output partitionings

io = flip(1:q); BTp = BT2BT(BT, q, io);

check(w_in_B(w(:, io), BTp))

[UT, YT] = BT2UYT(BT, m, p);

check(norm(BT - UYT2BT(UT, YT, m, p)) == 0)

Bp = ss(tf([0 1], [1 1], 1));

BpT = B2BT(Bp, T);
check(is_io(BpT, 2, [1 2]) == true)
check(is_io(BpT, 2, [2 1]) == false)
check(all(BT2IO(BpT, 2) == [1 2]))

%% Subbehaviors

Y0 = BT2Y0(BT, q);
U0 = BT2U0(BT, q);
B0 = BT2B0(BT, q);
BC = BT2BC(BT, q);
%BP = BT2BP(BT, q); TODO

y0 = initial(B, rand(n, 1), T-1); check(w_in_B(y0, Y0))

u0 = reshape(U0 * rand(size(U0, 2), 1), m, T)';
w0 = [u0 zeros(T, p)]; check(w_in_B(w0, BT))

T0 = size(B0, 1) / q;
w0 = reshape(B0 * rand(size(B0, 2), 1), q, T0)'; 
xini = w2xini(w0, B); check(norm(xini) < tol)

[HT, T] = BT2HT(BT, q);

check(norm(HT - convm(B, T)) < tol)

%% Analysis

[ch, mh, ellh, nh] = BT2c(BT, q); check(all([mh nh] == [m n]))

ell = lag(B); check(ellh == ell)

Bp = B; Bp.a = Bp.a + 0.01 * randn(n); d = Bdist(B, Bp);

Bp = ss2ss(B, rand(n)); check(equal(B, Bp))

Bp = ss([0.5 1; 0 0.25], [1; 0], [1 1], 1, -1); 
n_unctr = isunctr(Bp); check(n_unctr == 1)

Bp = ss([0.5 1; 0 0.25], [1; 1e-5], [1 1], 1, -1); 
d = distunctr(Bp); % -> 1e-7

[Hinf, ~, uinf] = BT2Hinf(BT, q); C = convm(B, T);
check(abs(Hinf - norm(C)) / norm(C) < tol)

%% Parametric representations

R = B2R(B); R = BT2R(BT, q);

BT_ = R2BT(B2R(B), q, T); check(Bdist(B, BT_) < tol)
BT_ = ss2BT(B, T);        check(Bdist(B, BT_) < tol)

check(Bdist(B, BT2ss(BT, q)) < tol)

check(Bdist(B, R2ss(R, q)) < tol)

Rmin = BT2Rmin(BT, q); check(Bdist(BT, R2BT(Rmin, q, T)) < tol)
Rmin = R2Rmin(R, q);   check(Bdist(BT, R2BT(Rmin, q, T)) < tol)

%% Signal processing and open-loop control

[d, wh] = dist(w, B);

[xini, e] = w2xini(w, B); check(norm(w - B2w(B, T, xini, w(:, 1:m))) < tol)

BT = B2BT(B, ell + size(w,1));
[wini, e] = w2wini(w, BT, ell); check(w_in_B([wini; w], B))

yf = u2y(BT, q, w(:, 1:m), wini); check(w(:, m+1:end) - yf)

Tf = 3; u1 = [[1; zeros(q * Tf - 1, 1)] zeros(q * Tf, m - 1)];
h1 = u2y(BT, q, u1); h = lsim(B, u1); check(h1 - h < tol)

qg = 2; qm = 2; q = qm + qg; m = 1; p = q - m; n = 5; B = drss(n, p, m);
T = 20; w = B2w(B, T); wg = w(:, 1:qg); wm = w(:, qg+1:q);
wmh = wgiven2wmissing(wg, B); check(norm(wm - wmh) / norm(wm) < tol)

m = 1; p = 1; n = 3; q = m + p; B = drss(n, p, m); 
Tr = 10; wr = [zeros(Tr, m) ones(Tr, p)]; ell = lag(B);
v = [1e-2 * ones(Tr, m), ones(Tr, p)]; wh = lqctr(B, wr, v);

if ~isunctr(B)
  Tr = ell; wr = zeros(Tr, q);
  wp = B2w(B, ell); wf = zeros(ell, q); 
  wh = lqctr(B, wr, [], wp, wf);
  check(w_in_B([wp; wh; wf], B))
end

%% Identification

Td = 100; wd = B2w(B, Td);

ch = c_mpum(wd); check(all(ch == [m, lag(B), n]))

BhT = w2BT(wd, T);

R = w2R(wd); check(w_in_B(wd, R2BT(R, q, Td)))

Bh = w2ss(wd); check(w_in_B(wd, Bh))

R_ = mpum(wd); check(w_in_B(wd, R2BT(R_, q, Td)))

%% Auxiliary functions

w = reshape(1:q*T, q, T)'; vec_w = vec(w');
[vec_u, vec_y] = w2uy(vec_w, m, p); 
check(norm(vec_w - uy2w([vec_u; vec_y], m, p)) == 0)

check(norm(obsvm(B, n) - obsv(B)) < tol)

C = convmtx(impulse(B(1, 1), n-1), n);
check(norm(convm(B(1, 1), n) - C(1:n, 1:n)) < tol)

H = blkhank([1 2 3 4 5], 3);

w = Pblkhank([1 2 3; 2 3 4; 3 4 5], 3);

H = hank({[1 2 3 4], [5 6 7]}, 3);

w = Phank([1 2 5; 2 3 6; 3 4 7], 3);

M = multmat([1 2 3], 1, 5);

R = Pmultmat([1 2 3 0 0; 0 1 2 3 0; 0 0 1 2 3], 1, 1);

A = rand(2, 5); B = [rand(1, 5); rand(2) * A];
C = rspan_intersect(A, B); check(rank([A; C]) == 2)

A = rand(2, 5); Ap = perp(A); 
check(size(rspan_intersect(A, B), 1) == 0)

A = rand(2, 5); B = [rand(1, 5); rand(2) * A];
C = rspan_diff(B, A); check(rank([B(1, :); C]) == 1)

D = rand(5, 5); [R, P, dh] = lra(D, 2);

dh_ = glra(D, 4, 1);

%% Interconnection of systems

n1 = 2; m1 = 2; p1 = 1; q1 = m1 + p1; B1 = drss(n1, p1, m1); % 1st system
n2 = 2; m2 = 1; p2 = 1; q2 = m2 + p2; B2 = drss(n2, p2, m2); % 2nd system

BT1 = B2BT(B1, T); BT2 = B2BT(B2, T); BT = BTappend(BT1, q1, BT2, q2);

R = Rappend(B2R(B1), q1, B2R(B2), q2);

check(norm(R * BT(1:size(R, 2), :)) < tol) % selection from BT!

[m_app, ell_app, n_app] = BT2c(BT, q); % -> 3 2 4

qint = q1 + q2; 
Rint = [R; [[1 zeros(1, q1-1), -1 zeros(1, q2-1)] zeros(1, size(R, 2) - qint)]];

BTint = R2BT(Rint, qint, T); check(norm(Rint * BTint(1:size(Rint, 2), :)) < tol)

[m_int, ell_int, n_int] = BT2c(BTint, qint); % -> 2 2 4

check(~is_io(BTint, qint, [1 4 2 3 5]))

[IOp, IOi] = BT2IO(BTint, qint); nIOi = size(IOi, 1); % -> 84
