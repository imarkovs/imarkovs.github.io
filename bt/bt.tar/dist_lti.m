function [d, BTh] = dist_lti(BT, q, c) 
Rh = BT2R(BT, q, c); 
BTh = R2BT(Rh, q, size(BT, 1) / q); 
d = Bdist(BT, BTh, q);
