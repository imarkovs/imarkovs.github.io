function [HT, T] = BT2HT(BT, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
[c, m] = BT2c(BT, q, ctol); p = q - m;
[U0, Y0] = BT2UYT(BT2B0(BT, q, ctol), m, p);
HT = Y0 * pinv(U0, tol); T = size(U0, 1) / m;
