function BvarT = BTproject(BT, q, var)
BT = BT2BT(BT, q, [var, setdiff(1:q, var)]);
BvarT = BT2UYT(BT, length(var), q - length(var));
