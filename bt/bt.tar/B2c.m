function [c, m, ell, n] = B2c(B, tol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[p, m] = size(B); C = ctrb(B); n = rank(C, tol); ell = lag(B, tol); c = [m, ell, n];
