function BT = R2BT(R, q, T, tol); 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
BT = null(multmat(R, q, T), tol);
