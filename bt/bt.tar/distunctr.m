function d = distunctr(B, nc)
if ~exist('nc', 'var') || isempty(nc), nc = 1; end
[p, m] = size(B); q = p + m; n = order(B); ell = lag(B);
BT = B2BT(B, 3 * ell); Bini = BT(1:q * ell, :); % selection from BT!
[~, NullBini] = lra(Bini', m * ell + n);
BC = BT((q * 2 * ell + 1):end, :) * NullBini';
[P, R, hatBC] = lra(BC, m * ell + n - nc); 
d = norm(BC - hatBC, 'fro') / norm(BC, 'fro');
