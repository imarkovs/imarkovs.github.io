function O = obsvm(B, T)
[p, m] = size(B); 
O = B.c; for i = 2:T, O = [O; O(end-p+1:end, :) * B.a]; end
