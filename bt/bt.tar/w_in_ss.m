function ans = w_in_ss(w, B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[xini, e] = w2xini(w, B);  ans = e < tol;
