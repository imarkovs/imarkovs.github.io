function BT = BTappend(BT1, q1, BT2, q2, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>

[q1T1, nc1] = size(BT1); T1 = q1T1 / q1;
[q2T2, nc2] = size(BT2); T2 = q2T2 / q2;

T = min(T1, T2); q = q1 + q2;
BT1 = BT2BT(BT1, q1, T, ctol);
BT2 = BT2BT(BT2, q2, T, ctol);

BT = zeros(q * T, nc1 + nc2);
I = kron(ones(1, T), 1:q1)   + kron(0:T-1, q * ones(1, q1)); 
BT(I, 1:nc1)     = BT1;
I = kron(ones(1, T), q1+1:q) + kron(0:T-1, q * ones(1, q2)); 
BT(I, nc1+1:end) = BT2;
%% <ctol2c>
if isscalar(ctol) % estimate c from BT or wd
  % if exist('R', 'var') && ~exist('BT', 'var'), BT = null(R); end
  if exist('BT', 'var'), [c, m, ell, n] = BT2c(BT, q, ctol); 
  elseif exist('wd', 'var'), [c, m, ell, n] = c_mpum(wd, ctol); end
else % ctol should specify complexity 
  c = ctol; [m, ell, n] = unpack_c(c);
end
BT = lra(BT, c2r(c, T));
