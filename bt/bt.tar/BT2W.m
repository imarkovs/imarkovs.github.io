function W = BT2W(BT, q); 
[qT, N] = size(BT); T = qT / q;
for i = 1:N, W{i} = reshape(BT(:, i), q, T)'; end
