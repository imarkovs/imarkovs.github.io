function BT = ss2BT(B, T); 
[p, m] = size(B); n = order(B);
BT = uy2w([zeros(m * T, n) eye(m * T); obsvm(B, T) convm(B, T)], m, p);
