clear all, addpath ~/slra/ident/data
Dname = {'destill', 'pHdata', 'dryer', 'thermic-wall', 'heating-system', ...
         'erie', 'CD_player_arm', 'robot_arm', 'exchanger', 'cstr', 'steamgen'};
%% <define-methods>
M.name{1} = 'pinv';  M.comp{1} = 'wh = ddint(wi, w);';
M.name{2} = 'lra';   M.comp{2} = 'wh = ddint(wi, w, [], [m, n, n]);';
M.name{3} = 'l1';    M.comp{3} = 'wh = ddint(wi, w, [], [], l);';
M.name{4} = '2s-ml'; M.comp{4} = '[~, ~, wih] = ident(wi, m, ell); wh = ddint(wih, w);';
K = [1 3 4]; I = [3 5 7 8 9]; 
for i = 1:length(I), Dname{I(i)}
  %% <load-data>
  switch I(i)
    case 1,  destill_         , m = 5; ell = 1; l = 1; 
    case 2,  pHdata_          , m = 2; ell = 6; l = 1;  
    case 3,  dryer_           , m = 1; ell = 5; l = 1;  
    case 4,  thermic_res_wall_, m = 2; ell = 2; l = 1;    
    case 5,  heating_system_  , m = 1; ell = 2; l = 1;  
    case 6,  erie_            , m = 5; ell = 1; l = 1;   
    case 7,  CD_player_arm_   , m = 2; ell = 1; l = 0.05;   
    case 8,  robot_arm_       , m = 1; ell = 4; l = 1;   
    case 9,  exchanger_       , m = 1; ell = 2; l = 1;   
    case 10, cstr_            , m = 1; ell = 1; l = 1;   
    case 11, steamgen_        , m = 4; ell = 1; l = 1;   
  end
  wd = [u y]; [T, q] = size(wd); p = q - m; n = p * ell;
  Ts = round(3 / 4 * T); Ti = 1:Ts; Tv = Ts+1:T;
  wi = wd(Ti, :); yv = wd(Tv, m+1:end); 
  w = [wd(Tv, 1:m) NaN(length(Tv), p)];
  e = @(yh) 100 * norm(yv - yh) / norm(yv); %% <define-error>
  for k = 1:length(K)
    tic, eval(M.comp{K(k)}); CT(i, k) = toc; RE(i, k) = e(wh(:, m+1:end)); 
  end
end

%% results
disp('relative errors:       '), disp([[' '; Dname(I)'] [M.name(K); num2cell(RE)]])
disp('computation time (sec):'), disp([[' '; Dname(I)'] [M.name(K); num2cell(CT)]])
