function M = multmat(R, q, T, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
g = size(R, 1); M = [];
for i = 1:g, M = [M; scalar_multmat(R(i, :), q, T, tol)]; end

function M = scalar_multmat(R, q, T, tol)
R = remove_trailing_zeros(R, q, tol);
nc = length(R); n = T - nc / q + 1;
M = zeros(n, nc + (n - 1) * q);
for i = 1:n, M(i, (1:nc) + (i - 1) * q) = R; end

function R = remove_trailing_zeros(R, q, tol)
RR = reshape(R, q, length(R) / q);
n = find(sum(abs(RR), 1) > tol, 1, 'last');
R = vec(RR(:, 1:n))';
