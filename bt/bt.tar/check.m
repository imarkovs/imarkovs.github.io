function check(a), if a, disp('PASS'), else, disp('FAIL'), end
