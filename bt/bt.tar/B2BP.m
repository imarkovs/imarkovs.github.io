function BP = B2BP(B, T)
% TODO
