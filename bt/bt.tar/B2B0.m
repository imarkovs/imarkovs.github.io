function B0 = B2B0(B, T, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[p, m] = size(B); n = order(B);
Tmin = @(T) (m + 1) * T + n - 1; %% <define-Tmin>
wd0 = B2w(B, Tmin(T), 0); B0 = orth(hank(wd0, T), tol);
