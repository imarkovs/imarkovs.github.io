function B0 = B2B0(B, T, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[p, m] = size(B); q = m + p; ell = lag(B);
B0 = BT2B0(B2BT(B, T+ell), q, ctol);
