function BT = B2BT(B, T); 
[p, m] = size(B); n = order(B);
Tmin = @(T) (m + 1) * T + n - 1; %% <define-Tmin>
BT = lra(hank(B2w(B, Tmin(T)), T), m * T + n);
