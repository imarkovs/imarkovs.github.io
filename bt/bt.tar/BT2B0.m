function [B0, T] = BT2B0(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
%% <ctol2c>
if isscalar(ctol) % estimate c from BT or wd
  if exist('R', 'var') && ~exist('BT', 'var'), BT = null(R); end
  if exist('BT', 'var'), [c, m, ell, n] = BT2c(BT, q, ctol); 
  elseif exist('wd', 'var'), [c, m, ell, n] = c_mpum(wd, ctol); end
else % ctol should specify complexity 
  c = ctol; m = c(1); ell = c(2); n = c(3);
end 
Bini = BT(1:q * ell, :); T = size(BT, 1) / q - ell; % selection from BT!
B0 = lra(BT(q * ell + 1:end, :) * null(Bini, tol), c2r(c, T, 0));
