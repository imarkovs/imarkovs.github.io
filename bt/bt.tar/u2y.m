function yf = u2y(BT, q, uf, wini)
T = size(BT, 1) / q; [Tf, m] = size(uf); p = q - m;
if ~exist('wini'), Tini = T - Tf; wini = zeros(Tini, q); 
else, Tini = size(wini, 1); end
Bini = BT(1:q * Tini, :); % selection from BT!
[Uf, Yf] = BT2UYT(BT(q * Tini + 1:q * (Tini + Tf), :), m, p);
yf = Yf * (pinv([Bini; Uf]) * [vec(wini'); vec(uf')]);
yf = reshape(yf, p, Tf)';
