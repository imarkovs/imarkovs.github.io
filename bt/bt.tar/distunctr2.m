function d = distunctr2(B, T, tol) 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[p, m] = size(B); q = p + m; n = order(B); ell = lag(B); 
if ~exist('T', 'var') || isempty(T), T = 2 * ell; end 
BC = B2B0(B, T, tol); % TODO: B2B0 vs B2BC ?
d  = Bdist(B, BC);    % dependence on T?
