function ell = lag(B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[p, m] = size(B); n = order(B); O = obsvm(B, n); r = rank(O, tol);
if order(B) > 0
  for ell = 1:n, if rank(O(1:p * ell, :), tol) == r, break, end, end
else, ell = 0; end
