function ell = lag(B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[p, m] = size(B); O = obsv(B); r = rank(O, tol); 
for ell = 0:r, if rank(O(1:p * ell, :), tol) == r, break, end, end
