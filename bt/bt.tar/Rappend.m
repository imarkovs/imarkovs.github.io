function R = Rappend(R1, q1, R2, q2)
[p1, ncol] = size(R1); ell1 = ncol / q1 - 1;
[p2, ncol] = size(R2); ell2 = ncol / q2 - 1;

ell = max(ell1, ell2); q = q1 + q2;
R = zeros(p1 + p2, q * (ell + 1));
I = kron(ones(1, ell+1), 1:q1)   + kron(0:ell, q * ones(1, q1)); 
R(1:p1, I)     = R1;
I = kron(ones(1, ell+1), q1+1:q) + kron(0:ell, q * ones(1, q2)); 
R(p1+1:end, I) = R2;
