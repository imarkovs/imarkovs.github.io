function wh = Phank(D, L, n)
if ~exist('n'), wh = Pblkhank(D, L); return, end
for k = 1:length(n), wh{k} = Pblkhank(D(:, 1:n(k)), L); D(:, 1:n(k)) = []; end
