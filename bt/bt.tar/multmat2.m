function M = multmat2(R, q, T)
[g, nc] = size(R); ell = nc / q - 1;
M = zeros((T - ell) * g, T * q);
for i = 1:(T - ell), M((i - 1) * g + 1: i * g, (1:(ell + 1) * q) + (i - 1) * q) = R; end
