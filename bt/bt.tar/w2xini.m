function [xini, e, x] = w2xini(w, B)
[p, m] = size(B); n = order(B); [T, q] = size(w);
if m > 0, 
  u = w(:, 1:m); y = w(:, m+1:end); y0 = y - lsim(B, u); 
else, y0 = w; end
O = obsvm(B, T); xini = O \ vec(y0'); 
if nargout > 1, e = norm(vec(y0') - O * xini); end
if nargout > 2, 
  B_ = ss(B.a, B.b, eye(n), zeros(n, m), -1);
  x = reshape(convm(B_, T) * vec(u') + obsvm(B_, T) * xini, n, T)'; 
end
