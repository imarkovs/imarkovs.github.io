function [xini, e] = w2xini(w, B)
[p, m] = size(B); [T, q] = size(w);
if m > 0, 
  u = w(:, 1:m); y = w(:, m+1:end); y0 = y - lsim(B, u); 
else, y0 = w; end
O = obsvm(B, T); xini = O \ vec(y0'); 
if nargout > 1, e = norm(vec(y0') - O * xini); end
