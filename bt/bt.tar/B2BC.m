function BC = B2BC(B, T, ctol), 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
BC = B2B0(B, T, ctol); % is this correct?
