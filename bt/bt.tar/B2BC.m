function BC = B2BC(B, T, tol), 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
BC = B2B0(B, T, tol); % is this correct?
