function Ap = perp(A, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[u, s, v] = svd(A); r = sum(diag(s) > tol); Ap = v(:, (r + 1):end)';
