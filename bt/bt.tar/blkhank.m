function H = blkhank(w, L)
[q, T] = size(w); if T < q, w = w'; [q, T] = size(w); end, j = T - L + 1; 
if j <= 0, H = []; else, 
  H = zeros(L * q, j);
  for i = 1:L, H(((i - 1) * q + 1):(i * q), :) = w(:, i:(i + j - 1)); end
end
