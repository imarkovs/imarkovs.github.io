function w = uy2w(uy, m, p)
q = m + p; T = size(uy, 1) / q; w = zeros(size(uy));
for i = 1:m, w(i:q:end, :) = uy(i:m:m*T, :); end
for i = 1:p, w(m+i:q:end, :) = uy(m*T+i:p:end, :); end
