function [Bh, io] = BT2ss(BT, q, io, ctol); 
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
%% <ctol2c>
if isscalar(ctol) % estimate c from BT or wd
  if exist('R', 'var') && ~exist('BT', 'var'), BT = null(R); end
  if exist('BT', 'var'), [c, m, ell, n] = BT2c(BT, q, ctol); 
  elseif exist('wd', 'var'), [c, m, ell, n] = c_mpum(wd, ctol); end
else % ctol should specify complexity 
  c = ctol; m = c(1); ell = c(2); n = c(3);
end
p = q - m;

%% compute state by past/future intersection
Wpf = BT(1:q * (2 * ell + 1), :); R = null(Wpf', tol)'; % selection from BT!
Wp = BT(1:q * ell, :); X = R(:, 1:q * ell) * Wp;        % selection from BT!

%% compute the shifted state
sigmaWp = BT(q + 1:q * (ell + 1), :); 
sigmaX = R(:, 1:q * ell) * sigmaWp;

%% make X and sigmaX minimal by LRA
[u, s, ~] = svd(X); P = u(1:n, :);
Xmin = P * X; sigmaXmin = P * sigmaX; 

%% find an input/output partition
if ~exist('io', 'var') || isempty(io)
  IO = BT2IO(BT, q); io = IO(1, :);
end
if q > 1, BT = BT2BT(BT, q, io); end 
[UT, YT] = BT2UYT(BT, m, p);
U = UT(m * ell + 1:m * (ell + 1), :);
Y = YT(p * ell + 1:p * (ell + 1), :);

%% compute the state-space parameters
abcd = [sigmaXmin; Y] * pinv([Xmin; U], tol); 
Bh = ss(abcd(1:n,     1:n), abcd(1:n,     n+1:end), ...
        abcd(n+1:end, 1:n), abcd(n+1:end, n+1:end), 1);
