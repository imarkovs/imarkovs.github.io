function Rh = Pmultmat(D, p, q)
[m, n] = size(D); L = m / p; T = n / q; ell = T - L;
I = multmat(reshape(1:(p*(ell + 1)), p, ell + 1), q, T); 
for k = 1:p*(ell + 1), ph(k) = mean(D(I == k)); end
Rh = reshape(ph, p, ell + 1);
