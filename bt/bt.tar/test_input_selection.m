clear all

%% simulation parameters
m = 10; p = 1; n = 2; 
Tr = 10;   % control horizon
Td = 1000; % number of data samples 

B = drss(n, p, 1); B = ss(B.a, [B.b zeros(n, m-1)], B.c, [B.d zeros(p, m-1)], -1);

%% reference trajectory
ur = zeros(Tr, m); yr = ones(Tr, p); 

%% simulate date 
wd = B2w(B, Td); % random trajectory, uses the behavioral toolbox

%% solve the problem and check the result
wh = input_selection(wd, [ur yr], m, 1)
figure, plot(yh)                  % tracking 
figure, stem(sum_square(ur - uh)) % and sparsity of ur - uh
