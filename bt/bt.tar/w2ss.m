function Bh = w2ss(wd, io, ctol) 
q = size(wd, 2);
%% <ctol2c>
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
if isscalar(ctol) % estimate c from BT or wd
  if exist('BT', 'var'), c = BT2c(BT, q, ctol); 
  else, c = c_mpum(wd, ctol); end
else, c = ctol; end
m = c(1); ell = c(2); n = c(3);
if ~exist('io', 'var') || isempty(io), io = 1:q; end % <default-io>
BT = w2BT(wd, 2  * ell + 1, c);
Bh = BT2ss(BT, q, io, c);
