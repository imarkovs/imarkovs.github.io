function [P, R, dh] = lra(d, rtol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('rtol', 'var') || isempty(rtol), rtol = tol; end % <default-rtol>
[u, s, v] = svd(d); 
if rtol < 1, r = sum(diag(s) > rtol); else r = rtol; end
P = u(:, 1:r); R = u(:, (r + 1):end)'; 
if nargout > 2, dh = u(:, 1:r) * s(1:r, 1:r) * v(:, 1:r)'; end
