function R = BT2R(BT, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
c = BT2c(BT, q, ctol); m = c(1); ell = c(2);
R = null(BT(1:(q * (ell + 1)), :)', tol)'; % selection from BT!
