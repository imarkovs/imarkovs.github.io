function wm = wgiven2wmissing(wg, B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[p, m] = size(B); q = m + p; 
[T, qg] = size(wg); qm = q - qg;

BT = B2BT(B, T); [Bg, Bm] = BT2UYT(BT, qg, qm);
wm = Bm * pinv(Bg, tol) * vec(wg');
wm = reshape(wm, qm, T)';
