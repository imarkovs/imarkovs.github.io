function [Rcell, ells, Rrlc] = Rmat2Rcell(Rmat, q, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[g, qL] = size(Rmat); ell = qL / q - 1; Rcell1 = {}; 
for i = 1:g, 
  Rcell1{i, 1} = remove_trailing_zeros(Rmat(i, :), q, tol); 
  ells(i)  = size(Rcell1{i}, 2) / q - 1;
end

%% Row leading coefficient
if nargout > 2, for i = 1:g, Rrlc(i, :) = Rcell1{i}(:, end - q + 1:end); end, end

%% merge rows of equal degree
dd  = diff(ells);                % change points
Idd = [0 find(dd) length(ells)]; % indeces of the change points
k   = diff(Idd);                 % # of rows with equal degree
for i = 1:length(k)
  Rcell_i = []; for j = 1:k(i), Rcell_i = [Rcell_i; Rcell1{Idd(i) + j}]; end
  Rcell{i, 1} = Rcell_i; 
end
