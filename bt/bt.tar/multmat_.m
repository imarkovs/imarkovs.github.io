function M = multmat_(R, q, T)
M = []; 
if ~isempty(R)
  for i = 1:length(R), M = [M; multmat(R{i}, q, T)]; end
end
