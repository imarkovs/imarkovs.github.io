function dh = glra(T, n, r)
c = T(:, 1:n); d = T(:, n+1:end);
[u, c1] = qr(c); % assuming C is f.c.r 
c1 = c1(1:n, :); dp = u' * d; 
[ud, sd, vd] = svd(dp(n+1:end, :));
d2h = ud(:, 1:r) * sd(1:r, 1:r) * vd(:, 1:r)';
dh = u * [dp(1:n, :); d2h];
