function BC = BT2BC(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
[c, m, ell, n] = BT2c(BT, q, ctol); p = q - m; 
Bini = BT(1:q * ell, :); % selection from BT!
BC = orth(BT((q * 2 * ell + 1):end, :) * null(Bini, tol), tol);
