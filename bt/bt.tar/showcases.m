%% When are two systems equal?

m = 2; p = 2; n = 3; sys1 = drss(n, p, m);

sys2 = ss2ss(sys1, rand(n));

try, sys1 == sys2, end % -> Operator '==' is not supported for operands of type 'ss'.

equal(sys1, sys2) % -> true

%% Interconnection of systems

n1 = 2; B1 = drss(n1); 
n2 = 2; B2 = drss(n2);

R3 = [0 1 -1 0];

T = n1 + n2;

BT1 = B2BT(B1, T); BT2 = B2BT(B2, T); BT3 = R2BT(R3, 4, T);

BT12    = BTappend(BT1, 2, BT2, 2);
BT12int = BTintersect(BT12, BT3);

B12 = B2 * B1;

BT12_ = BTproject(BT12int, 4, [1 4]);

equal(B12, BT12_, q) % -> 1

%% Signal from noise separation

m = 1; p = 1; n = 3; q = m + p; B = drss(n, p, m); 
T = 10; w0 = B2w(B, T); wn = randn(size(w0)); 
w = w0 + 0.1 * norm(w0) * wn / norm(wn);

BT = B2BT(B, T); wh = BT * BT' * vec(w'); wh = reshape(wh, q, T)';

%% Missing input estimation

m_missing = 1; m_given = 1; m = m_missing + m_given; p = 2; n = 3; q = m + p; 
B = drss(n, p, m); T = 10; w = B2w(B, T); 
w_missing = w(:, 1:m_missing); w_given = w(:, m_missing+1:end);

BT = B2BT(B, T); [BT_missing, BT_given] = BT2UYT(BT, m_missing, m_given + p);
wh_missing = BT_missing * BT_given' * vec(w_given');
wh_missing = reshape(wh_missing, m_missing, T)';

rank(BT_given) == T * m + n % -> 1

e = norm(w_missing - w_missing) / norm(w_missing) % -> 0

%% Direct data-driven forcasting

robot_arm_; m = 1; p = 1; n = 8; 
wd = [u y]; [Td, q] = size(wd);

Tv = 50; Ti = Td - Tv;
wi = wd(1:Ti, :); wv = wd(Ti+1:end, :);
Tini = n; w_ini = wi(end - Tini + 1:end, :);

tic
yh_dd = u2y(hank(wi, Tv + Tini), q, wv(:, 1:m), w_ini); 
t_dd = toc % -> 0.0186

tic 
Bh = n4sid(iddata(wi(:, m+1:end), wi(:, 1:m)), n); 
f = forecast(Bh, iddata(w_ini(:, m+1:end), w_ini(:, 1:m)), Tv, wv(:, 1:m)); 
yh_mb = f.OutputData; t_mb = toc % -> 1.4176

e = @(yh) 100 * norm(wv(:, m+1:end) - yh) / norm(wv(:, m+1:end)); 
[e(yh_dd), e(yh_mb)] % -> 3.5531    3.8398
