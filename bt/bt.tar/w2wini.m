function [wini, e] = w2wini(wf, BT, Tini, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[Tf, q] = size(wf); T = size(BT, 1) / q; 
if ~exist('Tini', 'var') || isempty(Tini), c = BT2c(BT, q); Tini = c(2); end
Bini = BT(1:q * Tini, :); Bf = BT(q * Tini + 1:end, :); % selection from BT!
g = pinv(Bf, tol) * vec(wf'); wini = reshape(Bini * g, q, Tini)'; 
if nargout > 1, e = norm(vec(wf') - Bf * g); end
