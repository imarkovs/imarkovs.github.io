function r = c2r(ctol, T, opt)
if isscalar(ctol), 
  r = ctol; 
else 
  if exist('opt', 'var'), r = ctol(1) * T; else r = ctol(1) * T + ctol(3); end
end
