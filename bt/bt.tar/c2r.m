function r = c2r(c, T, opt)
if ~exist('opt', 'var'), r = c(1) * T + c(3); 
else r = c(1) * T; end % needed for BT2B0
