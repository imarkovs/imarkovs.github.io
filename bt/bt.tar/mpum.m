function Rmat = mpum(w, ell_max, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~iscell(w), [T, q] = size(w); else, [T, q] = size(w{1}); end 
if ~exist('ell_max', 'var') || isempty(ell_max)
  ell_max = floor((T + 1) / (q + 1)); 
end
m = q; p = 0; ell = []; R = {};
for L = 1:ell_max
  H = hank(w, L);
  if rank(H, tol) < m * L + sum(ell) 
    N = null(H', tol)'; Np = multmat_(R, q, L); 
    if isempty(Np), Rnew = N; else, Rnew = perp(Np / N) * N; end
    if ~isempty(Rnew),
        dp = size(Rnew, 1);
        for i = 1:dp, R{p+i} = Rnew(i, :); ell(p+i) = L - 1; end
        p = p + dp; m = m - dp; 
    end
  end
end
ell = max(ell); p = length(R); Rmat = zeros(p, q * (ell+1));
for i = 1:p
  Ri = R{i}; elli = size(Ri, 2) / q - 1;
  Rmat(i, 1:q * (elli + 1)) = Ri; 
end
