function R = B2R(B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
R = null(B2BT(B, lag(B, tol) + 1)', tol)';
