function [UT, YT] = BT2UYT(BT, m, p)
q = m + p; [qT, N] = size(BT); T = qT / q;
UT = zeros(m * T, N); for i = 1:m, UT(i:m:end, :) = BT(i:q:end, :); end
YT = zeros(p * T, N); for i = 1:p, YT(i:p:end, :) = BT(m+i:q:end, :); end
