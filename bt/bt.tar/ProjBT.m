function wh = ProjBT(w, BT)
wh = BT * BT' * w;
