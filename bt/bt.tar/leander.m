function [w_hat, R_ret] = LPV_SLRA_optimized(iso_trajs, ell, r, Rini, fixed_R_indices, max_iterations)
    
    MIN_DELTA_F = 1e-5;
    MIN_GRAD_F = 1e-5;
    MIN_DELTA_R = 1e-6;
    if isa(iso_trajs, 'cell')
        ds_amt = numel(iso_trajs);
        w = cell(ds_amt, 1);
        p = cell(ds_amt, 1);
        T = cell(ds_amt, 1);
        weights = cell(ds_amt, 1);
        for i=1:ds_amt
            traj = iso_trajs{i};
            w{i} = traj.w;
            p{i} = traj.p;
            T{i} = traj.T;
            weights{i} = traj.weights;
        end
    else
        traj = iso_trajs;
        ds_amt = 1;
        w = {traj.w};
        p = {traj.p};
        T = traj.T;
        weights = {traj.weights};
    end

    nu = iso_trajs{1}.nu;
    np = iso_trajs{1}.np;
    q = size(w{1}, 1);
    q_ex = (np+1)*q;
    L = max(ell)+1;
    d = q_ex*L-r;
    ny = q-nu;
    R = Rini;
%     R = rand(3, q_ex*6);
%     R(1, 1:3*q_ex) = 0;
%     R(2, 1:2*q_ex) = 0;
%     ell = [2 3 5];
%     L = max(ell)+1;
    R_lagged = get_R_lagged(R, L, ell);
    G_width = 0;
    b = cell(ds_amt, 1);
    fixed_idxs = cell(ds_amt, 1);
    fixed_amt = cell(ds_amt, 1);
    LW = cell(ds_amt, 1);
    Pts_free = cell(ds_amt, 1); Iq = speye(q);
    Perm = cell(ds_amt, 1);
    dGtdR = cell(ds_amt, 1);
    vec_w1 = cell(ds_amt, 1);
    vec_w2 = cell(ds_amt, 1);
    w_ex_vec = cell(ds_amt, 1);
    V_cell = cell(ds_amt, 1);
    for i=1:ds_amt
        b{i} = T{i}-L+1;
        if b{i} < r
            fprintf('Hankel matrix %u is not wide enough!\n', i)
            w_hat = w;
            R_ret = Rini;
            return
        end

        fixed_idxs{i} = isinf(vec(weights{i})); fixed_amt{i} = sum(fixed_idxs{i});
        if fixed_amt{i} == numel(w{i})
            R_ret = Rini;
            w_hat = w;
            return
        end
        Gi_width = q*T{i}-fixed_amt{i};
        G_width = G_width + Gi_width;
        W = speye(Gi_width).*vec(weights{i}(~fixed_idxs{i}));
        LW{i} = chol(W);
        tmp = vec(1:q*T{i});
        tmp_idxs = 1:q;
        Pts_free{i} = cell(T{i}, 1);
        wgts = weights{i};
        for t=1:T{i}
            Iq_tmp = Iq .* (1./sqrt(wgts(:, t)));
            Pts_free{i}{t} = kron([1; p{i}(:, t)], Iq_tmp(:, ~fixed_idxs{i}(tmp_idxs)));
            tmp_idxs = tmp_idxs + q;
        end
        Perm{i} = sparse([tmp(fixed_idxs{i}); tmp(~fixed_idxs{i})], tmp, ones(q*T{i}, 1));
        dGtdR{i} = get_dGp(Pts_free{i}, d, q, L, fixed_amt{i}, ell);
        vec_wp = Perm{i}'*vec(w{i});
        vec_w1{i} = vec_wp(1:fixed_amt{i});
        vec_w2{i} = vec_wp(fixed_amt{i}+1:end);
        w_ex = zeros(q_ex, T{i});
        for t=1:T{i}
            w_ex(:, t) = kron([1; p{i}(:, t)], w{i}(:, t));
        end
        w_ex_vec{i} = w_ex(:);


        V_cell_tmp = cell(b{i}, L); a = q_ex*L;
        for ii=1:b{i}
            work2 = custom_blkdiag_prod(Pts_free{i}, ii, ii+L-1);
            for di=1:L
                if ii+di-1 > b{i}
                    V_cell_tmp{ii,di} = zeros(a, a);
                else
                    V_cell_tmp{ii,di} = [zeros((di-1)*q_ex, a);work2((di-1)*q_ex+1:end, (di-1)*q_ex+1:end) zeros(a-(di-1)*q_ex, (di-1)*q_ex)];
                end
            end
        end
        V_cell{i} = V_cell_tmp;
    end

    fixed_R_idxs = zeros(ny*L, 1);
    fixed_R_idxs2 = zeros(np*ny*L, 1);
    tmp = kron([1; zeros(np, 1)], [zeros(nu, L); reshape(1:ny*L, ny, L)]);
    for i=1:numel(tmp)
        if tmp(i) > 0
            fixed_R_idxs(tmp(i)) = i;
            for j=1:np
                fixed_R_idxs2(np*(tmp(i)-1)+j) = i+j*q;
            end
        end
    end
    fixed_R_idxs = fixed_R_idxs(end-d+1:end);
    fixed_R_idxs2 = fixed_R_idxs2(end-np*d+1:end);
    R(:, fixed_R_idxs2) = 0;
    fixed_R_idxs = [fixed_R_idxs; fixed_R_idxs2];
    global_fixed_R_idxs = fixed_R_indices(:);
    for i=1:d
        global_fixed_R_idxs = [global_fixed_R_idxs; sub2ind(size(R), i*ones(size(fixed_R_idxs)), fixed_R_idxs)];
    end
    free_R_idxs = 1:size(R, 2);
    free_R_idxs(fixed_R_idxs) = [];
    mu = 1e0;
    for iter=1:max_iterations
        J = zeros(G_width, numel(R));
        delta_w = zeros(G_width, 1);
        f0 = 0;
        cur_offset = 1;
        for i=1:ds_amt
            [Ji, delta_wi, f0i] = calculate_jac_g(w_ex_vec{i}, R, R_lagged, L, Pts_free{i}, V_cell{i}, dGtdR{i}, T{i});%vec(dR(:, free_R_idxs))';
            Gi_width = q*T{i} - fixed_amt{i};
            J(cur_offset:cur_offset+Gi_width-1, :) = Ji;
            delta_w(cur_offset:cur_offset+Gi_width-1) = delta_wi;
            cur_offset = cur_offset + Gi_width;
            f0 = f0 + f0i;
        end
        if f0 == -inf && Tini > 0
            fprintf('Unable to solve system.\n')
        end
        J(:, global_fixed_R_idxs) = 0;
        dR = delta_w'*J;
        if norm(dR, 'fro') < MIN_GRAD_F
            fprintf('[%u] Norm of gradient is too small (||∇f||_2=%.2e). Terminating early.\n', iter, norm(dR, 'fro'))
            break
        end
        Bk = J'*J;
        success = false; II = eye(size(J, 2));
        R2 = R;
        delta_R = zeros(size(R));
        delta_f = 0;
        while mu < 1e15
            alpha = abs(mu*f0);
            delta = [J; sqrt(alpha)*II]\[-delta_w; zeros(size(J, 2), 1)];
            delta_R = reshape(delta, d, []);
            delta_R = delta_R(:, free_R_idxs);
            R2(:, free_R_idxs) = R(:, free_R_idxs)+delta_R;
            R2_lagged = get_R_lagged(R2, L, ell);
            f1 = get_f(V_cell, w_ex_vec, R2, R2_lagged, L, T);
            if f1 < 0
                rho = -inf;
            else
                f_pred1 = f0 + dR*delta + 0.5*(delta'*(Bk*delta));
                rho = (f0-f1)/(f0-f_pred1);
            end
            if rho > 0.95
                mu = min(1e-10, mu/3);
                success = true;
                delta_f = f0-f1;
                break
            else
                mu = 3*mu;
            end
        end
        if norm(delta_R, 'fro') < MIN_DELTA_R
            fprintf('[%u] Step became too small. Terminating early. 2f = %.2e\n', iter, 2*f0)
            fprintf('[%u] new f=%.2e; Delta f=%.2e; ||Delta R||_F=%.2e; ||∇f||_2=%.2e; alpha=%.2e\n', iter, f0-delta_f, delta_f, norm(delta_R, 'fro'), norm(dR, 'fro'), alpha)
            break
        end
        if delta_f < MIN_DELTA_F
            fprintf('[%u] Likelihood improvement became too small. Terminating early. 2f = %.2e\n', iter, 2*f0)
            fprintf('[%u] new f=%.2e; Delta f=%.2e; ||Delta R||_F=%.2e; ||∇f||_2=%.2e; alpha=%.2e\n', iter, f0-delta_f, delta_f, norm(delta_R, 'fro'), norm(dR, 'fro'), alpha)
            break
        end
        if ~success
            break
        end
%         if mod(iter, 20) == 0
            fprintf('[%u] new f=%.2e; Delta f=%.2e; ||Delta R||_F=%.2e; ||∇f||_2=%.2e; alpha=%.2e\n', iter, f0-delta_f, delta_f, norm(delta_R, 'fro'), norm(dR, 'fro'), alpha)
%         end
        R = R2;
        R_lagged = R2_lagged;
    end
    f_ret = 0;
    w_hat = cell(ds_amt, 1);
    for i=1:ds_amt
        G2pp = get_G2(Pts_free{i}, R, R_lagged);
        [s, yy] = get_sy(w_ex_vec{i}, R, R_lagged, L, T{i}, G2pp*G2pp');
        w2_hat = vec_w2{i} - LW{i}\(G2pp'*yy);
        w_hat_i = reshape(Perm{i}*[vec_w1{i}; w2_hat], q, T{i});
        w_hat{i} = w_hat_i;
        f_ret = f_ret + 0.5*(yy'*s);
    end
    if ds_amt == 1
        w_hat = w_hat{i};
    end
    if nargout > 1
        R_ret = R;
    end
    fprintf('[%u] f=%.2e; ||dR||=%.2e; mu=%.2e\n', iter, f_ret, norm(dR, 'fro'), mu)
end

function [R_lagged] = get_R_lagged(R, L, ell)
    if isscalar(ell)
        R_lagged = {};
    else
        R_lagged = cell(L-1, 1);
        for i=1:L-1
            R_lagged{i} = R(ell<=L-1-i, q_ex*i+1:end);
        end
    end
end

function [M] = custom_blkdiag_prod(mats, start, stop)
    h = size(mats{1}, 1);
    th = h * (stop-start+1);
    M = zeros(th, th);of = 0;
    for i=start:stop
        Mi = mats{i};
        M(of+(1:h), of+(1:h)) = full(Mi*Mi');
        of = of+h;
    end
end

function [M] = cell_prod_sum(lst1, lst2, start2)
    rows = size(lst1{1}, 1);
    cols = 0;
    for i=1:numel(lst1)
        i2 = start2+i-1;
        cols = cols + size(lst2{i2}, 2);
    end
    M = zeros(rows, cols);
    offset = 0;
    for i=1:numel(lst1)
        i2 = start2+i-1;
        c = size(lst2{i2}, 2);
        M(:, offset+(1:c)) = lst1{i}*lst2{i2};
        offset = offset+c;
    end
end

function [G] = get_G2(Pts, R, R_lagged)
    q_ex = size(Pts{1}, 1);
    nrho = sum(Pts{end}(:, 1) ~= 0) - 1;
    q = q_ex/(nrho + 1);
    [d, tmp] = size(R);
    L = floor(tmp/q_ex);
    b = numel(Pts)-L+1;
    R_cell = cell(L, 1); offset = 0;
    for i=1:L
        R_cell{i} = R(:, offset+(1:q_ex));
        offset = offset + q_ex;
    end
    xoffset = 0; yoffset = 0;
    amt = d*q*L*b;  % Worst case
    if numel(R_lagged) > 0
        for i=1:numel(R_lagged)
            amt = amt + size(R_lagged{i}, 1)*q*(L-i);
        end
    end
    rows = zeros(amt, 1); cols = zeros(amt, 1); vals = zeros(amt, 1);
    offset = 0;
    if numel(R_lagged) > 0
        for i=1:numel(R_lagged)
            dL = numel(R_lagged)-i+1;
            R_lag = R_lagged{dL};
            dd = size(R_lag, 1);
            if dd == 0
                continue
            end
            R_cell_lagged = cell(L-i, 1); offst = 0;
            for j=1:L-dL
                R_cell_lagged{j} = R_lag(:, offst+(1:q_ex));
                offst = offst + q_ex;
            end
            tmp = cell_prod_sum(R_cell_lagged, Pts, 1);
            w = size(tmp, 2);
            idxs = offset+(1:dd*w);
            rows(idxs) = repmat(yoffset+(1:dd)', w, 1);
            cols(idxs) = vec(repmat(1:w, dd, 1));%kron(xoffset+(1:w)', ones(d, 1));
            vals(idxs) = tmp(:);
            offset = offset + dd*w;
            yoffset = yoffset + dd;
        end
    end
    for idx=0:b-1
        tmp = cell_prod_sum(R_cell, Pts, idx+1);
        w = size(tmp, 2);
        idxs = offset+(1:d*w);
        rows(idxs) = repmat(yoffset+(1:d)', w, 1);
        cols(idxs) = vec(repmat(xoffset+(1:w), d, 1));
        vals(idxs) = tmp(:);
        offset = offset + d*w;
        yoffset = yoffset + d;
        xoffset = xoffset + size(Pts{idx+1}, 2);
    end
    G = sparse(rows(1:offset), cols(1:offset), vals(1:offset));
end

function [G] = get_Gamma(q_ex, b, V_cell, R)
    [d, tmp] = size(R);
    L = floor(tmp/q_ex);
    Rt = zeros(size(R, 2), L);
    for t=1:L
        Rt(:, t) = [zeros(q_ex*(t-1), 1); R(:, 1:end-q_ex*(t-1))'];
    end
    xoffset = 0; yoffset = 0;
    amt = d*d*L;  % Upper bound
    rows = zeros(amt, 1); cols = zeros(amt, 1); vals = zeros(amt, 1);
    offset = 0;
    amt = L;
    for row=1:b
        tmp = R*(V_cell{row, 1}*Rt);
        if row+L-1 > b
            amt = b+1-row;
            tmp = tmp(:, 1:end-L+amt);
        end
        idxs = offset+(1:d*d*amt);
        irows = repmat(yoffset+(1:d)', amt, 1);
        icols = repmat(xoffset+(1:d*amt), d, 1);
        rows(idxs) = irows;
        cols(idxs) = icols(:);
        vals(idxs) = tmp(:);
        offset = offset + d*d*amt;
        
        if amt > 0
            idxs = offset+(1:d*d*(amt-1));
            rows(idxs) = icols(d*d+1:end);
            cols(idxs) = irows(d*d+1:end);
            vals(idxs) = tmp(d*d+1:end);
            offset = offset + d*d*(amt-1);
        end

        yoffset = yoffset + d;
        xoffset = yoffset;
    end
    G = sparse(rows(1:offset), cols(1:offset), vals(1:offset));
end

function [dG] = get_dGp(Pts, d, q, L, fixed_amt, lags)
    q_ex = size(Pts{1}, 1);
    b = numel(Pts)-L+1;
    dG = coder.nullcopy(cell(d, q_ex*L));
    max_amt = b;
    if ~isscalar(lags)
        ell = max(lags);
        max_amt = max_amt + ell;
    end
    rows = zeros(max_amt, 1); cols = zeros(max_amt, 1); vals = zeros(max_amt, 1);
    for j=1:q_ex*L
        xoffset = 0; yoffset = 1; amt = 0;
        offset = 1; P_offset = 1+mod(j-1, q_ex); P_idx = floor((j-1)/q_ex);
        if ~isscalar(lags)
            for idx=1:ell
                num_rows = sum(lags<idx);
                if num_rows == 0
                    continue
                end
                dL = L-idx;
                if P_idx-dL < 0
                    yoffset = yoffset + num_rows;
                    continue
                end
                [~, cc, tmp] = find(Pts{1+P_idx-dL}(P_offset, :));
                if numel(tmp) == 0
                    yoffset = yoffset + num_rows;
                    continue
                end
                for k=1:P_idx-dL
                    cc = cc + size(Pts{k}, 2);
                end
                rows(offset) = yoffset;
                cols(offset) = xoffset+cc;
                vals(offset) = tmp;
                amt = amt+1;
                offset = offset+1;
                yoffset = yoffset + num_rows;
            end
        end
        for idx=1:b
            [~, cc, tmp] = find(Pts{idx+P_idx}(P_offset, :));
            if numel(tmp) == 0
                yoffset = yoffset + d;
                xoffset = xoffset + size(Pts{idx}, 2);
                continue
            end
            for k=1:P_idx
                cc = cc + size(Pts{idx-1+k}, 2);
            end
            rows(offset) = yoffset;
            cols(offset) = xoffset+cc;
            vals(offset) = tmp;
            amt = amt + 1;
            offset = offset + 1;
            yoffset = yoffset + d;
            xoffset = xoffset + size(Pts{idx}, 2);
        end
        for i=1:d
            if ~isscalar(lags) && P_idx + lags(i) < max(lags)
                dG{i, j} = sparse(q*numel(Pts)-fixed_amt, d*b);
            else
                dG{i, j} = sparse(cols(1:amt), (i-1)+rows(1:amt), vals(1:amt), q*numel(Pts)-fixed_amt, d*b);
            end
        end
    end
end

function [f] = get_f(V_cell, wd_ext_vec, R, R_lagged, L, T)
    f = 0; ds_amt = numel(V_cell);
    q_ext = floor(numel(wd_ext_vec{1})/T{1});
    for i=1:ds_amt
        Gamma = get_Gamma(q_ext, T{i}-L+1, V_cell{i}, R);
        [s, y] = get_sy(wd_ext_vec{i}, R, R_lagged, L, T{i}, Gamma);
        f = f + 0.5*(y'*s);
    end
end

function [s, y] = get_sy(wd_ext_vec, R, R_lagged, L, T, Gamma)
    d = size(R, 1); q_ex = floor(numel(wd_ext_vec)/T);
    cols = (T-L+1);
    s = zeros(d*cols, 1);
    offset = 0;
    if numel(R_lagged) > 0
        for i=1:numel(R_lagged)
            dL = numel(R_lagged)-i+1;
            R_lag = R_lagged{dL};
            dd = size(R_lag, 1);
            if dd == 0
                continue
            end
            s(offset+(1:dd)) = R_lag*wd_ext_vec(1:size(R_lag, 2));
            offset = offset + dd;
        end
    end
    idxs = offset+(1:d); idxs2 = 1:size(R, 2);
    for t=1:cols
        s(idxs) = R*wd_ext_vec(idxs2);
        idxs = idxs + d;
        idxs2 = idxs2 + q_ex;
    end
    y = Gamma\s;
end

function [Jg, delta_w, f] = calculate_jac_g(wd_ext_vec, R, R_lagged, L, Pts, V_cell, dGtdR, T)
    % See section 4.2
    q_ex = floor(numel(wd_ext_vec)/T);
    b = T-L+1;
    size_R = size(R);
    d = size_R(1);
    G = get_G2(Pts, R, R_lagged);
    Gamma2 = decomposition(G*G', 'banded');
    [s, y] = get_sy(wd_ext_vec, R, R_lagged, L, T, Gamma2);
    Y = reshape(y, d, b);
    delta_w = G'*y;
    RtY = R'*Y; Ii = eye(d); YtR = RtY';
    Jg = zeros(size(G, 2), size_R(1)*size_R(2));
    z_js = zeros(b, q_ex*L);
    if norm(y) > 1e15
        fprintf('Conditioning problem!\n')
        f = -inf;
        return
    end
    for row=1:b
        for c=max(row-L+1, 1):min(row+L-1, b)
            if c <= row
                Vij = V_cell{c, row-c+1};
            else
                Vij = V_cell{row, c-row+1}';
            end
            z_js(row, :) = z_js(row, :) + YtR(c, :)*Vij;%Vij(j, :)*RtY(:, c);
        end
    end
    z_ij2 = zeros(d*b, q_ex*L, d);
    for i=1:d
        for row=1:b
            idxs = (row-1)*d+(1:d);
            for c=max(row-L+1, 1):min(row+L-1, b)
                if c < row
                    Vij = V_cell{c, row-c+1}';
                else
                    Vij = V_cell{row, c-row+1};
                end
                z_ij2(idxs, :, i) = z_ij2(idxs, :, i) + Y(i, c)*(R*Vij);
            end
        end
    end
    for j=1:q_ex*L
        idxs = (j:q_ex:j+numel(wd_ext_vec)-L*q_ex);
        for i=1:d
            z_ij = kron(wd_ext_vec(idxs)-z_js(:, j), Ii(:, i)) - z_ij2(:, j, i);
            x = G'*(Gamma2\z_ij);
            Jg(:, i+(j-1)*d) = x + dGtdR{i, j}*y;
        end
    end
    f = 0.5*(y'*s);
end