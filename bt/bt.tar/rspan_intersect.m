function C = rspan_intersect(A, B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
Ap = null(A, tol); Bp = null(B, tol); C = null([Ap Bp]', tol)';
