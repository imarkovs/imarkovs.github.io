function [c, m, ell, n] = w2c(wd, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
[c, m, ell, n] = c_mpum(wd, ctol);
