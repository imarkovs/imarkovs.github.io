function [m, ell, n] = unpack_c(c), m = c(1); ell = c(2); n = c(3);
