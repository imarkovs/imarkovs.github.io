function w = B2w(B, T, xini, u)
[p, m] = size(B); n = order(B);
if ~exist('xini', 'var') || isempty(xini), xini = rand(n, 1); end
if isscalar(xini) && xini == 0, xini = zeros(n, 1); end
if ~exist('u', 'var') || isempty(u), u = rand(T, m); end
if isscalar(u) && u == 0, u = zeros(T, m); end
y = lsim(B, u, [], xini); w = [u y];
