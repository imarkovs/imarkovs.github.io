function wh = input_selection(wd, wr, m, lambda)
if ~exist('lambda', 'var'), lambda = 1e-2; end
[Tr, q] = size(wr); p = q - m;
Hu = hank(wd(:, 1:m), Tr);     ur = vec(wr(:, 1:m)');
Hy = hank(wd(:, m+1:end), Tr); yr = vec(wr(:, m+1:end)');
cvx_begin quiet 
  variable g(size(Hu, 2), 1)
  minimize(norm(yr - Hy * g) + lambda * sum(sum_square(ur - Hu * g)))
cvx_end
wh = [reshape(Hu * g, m, Tr)' reshape(Hy * g, p, Tr)'];
