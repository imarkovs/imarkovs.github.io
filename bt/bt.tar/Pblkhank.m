function wh = Pblkhank(D, L)
[m, n] = size(D); q = m / L; T = L + n - 1; np = T * q;
I = blkhank(reshape(1:np, q, T)', L); 
for k = 1:np, ph(k) = mean(D(I == k)); end
wh = reshape(ph, q, T)';
