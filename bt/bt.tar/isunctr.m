function n_unctr = isunctr(B, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[p, m] = size(B); q = p + m; n = order(B); ell = lag(B); 
T = 3 * ell; BC = BT2BC(B2BT(B, T), q, tol); 
n_unctr = m * size(BC, 1) / q + n - size(BC, 2);
