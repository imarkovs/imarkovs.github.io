function n_unctr = isunctr(B, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
[p, m] = size(B); q = p + m; n = order(B); ell = lag(B); 
T = 3 * ell; BC = BT2BC(B2BT(B, T), q, ctol); 
n_unctr = m * size(BC, 1) / q + n - size(BC, 2);
