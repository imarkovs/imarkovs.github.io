function [u, y] = w2uy(w, m, p)
q = m + p; T = size(w, 1) / q; 
for i = 1:m, u(i:m:m*T, :) = w(i:q:end, :); end
for i = 1:p, y(i:p:p*T, :) = w(m+i:q:end, :); end
