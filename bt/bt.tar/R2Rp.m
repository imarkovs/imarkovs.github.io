function [Rp, ells] = R2Rp(R, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
if iscell(R), R = Rcell2Rmat(R, q); end
[Rr, jb] = rref_(orth(R', tol)', tol); L = size(R, 2) / q;

%% if the row leading coefficent is rank deficient, add shifts in R
[Rrcell, ~, Rrlc] = Rmat2Rcell(Rr, q, tol); r = rank(Rrlc, tol);
if r < size(Rrlc, 1) && r < size(Rrlc, 2)
    Rr = multmat(Rrcell, q, L); 
    [Rr, jb] = rref_(Rr, tol); 
    %% remove zero rows
    Ir = []; for i = 1:size(Rr, 1), if norm(Rr(i, :)) < tol, Ir = [Ir i]; end, end, 
    Rr(Ir, :) = [];    
end

%% detect the annihilators
d   = ceil(jb / q) - 1;     % row degrees
dd  = diff(d);              % change points
Idd = [find(dd) length(d)]; % indeces of the change points
k   = diff([0 Idd]);        % # of rows with equal degree

ells = d(1:k(1)); 
Rp{1} = Rr(1:Idd(1), 1:q*(d(1) + 1)); % the first k(1) rows are annihilators
for i = 2:length(k)
    ell_i = d(Idd(i - 1) + 1);
    Ri = Rr(Idd(i - 1) + 1:Idd(i), 1:q * (ell_i + 1));
    Rold = multmat(Rp, q, ell_i + 1);
    Rnew = rspan_intersect(perp(rspan_intersect(Ri, Rold, tol)), Ri, tol);
    ells = [ells, ell_i * ones(1, size(Rnew, 1))]; Rp = [Rp; Rnew]; 
end
