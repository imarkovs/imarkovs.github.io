function BT = BT2BT(BT, q, Tio, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
T = size(BT, 1) / q; 
if isscalar(Tio), Tnew = Tio; % horizon restriction
  if T == Tnew, return, end % nothing to do
  if T < Tnew, error('extension of the horizon not implemented'), end
  if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
  BTnew = []; 
  for i = 0:(T - Tnew)
    BTnew = [BTnew BT(i * q + 1:(i + Tnew) * q, :)]; 
  end
  BT = lra(BTnew, c2r(ctol, Tnew)); 
else, io = Tio;  % variables permutation
  BT = BT(q * kron(0:T-1, ones(1, q)) + kron(ones(1, T), io), :);
end
