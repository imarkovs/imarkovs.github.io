function ans = w_in_kerR(w, R, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
ans = norm(R * hank(w, size(R, 2) / size(w, 2))) < tol;
