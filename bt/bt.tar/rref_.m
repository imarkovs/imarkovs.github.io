function [Rr, jb] = rref_(R, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
[Rr, jb] = rref(fliplr(R), tol); 
Rr = flipud(fliplr(Rr)); 
jb = flip(size(R, 2) + 1 - jb);
