function Rmin = BT2Rmin(BT, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
[c, m, ell, n] = BT2c(BT, q, ctol);
R = {}; ells = []; p = []; i = 1; 
for L = 1:ell+1
  BL = BT2BT(BT, q, L); r = rank(BL, tol);
  if (r > m * L + sum(ells)) & (r < q * L)
    N  = null(BL', tol)'; Np = multmat_(R, q, L);
    if ~isempty(Np), Nnew = rspan_diff(N, Np); else, Nnew = N; end
    if ~isempty(Nnew), 
      R{i} = Nnew; ells(i) = L - 1; p(i) = size(Nnew, 1); i = i + 1;
    end
  end
end
ell_max = max(ells); Rmin = []; 
for i = 1:length(R)
  Rmin = [Rmin; [R{i} zeros(p(i), q * (ell + 1) - size(R{i}, 2))]]; 
end
