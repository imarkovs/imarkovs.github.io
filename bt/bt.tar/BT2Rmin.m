function [Rmin, ells] = BT2Rmin(BT, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
%% <ctol2c>
if isscalar(ctol) % estimate c from BT or wd
  if exist('R', 'var') && ~exist('BT', 'var'), BT = null(R); end
  if exist('BT', 'var'), [c, m, ell, n] = BT2c(BT, q, ctol); 
  elseif exist('wd', 'var'), [c, m, ell, n] = c_mpum(wd, ctol); end
else % ctol should specify complexity 
  c = ctol; m = c(1); ell = c(2); n = c(3);
end % [c, m, ell] = BT2c(BT, q, ctol);
R = {}; ells = []; m = q; i = 0; 
for L = 1:ell+1
  BL = BT2BT(BT, q, L, ctol); r = rank(BL, tol);
  if (r < m * L + sum(ells)) 
    N = null(BL', tol)'; Np = multmat_(R, q, L);
    if ~isempty(Np), Nnew = rspan_diff(N, Np); else, Nnew = N; end
    for j = 1:size(Nnew, 1) R{i + j} = Nnew(j, :); ells(i + j) = (L - 1); end
    i = i + size(Nnew, 1);
  end
end
ell_max = max(ells); Rmin = []; 
for i = 1:length(R)
  Rmin = [Rmin; [R{i} zeros(1, q * (ell + 1) - size(R{i}, 2))]]; 
end
