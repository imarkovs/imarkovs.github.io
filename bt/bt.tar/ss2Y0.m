function Y0 = ss2Y0(B, T); Y0 = obsvm(B, T);
