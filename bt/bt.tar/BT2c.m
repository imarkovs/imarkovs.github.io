function [c, m, ell, n] = BT2c(BT, q, ctol);
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
if isscalar(ctol), 
  tol = ctol; T = size(BT, 1) / q; 
  r1 = rank(BT, tol); r2 = rank(BT2BT(BT, q, T - 1), tol); 
  mn = [T 1; T-1 1] \ [r1; r2]; 
  m = round(mn(1)); n = round(mn(2));
  if n > 0
    for ell = 1:n, if rank(BT2BT(BT, q, ell), tol) == ell * m + n, break, end, end
  else, ell = 0; end
  c = [m, ell, n];
else, c = ctol; m = c(1); ell = c(2); n = c(3); end
