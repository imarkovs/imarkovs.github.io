function ans = equal(B1, B2, tol, T)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('T', 'var') || isempty(T), T = 100; end % <default-horizon>
ans = Bdist(B1, B2, T) < tol;
