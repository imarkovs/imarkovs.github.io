m = 1; ells = [1 1 2];

ell = max(ells); n = sum(ells); 
p = length(ells); q = m + p;
c = [m, ell, n];

R = zeros(p, q * (ell + 1));
for i = 1:p
  R(i, 1:q * (ells(i) + 1)) = rand_schur(ells(i), q);
end

T = 3 * (ell + 1);
BT = R2BT(R, q, T);
Rd = BT2R(BT, q);

[Rh, ellsh]  = R2Rmin(Rd, q);

equal(BT, R2BT(Rd, q, T))
all(ells == ellsh)
equal(BT, R2BT(Rh, q, T))

Bh = BT2ss(BT, q, 1:q); 
T = ell + 1; BT = R2BT(R, q, T); BhT = B2BT(Bh, T); Bdist(BT, BhT, q)
