function Rmin = R2Rmin(R, q, tol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
ell1 = size(R, 2) / q; Tmin = 3 * ell1;
Rmin = BT2Rmin(R2BT(R, q, Tmin, tol), q, tol);
