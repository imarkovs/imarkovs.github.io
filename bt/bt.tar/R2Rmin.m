function [Rmin, ells] = R2Rmin(R, q, ctol)
if ~exist('tol', 'var') || isempty(tol), tol = 1e-8; end % <default-tol>
if ~exist('ctol', 'var') || isempty(ctol), ctol = tol; end % <default-ctol>
ell1 = size(R, 2) / q; Tmin = 3 * ell1;
[Rmin, ells] = BT2Rmin(R2BT(R, q, Tmin, ctol), q, ctol);
