function wh = ddint(wd, w, S, c, l)
if ~exist('S') || isempty(S), S = ones(size(w)); end %% <default-S>
[Ts, q] = size(w); 
w_vec = vec(w'); S_vec = vec(S'); Ig = find(~isnan(w_vec)); 
%% <if-wd-is-lti-simulate-data>
if isa(wd, 'lti'), B = wd;
  m = size(B, 2); n = order(B); 
  Tmin = @(T) (m + 1) * T + n - 1; %% <define-Tmin>
  wd = B2w(B, Tmin(Ts)); 
end
Hwd = hank(wd, Ts); 
if exist('c') && ~isempty(c)
  r = c(1) * Ts + c(3); tol = 1e-10;
  if rank(Hwd, tol) < r, warning('wd not informative.'); end
  Hwd = lra(Hwd, r); 
end
A = S_vec(Ig, ones(1, size(Hwd, 2))) .* Hwd(Ig, :); 
b = S_vec(Ig) .* w_vec(Ig); 
if ~exist('l') || isempty(l) || l == 0
  g = pinv(A) * b;
else, g = lasso(A, b, l); end
wh = reshape(Hwd * g, q, Ts)';
