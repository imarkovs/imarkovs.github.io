function p = rand_schur(ell, q)
if ~exist('q'), q = 1; end, p = zeros(1, q * (ell+1));
for i = 1:q, p(i:q:end) = flip(poly(eig(drss(ell)))); end