% Construct random parameter vector for a given structure specification
% that results in an rank n matrix

function [p0,s0,c0,x0] = rand_p0(s,m,d)

randn('state',0)

n_d  = sum(s(:,2));
n    = n_d - d;
f    = -1;
iter = 0;
MAXITER = 2;

% Find np
q  = size(s,1);   % number of blocks
t  = max(s(:,3));
np_t = 0;
np   = 0;
s0   = zeros(m,n_d);
ni   = 0;
for i = 1:q
  if (s(i,1) == 1) | (s(i,1) == 2)
    np_t = np_t + t * s(i,4);
    np   = np + t*s(i,2);
  elseif s(i,1) == 3
    np_t = np_t + t * s(i,2);
    np   = np + t*s(i,2);
  else
    s0i  = randn(m,s(i,2));
    s0   = s0 + [zeros(m,ni),s0i,zeros(m,n_d-ni-s(i,2))];
  end
  ni = ni + s(i,2);
end
np = np + (m/t-1) * np_t;

while f < 0  
  p = randn(np,1);
  c = s0 + construct(p,s,m);
  [x0,f,c0,p0] = stls(c(:,1:n),c(:,n+1:end),s);
  iter = iter + 1;
  if iter > MAXITER
    error('Can not find p0!')
  end
end
