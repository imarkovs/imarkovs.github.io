% General structure test program

randn('state',0)

% specify m, n, d, and the structure
m  = 100;
n  = 5;
d  = 1;

%s  = [1 n 1 1; 3 d 1 1]; % A - Toeplitz, b - unstructured; deconvolution
%s = [2 n+d 2 3]; % [A b] Hankel
s = [3 n+d 1 1]; % TLS
%s = [4 n 1 1; 3 d 1 1]; % LS

% generate true random data
[p0,s0,c0,x0] = rand_p0(s,m,d);
% and noisy data for the estimation
pt = 0.1 * randn(size(p0));
p  = p0 + pt;
c  = s0 + construct(p,s,m);

% find estimates
xh_ls  = c(:,1:n)\c(:,n+1:end);
xh_tls = tls(c(:,1:n),c(:,n+1:end));
tic, [xh_qn,ic_qn,ch_qn,ph_qn] = stls(c(:,1:n),c(:,n+1:end),s,[],'qn',1e-10); t_qn = toc;
tic, [xh_lm,ic_lm,ch_lm,ph_lm] = stls(c(:,1:n),c(:,n+1:end),s,[],'lm',1e-10); t_lm = toc;
tic, [xh_nm,ic_nm,ch_nm,ph_nm] = stls(c(:,1:n),c(:,n+1:end),s,[],'nm',1e-10); t_nm = toc;
tic, [xh_mv,ic_mv,ch_mv,ph_mv] = stls(c(:,1:n),c(:,n+1:end),s,xh_lm,'mvk',1e-10); t_mv = toc;

% check results

% error on p
fprintf('\n norm(p0-ph) / norm(p0)\n\n')
fprintf('err_p     = %f\n', norm(p0-p) / norm(p0))
fprintf('err_ph_qn = %f\n', norm(p0-ph_qn) / norm(p0))
fprintf('err_ph_lm = %f\n', norm(p0-ph_lm) / norm(p0))
fprintf('err_ph_nm = %f\n', norm(p0-ph_nm) / norm(p0))
fprintf('err_ph_mv = %f\n', norm(p0-ph_mv) / norm(p0))

% error on x
fprintf('\n norm(x0-xh) / norm(x0)\n\n')
fprintf('err_xh_ls  = %f\n', norm(x0-xh_ls,'fro')  / norm(x0,'fro'))
fprintf('err_xh_tls = %f\n', norm(x0-xh_tls,'fro') / norm(x0,'fro'))
fprintf('err_xh_qn  = %f\n', norm(x0-xh_qn,'fro')  / norm(x0,'fro'))
fprintf('err_xh_lm  = %f\n', norm(x0-xh_lm,'fro')  / norm(x0,'fro'))
fprintf('err_xh_nm  = %f\n', norm(x0-xh_nm,'fro')  / norm(x0,'fro'))
fprintf('err_xh_mv  = %f\n', norm(x0-xh_mv,'fro')  / norm(x0,'fro'))

% show x
fprintf('\n [    QN         LM       NM        MVK   ] \n\n')
fprintf('        %d         %d       %d        %d       \n', ic_qn, ic_lm, ic_nm, ic_mv)
disp([  t_qn, t_lm, t_nm, t_mv ])
fprintf('\n')
disp([  xh_qn     xh_lm     xh_nm    xh_mv  ])
