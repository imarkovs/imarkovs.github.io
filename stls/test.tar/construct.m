% CONSTRUCT a structured matrix 

function c = construct(p,struct,m)

S = decode_struct(struct,[],m);

p = [0;p(:)]; % treat properly; noise-free elements
c = p(S(:)+1);
c = reshape(c,m,size(S,2));
