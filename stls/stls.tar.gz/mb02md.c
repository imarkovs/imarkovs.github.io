/* 
MEX function for calling the SLICOT function MB02MD. Solves a TLS problem AX = B. 

In Linux and Solaris execute: 

g77 -c MB02MD.f

Link to LAPACK and BLAS. Mex command (you will need to adapt the paths):

Solaris: mex mb02md.c MB02MD.o /software/lib/liblapack.a /software/lib/libblas.a
Linux:   mex mb02md.c MB02MD.o /usr/lib/liblapack.a /usr/lib/libblas.a /usr/lib/gcc-lib/i386-redhat-linux/3.2/libg2c.a

Calling sequence: mb02md([a b],n), where n = size(a,2). 
*/

#include <stdio.h>
#include <string.h>
#include "mex.h"

int max(int,int);

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )

{
  double *c, *c_copy, *x, *s, *dwork, tol=0;
  int    m, n, l, iwarn, info, ldwork, *iwork, ldc_copy, r=0; 
  char   *chb = "B", msg[50];

  /* Get input data */
  c = mxGetPr( prhs[0] ); 
  n = mxGetScalar( prhs[1] );

  /* Define constants */
  m        = mxGetM( prhs[0] );
  l        = mxGetN( prhs[0] ) - n;
  ldc_copy = max(m,n+l);
  if ( m < n+l ) {
    ldwork = max(m*(n+l)+max(3*m+n+l,5*m),3*l);
  } else {
    ldwork = max(3*(n+l)+m,5*(n+l));
  }
  
  /* Reserve memory */
  plhs[0] = mxCreateDoubleMatrix(n, l, mxREAL);
  x       = mxGetPr( plhs[0] );
  c_copy  = mxCalloc( ldc_copy*(n+l), sizeof(double));
  s       = mxCalloc(n+l, sizeof(double));
  dwork   = mxCalloc(ldwork, sizeof(double));
  iwork   = mxCalloc(l, sizeof(int));

  /* Copy c to c_copy */
  memcpy(c_copy,c,m*(n+l)*sizeof(double));

  /* Call MB02MD */

  mb02md_(chb, &m, &n, &l, &r, c_copy, &ldc_copy, s, x, &n, &tol, iwork, dwork, &ldwork, &iwarn, &info);

  if (info != 0) {
    sprintf(msg, "MB02MD failed with an error info = %d.\n", info);
    mexErrMsgTxt(msg);
  } 

  mxFree(c_copy);
  mxFree(s);
  mxFree(dwork);
  mxFree(iwork);
}

int max(int x, int y)
{
  return( x > y ? x : y );
}
