% STLS - Structured Total Least Squares estimation
%
% Solves the structured system of equations A*X = B, with both A and B noisy.
% The augmented data matrix C = [A B] is of the form C = [C1 ... Cq], where 
% the blocks Ci are (block) Toeplitz or Hankel structured, unstructured, or 
% constant. C depends affinely on a vector of parameters P, i.e., C = C(P). 
% The STLS problem is:
%
%   min_{Xh,Ph} (P-Ph)' * blkdiag(VP,...,VP) * (P-Ph) s.t. C(Ph) [ Xh ] = 0
%                                                                [ -I ]
%
% [ xh, ic, ch, ph ] = stls( a, b, struct, x0, method, tol, info, vp )
%
% Input arguments:
%
% A, B      - noisy data
% STRUCT    - structure specification, a matrix with q rows and 4 columns
%   STRUCT(i,1)   - structure type [ 1 | 2 | 3 | 4 ] of the i-th block
%     1 - (block) Toeplitz, 2 - (block) Hankel, 3 - Unstructured, 4 - Noise free
%   STRUCT(i,2)   - number of columns of the i-th block
%   STRUCT(i,3:4) - dimension of the repeated blocks (for block Toeplitz/Hankel)  
% X0        - initial approximation (default TLS)
% METHOD    - solution method [ MVK | QN | LM | NM ] (default LM)
%   MVK - new iterative method, QN - fminunc, LM - lsqnonlin, NM - fminsearch
% TOL       - convergence tolerance (default 1e-5)
%             exit condition: ||X(k+1)-X(k)||_F / ||X(0)||_F < TOL
% INFO      - level of display [ off | iter | notify | final ] (default off)
% VP        - noise covariance matrix (default I)
%
% Output arguments:
%
% XH        - STLS estimate
% IC        - number of iterations for convergence, or -1 if not converged
% CH        - corrected matrix C(Ph) (Ch = [Ah Bh] - structured, and Ah*Xh = Bh)
% PH        - estimated parameter vector Ph 
%
% Note: The program can not treat the case length(P) < size(A,1) * size(B,2).
%
% See also the supplied demo file demo.m

% Reference: I. Markovsky, S. Van Huffel, and A. Kukush, "On the computation of the 
% structured total least squares estimator", Report #02--203, Dept. EE, K.U. Leuven.
% URL: ftp://ftp.esat.kuleuven.ac.be/pub/SISTA/markovsky/abstracts/02-203.html

function [ xh, ic, ch, ph ] = stls( a, b, struct, x0, method, tol, info, vp )

% Check the input data
if nargin < 3
  error('Not enough input arguments.')
else
  % check dimensions 
  if size(a,1) ~= size(b,1)
    error('A must have as many rows as B.')
  end
  if size(struct,2) ~= 4
    error('Incorrect structure specification STRUCT.')
  end
  if (size(a,2) + size(b,2) ~= sum(struct(:,2)))
    error('The structure of [A B] does not match the specification.')
  end
end
if nargin < 4 | isempty(x0)
  % default initial approximation is TLS 
  x0 = mb02md([a b],size(a,2)); % computed by the SLICOT function MB02MD
elseif size(x0) ~= [size(a,2),size(b,2)]
  error('The dimension of X0 does not match the dimensions of A and B.')
end
if nargin < 5 | isempty(method)
  method = 'lm'; % default method is lsqnonlin
else 
  method = lower(method); % convert to lowercase
  if ~ismember(method,{'mvk','qn','lm','nm'})
    error(sprintf('Unknown method ''%s''.',method))
  end
end
if nargin < 6 | isempty(tol)
  tol = 1e-5; % default convergence tolerance
elseif any(size(tol) ~= [1,1]) | tol >= 1  
  error('TOL must be a real number less than 1.')
end
if nargin < 7 | isempty(info)
  info = 'off'; % default value
else
  info = lower(info); % convert to lowercase
  if ~ismember(info,{'off','on','iter','notify','final'})
    warning('Unknown INFO option. Ignored.')
    info = 'off';
  end
end
if nargin < 8 
  vp = [];
end
if ~check_np_g_md(struct,size(b,2)) % check the condition np > md
  error('The case np < m*d can not be solved!')
end
svp = size_vp(struct);
if ~isempty(vp) & ~all([svp svp] == size(vp)) % check the size of vp
  error(sprintf('For the given structure VP should be of size %d x %d !',svp,svp))
end

% Common for all methods optimization parameters
opt = optimset('Diagnostics', 'off', 'Display', info, 'TolFun', eps, 'MaxFunEvals', inf, ...
               'DerivativeCheck', 'off', 'LargeScale', 'off');

% Find {V1,...,Vk}
[S,V] = decode_struct(struct,vp);
t     = max(struct(:,3));
d     = size(b,2);

% Chose method to solve the problem
if t*d == 1 % single RHS, row-vector structure
  switch method
   case 'mvk'
    opt = optimset(opt, 'TolX', tol, 'MaxIter', 100);
    [xh,info] = mvk1(x0,opt,a,b,V);
   case 'nm'
    opt = optimset(opt, 'TolX', tol, 'MaxIter', 500);
    [xh,minf,flag,info] = fminsearch(@cost1,x0,opt,a,b,V); 
   case 'qn'
    opt = optimset(opt, 'GradObj', 'on', 'TolX', tol, 'MaxIter', 100); 
    [xh,minf,flag,info] = fminunc(@cost1,x0,opt,a,b,V); 
   case 'lm'
    opt = optimset(opt, 'TolFun', tol, 'TolX', tol, 'MaxIter', 100); 
    [xh,minf,res,flag,info] = lsqnonlin(@cost1_,x0,[],[],opt,a,b,V);
   otherwise
    error(sprintf('Unknown method ''%s''.',method))
  end
else % multiple RHS and/or non row-vector block structure
  switch method
   case 'mvk'
    opt = optimset(opt, 'TolX', tol, 'MaxIter', 100);
    [xh,info] = mvk2(x0,opt,a,b,V);
   case 'nm'
    opt = optimset(opt, 'TolX', tol, 'MaxIter', 1000);
    [xh,minf,flag,info] = fminsearch(@cost2,x0,opt,a,b,V);
   case 'qn'
    opt = optimset(opt, 'GradObj', 'on', 'TolX', tol, 'MaxIter', 100); 
    [xh,minf,flag,info] = fminunc(@cost2,x0,opt,a,b,V);
   case 'lm'
    opt = optimset(opt, 'TolFun', sqrt(tol), 'TolX', tol, 'MaxIter', 100); 
    [xh,minf,res,flag,info] = lsqnonlin(@cost2_,x0,[],[],opt,a,b,V);
   otherwise
    error(sprintf('Unknown method ''%s''.',method))
  end
end

% Assign the output arguments
if nargout > 1
  ic = info.iterations;
  if ~(ic < opt.MaxIter)
    ic = -1; % not converged
  end
  if nargout > 2 
    [ch,ph] = corr(xh,[a b],struct,vp);    
  end
end
  
% ---------------------------------------------------------------------------
% COST1 - STLS cost function and gradient; t = 1, d = 1
function [ cost, grad ] = cost1( x, a, b, V )

% Construct the first row of Vr
s = size(V,3);
f = zeros(1,s);
for k = 1:s
  f(k) = [x;-1]' * V(:,:,k)' * [x;-1];
end
r = a*x-b;

% Solve the system Vr*yr = r
yr   = mb02gd(f,r); % Slicot solver
cost = r'*yr;

% Gradient
if nargout > 1
  n       = size(a,2);
  n_1     = n + 1;
  N       = zeros(s,1);
  N(1)    = norm(yr)^2;
  Vx      = zeros(n,s);
  Vx(:,1) = V(1:n,1:n,1) * x - V(1:n,n_1,1);
  for k = 2:s
    N(k) = yr(1:end-k+1)' * yr(k:end);
    Vx(:,k) = (V(1:n,1:n,k) + V(1:n,1:n,k)') * x - V(1:n,n_1,k) - V(n_1,1:n,k)';
  end
  grad = 2 * (a'*yr - Vx*N);
end

% ---------------------------------------------------------------------------
% COST1_ - STLS cost function for LSQNONLIN; t = 1, d = 1
function cost = cost1_( x, a, b, V )

% Construct the first row of Vr
s = size(V,3);
f = zeros(1,s);
for k = 1:s
  f(k) = [x;-1]' * V(:,:,k)' * [x;-1];
end
r = a*x-b;

% Solve the system Vr^{1/2}*F = r
cost = mb02gd_(f,r); % Slicot solver

% -----------------------------------------------------------------------------
% MVK1 - STLS computation by the proposal of [MVK02]; t = 1, d = 1
function [ x, info ] = mvk1( x, opt, a, b, V )

n    = size(a,2);
s    = size(V,3);
info = ismember(opt.Display,{'iter','on'});
n_1  = n+1;

% Construct symmetric V-s, {Vs1,...Vs}  
Vs          = zeros(n,n,s);
Vb          = zeros(n,s);
Vs(:,:,1)   = V(1:n,1:n,1); 
Vb(:,1)     = V(1:n,n+1,1);
for k = 2:s
  Vs(:,:,k) = V(1:n,1:n,k) + V(1:n,1:n,k)';
  Vb(:,k)   = V(1:n,n_1,k) + V(n_1,1:n,k)';
end

% Iteration
x_  = zeros(n,1); % estimate from the previous iteration
nx0 = norm(x);
ic  = 0;          % iteration counter
f   = zeros(1,s);
N   = zeros(s,1);
while (norm(x - x_)/nx0 > opt.TolX) & (ic < opt.MaxIter)
  % Construct {Fk}
  for k = 1:s
    f(k) = [x; -1]' * V(:,:,k)' * [x; -1];
  end
  % Solve the system Vr*yc = [A b]
  yc = mb02gd(f,[a b]); % Slicot function
  yr = yc(:,1:n)*x - yc(:,n_1);
  % Construct the system
  N(1) = norm(yr)^2;
  Vax  = zeros(n);
  for k = s:-1:2
    N(k) = yr(1:end-k+1)' * yr(k:end);
    Vax  = Vax + Vs(1:n,1:n,k) * N(k); 
  end
  Vax = Vax + Vs(1:n,1:n,1) * N(1); 
  A = a'*yc(:,1:n) - Vax;
  B = a'*yc(:,n_1) - Vb*N;
  % Solve it
  x_ = x;
  x  = A\B;   %fprintf('%6.0f; ',cond(A));
  ic = ic + 1;
  % print info
  if info
    fprintf('%d - %f\n', ic, norm(x - x_)/nx0)
  end
end
%fprintf('\n');

info = [];
info.iterations = ic;
if ismember(opt.Display,{'on','iter','final','notify'})
  if ic == opt.MaxIter
    fprintf('MVK1 method did not converge in %d iterations.\n', ic);
  else
    fprintf('MVK1 method converged in %d iterations.\n', ic);
  end
end

% -----------------------------------------------------------------------------
% COST2 - STLS cost function and gradient
function [ cost, deriv ] = cost2( x, a, b, V )

[m,n] = size(a);
d     = size(b,2);
s     = size(V,3);
t     = size(V,1) / (n+d);
x_ext = [x;-eye(d)];
if t > 1
  x_ext = kron(eye(t),x_ext);
end

% Construct the first row of Vr
f = zeros(t*d,t*d,s);
for k = 1:s
  f(:,:,k)  = x_ext' * V(:,:,k)' * x_ext;
end
F  = reshape(f,size(f,1),size(f,2)*size(f,3));
r  = a*x-b;
rt = r';

% Solve the system Vr*yr = R(:)
yr = mb02gd(F,rt(:));
cost = rt(:)'*yr;

if nargout == 2
  if t == 1
    n_1   = n+1;
    Yr    = reshape(yr,d,m);
    deriv = zeros(n,d);
    for k = s:-1:2
      N = zeros(d);
      for i = 1:m-k+1
        N = N + Yr(:,i+k-1)*Yr(:,i)';
      end
      deriv = deriv + (V(1:n,1:n,k)*x - V(1:n,n_1:end,k))*N' ...
              + (V(1:n,1:n,k)'*x - V(n_1:end,1:n,1)')*N;
    end
    N = zeros(d);
    for i = 1:m
      N = N + Yr(:,i)*Yr(:,i)';
    end
    deriv = a'*Yr' - deriv - (V(1:n,1:n,1)*x - V(1:n,n_1:end,1))*N';
  else
    n_1   = n+1;
    n_d   = n+d;
    td    = t*d;
    tn    = t*n;
    mt    = m/t;
    Yr    = reshape(yr,td,mt);
    deriv = zeros(n,d);
    for k = s:-1:2
      N = zeros(td);
      for i = 1:mt-k+1
        N = N + Yr(:,i+k-1)*Yr(:,i)';
      end
      temp = zeros(n,d);
      for i = 1:t
        for j = 1:t
          Vij  = V((i-1)*n_d+1:i*n_d,(j-1)*n_d+1:j*n_d,k);
          Nij  = N((i-1)*d+1:i*d,(j-1)*d+1:j*d);
          temp = temp + (Vij(1:n,1:n)*x - Vij(1:n,n_1:end))*Nij' ...
                 + (Vij(1:n,1:n)'*x - Vij(n_1:end,1:n)')*Nij;
        end
      end
      deriv = deriv + temp;
    end
    N = zeros(td);
    for i = 1:mt
      N = N + Yr(:,i)*Yr(:,i)';
    end
    temp = zeros(n,d);
    for i = 1:t
      for j = 1:t
        Vij  = V((i-1)*n_d+1:i*n_d,(j-1)*n_d+1:j*n_d,1);
        Nij  = N((i-1)*d+1:i*d,(j-1)*d+1:j*d);
        temp = temp + (Vij(1:n,1:n)*x - Vij(1:n,n_1:end))*Nij';
      end
    end
    deriv = a'*reshape(yr,d,m)' - deriv - temp;
  end
  deriv = 2*deriv;
end

% -----------------------------------------------------------------------------
% COST2_ - STLS cost function for LSQNONLIN
function F = cost2_( x, a, b, V )

[n,d] = size(x);
s     = size(V,3);
t     = size(V,1) / (n+d);
x_ext = [x;-eye(d)];
if t > 1
  x_ext = kron(eye(t),x_ext);
end

% Construct the first row of Vr
f = zeros(t*d,t*d,s);
for k = 1:s
  f(:,:,k)  = x_ext' * V(:,:,k)' * x_ext;
end
F = reshape(f,size(f,1),size(f,2)*size(f,3));
r  = a*x-b;
rt = r';

% Solve the system Vr^{1/2}*F = R(:)
F = mb02gd_(F,rt(:));

% -----------------------------------------------------------------------------
% MVK2 - STLS computation by the proposal of [MVK02]
function [ x, info ] = mvk2( x0, opt, a, b, V )

[m,n] = size(a);
d     = size(b,2);
s     = size(V,3);
t     = size(V,1) / (n+d);
info = ismember(opt.Display,{'iter','on'});

n_1 = n+1;
n_d = n+d;
nd  = n*d;
td  = t*d;
mt  = m/t;

% Iteration
x     = x0;
x_    = zeros(n,d);           % estimate from the previous iteration
nx0   = norm(x0,'fro');
ic    = 0;                    % iteration counter
f     = zeros(td,td,s);
bt    = b';
while (norm(x - x_,'fro')/nx0 > opt.TolX) & (ic < opt.MaxIter)
  % Construct {Fk}
  x_ext = [x; -eye(d)];
  if t > 1
    x_ext = kron(eye(t),x_ext);
  end
  for k = 1:s
    f(:,:,k) = x_ext' * V(:,:,k)' * x_ext;
  end
  F = reshape(f,size(f,1),size(f,2)*size(f,3));
  % Construct the system
  A = zeros(m*d,nd);
  for i = 1:d
    A(i:d:end,(i-1)*n+1:i*n) = a;
  end
  r  = a*x - b;
  rt = r';
  A  = [A bt(:) rt(:)];
  % Solve the system Vr*Ya = A
  Y = mb02gd(F,A);
  
  Ya = Y(:,1:nd);
  yb = Y(:,nd+1);
  yr = Y(:,nd+2);

  if t == 1
    Yr = reshape(yr,d,m);  
    BB  = zeros(n,d);
    AA_ = zeros(nd); 
    for k = s:-1:2
      N = zeros(d);
      for i = 1:m-k+1
        N = N + Yr(:,i+k-1)*Yr(:,i)';
      end
      BB   = BB + V(1:n,n_1:end,k) * N' + V(n_1:end,1:n,k)' * N;
      temp = kron(N,V(1:n,1:n,k)); 
      AA_  = AA_ + temp + temp';
    end
    N  = zeros(d);  
    for i = 1:m
      N = N + Yr(:,i)*Yr(:,i)';
    end
    BB  = BB  + V(1:n,n_1:end,1) * N';
    AA_ = AA_ + kron(N,V(1:n,1:n,1)); 
  else
    Yr  = reshape(yr,td,mt);
    BB  = zeros(n,d);
    AA_ = zeros(nd);
    for k = s:-1:2
      N = zeros(td);
      for i = 1:mt-k+1
        N = N + Yr(:,i+k-1)*Yr(:,i)';
      end
      for i = 1:t
        for j = 1:t
          Vij  = V((i-1)*n_d+1:i*n_d,(j-1)*n_d+1:j*n_d,k);
          Nij  = N((i-1)*d+1:i*d,(j-1)*d+1:j*d);
          BB   = BB + Vij(1:n,n_1:end) * Nij' + Vij(n_1:end,1:n)' * Nij;
          temp = kron(Nij,Vij(1:n,1:n));
          AA_  = AA_ + temp + temp';
        end
      end
    end
    N  = zeros(td);
    for i = 1:mt
      N = N + Yr(:,i)*Yr(:,i)';
    end
    for i = 1:t
      for j = 1:t
        Vij = V((i-1)*n_d+1:i*n_d,(j-1)*n_d+1:j*n_d,1);
        Nij = N((i-1)*d+1:i*d,(j-1)*d+1:j*d);
        BB  = BB  + Vij(1:n,n_1:end) * Nij';
        AA_ = AA_ + kron(Nij,Vij(1:n,1:n));
      end
    end
  end
  BB = a'*reshape(yb,d,m)' - BB;
  BB = BB(:);
  AA = zeros(nd);
  for i  = 1:m
    AA = AA + kron(Ya((i-1)*d+1:i*d,:)',a(i,:));
  end
  AA = AA - AA_;
  % Solve it
  x_ = x;
  x  = reshape(AA\BB,n,d); %fprintf('%6.0f; ',cond(AA));
  ic = ic + 1;
  % print info
  if info
    fprintf('%d - %f\n',ic,norm(x - x_)/nx0)
  end
end
%fprintf('\n');

info = [];
info.iterations = ic;
if ismember(opt.Display,{'on','iter','final','notify'})
  if ic == opt.MaxIter
    fprintf('MVK2 method did not converge in %d iterations.\n', ic);
  else
    fprintf('MVK2 method converged in %d iterations.\n', ic);
  end
end

% -----------------------------------------------------------------------------
% DECODE_STRUCT - Decodes the structure specification and forms the matrices Vk
function [ S, V ] = decode_struct( struct, vp, m )

n_d = sum(struct(:,2)); % = n+d
q   = size(struct,1);   % number of blocks

% Determine the s-dependence parameter indices of the Toeplitz/Hankel structured blocks
TH  = (struct(:,1) == 1) | (struct(:,1) == 2);
[max_n,max_i] = max([struct(find(TH),2);1]);
s   = struct(max_i,3) * max_n / struct(max_i,4); % s-dependence parameter

% default number of rows is s
if nargin < 3
  m = s;
end

% Form S
S   = zeros(m,n_d);
np  = 0;              % parameter counter
col = 1;              % column counter 
for i = 1:q
  ni = struct(i,2);   % # of column of Si
  Si = zeros(s,ni);
  switch struct(i,1)
   case {1,2} % Toeplitz/Hankel block
    bm  = struct(i,3);   % # of rows for the repeated block
    bn  = struct(i,4);   % # of columns for the repeated block
    mb  = m/bm;          % # of blocks rows
    nb  = ni/bn;         % # of block columns
    Si  = zeros(bm,mb,bn,nb);
    Sij = zeros(bm,bn,nb);
    t   = reshape(1:bm*bn,bm,bn); % repeated block
    for j = 1:nb
      Sij(:,:,nb-j+1) = np + t + (j-1)*bm*bn;
    end
    if struct(i,1) == 1 % Toeplitz block
      for j = 1:mb
        Si(:,j,:,:)  = Sij;
        Sij(:,:,end) = [];
        Sij          = cat(3,t+Sij(bm*bn),Sij);
      end
      Si = reshape(Si,mb*bm,nb*bn);
      np = Si(end,bn);
    else % Hankel block
      for j = 1:mb
        Si(:,mb-j+1,:,:) = Sij;
        Sij(:,:,end)     = [];
        Sij              = cat(3,t+Sij(bm*bn),Sij);
      end
      Si = reshape(Si,mb*bm,nb*bn);
      np = Si(bm,bn);
    end
   case 3 % Unstructured block
    Si = reshape((np+1):(np+m*ni),m,ni);
    np = np + m*ni;
   case 4 % Noise-free block
    Si = zeros(m,ni);
   otherwise
    error(sprintf('Unknown structure type ''%s''.',s(i,1)))
  end
  S(:,col:col+ni-1) = Si;
  col = col + ni; 
end

if nargout == 2
  t = max(struct(:,3));
  if t == 1
    n_d = t * n_d;
    s   = s/t;
  end
  % Construct {V1,...Vs}  
  V  = zeros(n_d,n_d,s);
  s1 = S(1,:);
  if isempty(vp)
    s1(find(s1 == 0)) = -1;
    for k = 1:s
      sk  = S(k,:);
      V(:,:,k) = (sk(ones(n_d,1),:)' == s1(ones(n_d,1),:));
    end
  else
    vp = kron(eye(s),vp);
    nv = size(vp,1);
    vp = [zeros(1,nv+1); [zeros(nv,1) vp]];
    np = size(vp,1);
    for k = 1:s
      sk = S(k,:);
      V(:,:,k) = vp( s1(ones(n_d,1),:) + 1 + np * (sk(ones(n_d,1),:)') );
    end
  end
end

% -----------------------------------------------------------------------------
% CHECK_NP_G_MD - Checks whether the assumption np > md holds true: 1 - yes, 0 - no
function ans = check_np_g_md( struct, d )

q = size(struct,1);   % number of blocks
t = max(struct(:,3));

np = 0;
for i = 1:q
  if (struct(i,1) == 1) | (struct(i,1) == 2)
    np = np + t * struct(i,4);
  elseif struct(i,1) == 3
    np = np + t * struct(i,2);
  end
end
ans = (np >= t*d);

% -----------------------------------------------------------------------------
% SIZE_VP - Returns the size of the covariance matrix VP for the given structure
function svp = size_vp( struct )

t   = max(struct(:,3));
svp = t * sum( struct( ( struct(:,1) ~= 4 ) , 2 ) );

% ----------------------------------------------------------------------------
% CORR - finds the STLS correction and checks the structure of C 
function [ ch, ph ] = corr( x, c, struct, vp )

m     = size(c,1);
[n,d] = size(x);
[S,V] = decode_struct(struct,[],m);
t     = size(V,1) / (n+d);
s     = size(V,3);
np    = max(max(S));

% Find yr
if t*d == 1
  f = zeros(1,s);
  for k = 1:s
    f(k) = [x;-1]' * V(:,:,k)' * [x;-1];
  end
  r  = c(:,1:n)*x-c(:,n+1);
  yr = mb02gd(f,r);
else
  x_ext = [x;-eye(d)];
  if t > 1
    x_ext = kron(eye(t),x_ext);
  end
  f = zeros(t*d,t*d,s);
  for k = 1:s
    f(:,:,k)  = x_ext' * V(:,:,k)' * x_ext;
  end
  F  = reshape(f,size(f,1),size(f,2)*size(f,3));
  r  = c(:,1:n)*x-c(:,n+1:end);
  rt = r';
  yr = mb02gd(F,rt(:));
end

% The computation of G is not efficient; TO BE IMPROVED
g  = zeros(m*d,np);
for i = 1:np
  gi = (S == i) * [x;-eye(d)];
  git = gi';
  g(:,i) = git(:);
end

% Compute DP
if isempty(vp)
  dp =  g' * yr;
else
  Vp = kron(eye(np/size(v,1)),v);
  dp =  Vp * g' * yr;
end

% Find CH
dp_ = [0; dp];
ch  = c - reshape(dp_(S(:)+1),m,n+d);

% Extract p from c and check consistency of C and STRUCT
p = zeros(np,1);
for i = 1:np
  ci   = c(S==i);
  ci11 = ci(1,1);
  if ~all(all(ci == ci11(ones(size(ci)))))
    error('The structure of [A B] does not match the specification.')
  end
  p(i) = ci11;
end
ph  = p - dp;

