% TLS --- TLS solution of Ax = B

function xh = tls(a,b)

n  = size(a,2);
d  = size(b,2);

[u,s,v]  = svd([a,b]);
xh = -v(1:n,n+1:end) / v(n+1:end,n+1:end);
